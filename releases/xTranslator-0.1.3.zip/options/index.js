"use strict";
(() => {
  // src/shared/contracts/settings.ts
  var DEFAULT_PROVIDER_ID = "deepseek";
  var DEFAULT_CAPTION_DISPLAY_MODE = "bilingual";
  var DEFAULT_API_KEYS = {};
  var DEFAULT_PROVIDER_MODELS = {};
  var DEFAULT_PROVIDER_SETTINGS = {
    providerId: DEFAULT_PROVIDER_ID,
    model: ""
  };
  var DEFAULT_SUBTITLE_SETTINGS = {
    displayMode: DEFAULT_CAPTION_DISPLAY_MODE,
    shortsTranslationEnabled: false,
    translationColor: "#ffd438",
    originalColor: "#ececf0",
    translationFontScale: 100,
    originalFontScale: 100,
    verticalPosition: null
  };
  var DEFAULT_SELECTION_SETTINGS = {
    enabled: true,
    includeContext: false
  };
  var DEFAULT_PAGE_TRANSLATION_SETTINGS = {
    autoTranslateTitle: true
  };
  var DEFAULT_SETTINGS = {
    provider: { ...DEFAULT_PROVIDER_SETTINGS },
    apiKeys: { ...DEFAULT_API_KEYS },
    providerModels: { ...DEFAULT_PROVIDER_MODELS },
    subtitles: { ...DEFAULT_SUBTITLE_SETTINGS },
    page: { ...DEFAULT_PAGE_TRANSLATION_SETTINGS },
    selection: { ...DEFAULT_SELECTION_SETTINGS }
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function parseCaptionDisplayMode(value) {
    if (value === "original" || value === "translation" || value === "bilingual") {
      return value;
    }
    return null;
  }
  function parseProviderSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    if (typeof value.providerId !== "string" || !value.providerId.trim()) {
      return null;
    }
    if (typeof value.model !== "string") {
      return null;
    }
    return {
      providerId: value.providerId.trim(),
      model: value.model.trim()
    };
  }
  function parseApiKeys(value) {
    if (!isRecord(value)) {
      return null;
    }
    const apiKeys = {};
    for (const [providerId, apiKey] of Object.entries(value)) {
      if (typeof apiKey !== "string") {
        return null;
      }
      apiKeys[providerId] = apiKey;
    }
    return apiKeys;
  }
  function resolveProviderApiKey(settings, providerId = settings.provider.providerId) {
    return settings.apiKeys[providerId] ?? "";
  }
  function resolveProviderModel(settings, providerId = settings.provider.providerId) {
    return settings.providerModels[providerId] ?? (providerId === settings.provider.providerId ? settings.provider.model : "");
  }
  function parseProviderModels(value) {
    if (value === void 0) {
      return {};
    }
    if (!isRecord(value)) {
      return null;
    }
    const models = {};
    for (const [providerId, model] of Object.entries(value)) {
      if (typeof model !== "string") {
        return null;
      }
      models[providerId] = model.trim();
    }
    return models;
  }
  function parseSubtitleSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const displayMode = parseCaptionDisplayMode(value.displayMode);
    if (!displayMode) {
      return null;
    }
    const shortsTranslationEnabled = value.shortsTranslationEnabled === void 0 ? DEFAULT_SUBTITLE_SETTINGS.shortsTranslationEnabled : value.shortsTranslationEnabled;
    if (typeof shortsTranslationEnabled !== "boolean") {
      return null;
    }
    const translationColor = value.translationColor === void 0 ? DEFAULT_SUBTITLE_SETTINGS.translationColor : parseCaptionColor(value.translationColor);
    const originalColor = value.originalColor === void 0 ? DEFAULT_SUBTITLE_SETTINGS.originalColor : parseCaptionColor(value.originalColor);
    const translationFontScale = value.translationFontScale === void 0 ? DEFAULT_SUBTITLE_SETTINGS.translationFontScale : parseCaptionFontScale(value.translationFontScale);
    const originalFontScale = value.originalFontScale === void 0 ? DEFAULT_SUBTITLE_SETTINGS.originalFontScale : parseCaptionFontScale(value.originalFontScale);
    if (!translationColor || !originalColor || !translationFontScale || !originalFontScale) {
      return null;
    }
    const verticalPosition = parseVerticalCaptionPosition(value.verticalPosition);
    if (verticalPosition === void 0) {
      return null;
    }
    return {
      displayMode,
      shortsTranslationEnabled,
      translationColor,
      originalColor,
      translationFontScale,
      originalFontScale,
      verticalPosition
    };
  }
  function parsePageTranslationSettings(value) {
    if (value === void 0) {
      return { ...DEFAULT_PAGE_TRANSLATION_SETTINGS };
    }
    if (!isRecord(value)) {
      return null;
    }
    const autoTranslateTitle = value.autoTranslateTitle === void 0 ? DEFAULT_PAGE_TRANSLATION_SETTINGS.autoTranslateTitle : value.autoTranslateTitle;
    return typeof autoTranslateTitle === "boolean" ? { autoTranslateTitle } : null;
  }
  function parseCaptionColor(value) {
    return typeof value === "string" && /^#[0-9a-f]{6}$/iu.test(value) ? value.toLowerCase() : null;
  }
  function parseCaptionFontScale(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= 80 && value <= 160 ? value : null;
  }
  function parseVerticalCaptionPosition(value) {
    if (value === void 0 || value === null) {
      return null;
    }
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1 ? value : void 0;
  }
  function parseSelectionSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const enabled = value.enabled === void 0 ? true : value.enabled;
    if (typeof enabled !== "boolean") {
      return null;
    }
    if (typeof value.includeContext !== "boolean") {
      return null;
    }
    return { enabled, includeContext: value.includeContext };
  }
  function parseExtensionSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const provider = parseProviderSettings(value.provider);
    if (!provider) {
      return null;
    }
    let apiKeys = parseApiKeys(value.apiKeys);
    if (!apiKeys) {
      const legacyKey = isRecord(value.provider) ? value.provider.apiKey : void 0;
      if (typeof legacyKey === "string") {
        apiKeys = { [provider.providerId]: legacyKey };
      } else {
        return null;
      }
    }
    const providerModels = parseProviderModels(value.providerModels);
    if (!providerModels) {
      return null;
    }
    if (provider.model && providerModels[provider.providerId] === void 0) {
      providerModels[provider.providerId] = provider.model;
    }
    const subtitles = parseSubtitleSettings(value.subtitles);
    if (!subtitles) {
      return null;
    }
    const page = parsePageTranslationSettings(value.page);
    if (!page) {
      return null;
    }
    const selection = parseSelectionSettings(value.selection);
    if (!selection) {
      return null;
    }
    return { provider, apiKeys, providerModels, subtitles, page, selection };
  }

  // src/shared/contracts/messages.ts
  var MESSAGE_TYPE = {
    getSettings: "get-settings",
    getVideoTranslationCache: "get-video-translation-cache",
    getVideoTranslationStatus: "get-video-translation-status",
    updateVideoTranslationStatus: "update-video-translation-status",
    translateVideo: "translate-video",
    translateVideoProgress: "translate-video-progress",
    translateText: "translate-text",
    translateTextProgress: "translate-text-progress",
    translateSelectionFromContext: "translate-selection-from-context",
    getCacheStats: "get-cache-stats",
    listCache: "list-cache",
    clearVideoCache: "clear-video-cache",
    clearAllCache: "clear-all-cache"
  };
  function isRecord2(value) {
    return typeof value === "object" && value !== null;
  }
  function isListCacheResponse(value) {
    if (!isRecord2(value) || typeof value.totalBytes !== "number" || !Array.isArray(value.entries)) {
      return false;
    }
    return value.entries.every(
      (entry) => isRecord2(entry) && typeof entry.title === "string" && typeof entry.videoId === "string" && typeof entry.sourceLanguage === "string" && typeof entry.targetLanguage === "string" && typeof entry.blockCount === "number" && typeof entry.updatedAt === "number"
    );
  }

  // src/shared/providers/http-client.ts
  var HTTP_RETRY = { maxAttempts: 3, baseDelayMs: 800, timeoutMs: 12e4 };
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function shouldRetryHttpStatus(status) {
    return status === 408 || status === 429 || status >= 500;
  }
  function mapHttpStatusCode(status) {
    if (status === 401 || status === 403) {
      return { reason: "auth", message: "Provider rejected the API key." };
    }
    if (status === 429) {
      return { reason: "rate-limit", message: "Provider rate limit reached; try again shortly." };
    }
    if (status === 404) {
      return { reason: "model", message: "The selected model was not found for this provider." };
    }
    if (status >= 500) {
      return { reason: "bad-response", message: "Provider returned a server error." };
    }
    return { reason: "bad-response", message: "Provider returned an unexpected response." };
  }
  function logProviderHttpFailure(url, status, attempt) {
    let origin = "unknown";
    try {
      origin = new URL(url).origin;
    } catch {
    }
    console.warn("[xTranslator] LLM HTTP request failed", { origin, status, attempt });
  }
  function isAbortError(error) {
    return error instanceof DOMException && error.name === "AbortError" || error instanceof Error && error.name === "AbortError";
  }
  function mapNetworkError(error) {
    if (isAbortError(error)) {
      return { reason: "timeout", message: "Provider request timed out." };
    }
    return { reason: "network", message: "Provider request failed over the network." };
  }
  function mapFailureReason(reason) {
    return reason === "timeout" || reason === "network";
  }
  async function sendWithRetry(fetchFn, url, init, retry) {
    let lastFailure = null;
    for (let attempt = 0; attempt < retry.maxAttempts; attempt += 1) {
      if (attempt > 0) {
        await sleep(retry.baseDelayMs * 2 ** (attempt - 1));
      }
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), retry.timeoutMs);
      try {
        const response = await fetchFn(url, { ...init, signal: controller.signal });
        if (response.ok) {
          return { ok: true, response };
        }
        logProviderHttpFailure(url, response.status, attempt + 1);
        const failure = mapHttpStatusCode(response.status);
        if (shouldRetryHttpStatus(response.status) && attempt < retry.maxAttempts - 1) {
          lastFailure = failure;
          continue;
        }
        return { ok: false, error: failure };
      } catch (error) {
        const failure = mapNetworkError(error);
        console.warn("[xTranslator] LLM request failed before a response", { reason: failure.reason, attempt: attempt + 1 });
        if (mapFailureReason(failure.reason) && attempt < retry.maxAttempts - 1) {
          lastFailure = failure;
          continue;
        }
        return { ok: false, error: failure };
      } finally {
        clearTimeout(timeout);
      }
    }
    return { ok: false, error: lastFailure ?? { reason: "network", message: "Provider request failed." } };
  }
  async function postJsonWithRetry(fetchFn, url, body, headers, retry = HTTP_RETRY) {
    return sendWithRetry(fetchFn, url, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    }, retry);
  }
  async function getWithRetry(fetchFn, url, headers, retry = HTTP_RETRY) {
    return sendWithRetry(fetchFn, url, { method: "GET", headers }, retry);
  }

  // src/shared/providers/sse.ts
  async function readServerSentEvents(response, onEvent) {
    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error("Streaming response has no readable body.");
    }
    const decoder = new TextDecoder();
    let buffer = "";
    let eventName;
    let dataLines = [];
    const dispatch = () => {
      if (dataLines.length > 0) {
        onEvent({
          ...eventName ? { event: eventName } : {},
          data: dataLines.join("\n")
        });
      }
      eventName = void 0;
      dataLines = [];
    };
    const consumeLines = (flush) => {
      if (flush) {
        if (buffer.length > 0) {
          buffer += "\n";
        }
      }
      let lineEnd = buffer.indexOf("\n");
      while (lineEnd >= 0) {
        const line = buffer.slice(0, lineEnd).replace(/\r$/u, "");
        buffer = buffer.slice(lineEnd + 1);
        if (line.length === 0) {
          dispatch();
        } else if (line.startsWith("event:")) {
          eventName = line.slice("event:".length).trim();
        } else if (line.startsWith("data:")) {
          const value = line.slice("data:".length);
          dataLines.push(value.startsWith(" ") ? value.slice(1) : value);
        }
        lineEnd = buffer.indexOf("\n");
      }
    };
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) {
          buffer += decoder.decode();
          consumeLines(true);
          dispatch();
          return;
        }
        buffer += decoder.decode(chunk.value, { stream: true });
        consumeLines(false);
      }
    } finally {
      reader.releaseLock();
    }
  }

  // src/shared/providers/anthropic-messages.ts
  var ANTHROPIC_VERSION = "2023-06-01";
  var BAD_RESPONSE = { reason: "bad-response", message: "Provider returned a malformed response." };
  function isRecord3(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  async function readTextContent(response, endpoint) {
    let payload;
    try {
      payload = JSON.parse(await response.text());
    } catch {
      console.warn("[xTranslator] LLM returned non-JSON completion data", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE } };
    }
    if (!isRecord3(payload) || !Array.isArray(payload.content)) {
      console.warn("[xTranslator] LLM returned a non-Messages payload", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE } };
    }
    const fragments = payload.content.flatMap(
      (block) => isRecord3(block) && typeof block.text === "string" ? [block.text] : []
    );
    const text = fragments.join("").trim();
    return text ? { ok: true, text } : { ok: false, error: { ...BAD_RESPONSE } };
  }
  async function readStreamingTextContent(response, endpoint, onTextDelta) {
    if (!response.headers.get("content-type")?.includes("text/event-stream")) {
      return readTextContent(response, endpoint);
    }
    let text = "";
    try {
      await readServerSentEvents(response, (event) => {
        if (event.event !== "content_block_delta") {
          return;
        }
        const payload = JSON.parse(event.data);
        if (!isRecord3(payload) || !isRecord3(payload.delta) || payload.delta.type !== "text_delta" || typeof payload.delta.text !== "string") {
          return;
        }
        text += payload.delta.text;
        onTextDelta(payload.delta.text);
      });
    } catch {
      console.warn("[xTranslator] LLM streaming response was malformed", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE } };
    }
    const content = text.trim();
    return content ? { ok: true, text: content } : { ok: false, error: { ...BAD_RESPONSE } };
  }
  async function readModelIds(response) {
    let payload;
    try {
      payload = JSON.parse(await response.text());
    } catch {
      return { ok: false, error: { ...BAD_RESPONSE } };
    }
    if (!isRecord3(payload) || !Array.isArray(payload.data)) {
      return { ok: false, error: { ...BAD_RESPONSE } };
    }
    const models = payload.data.map((item) => isRecord3(item) && typeof item.id === "string" ? item.id : null).filter((id) => id !== null && id.length > 0);
    return models.length > 0 ? { ok: true, models } : { ok: false, error: { ...BAD_RESPONSE } };
  }
  function createAnthropicAdapter(preset, fetchFn) {
    const headers = (apiKey) => ({
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": ANTHROPIC_VERSION
    });
    return {
      preset,
      async complete(request, options) {
        const url = `${preset.baseUrl}${preset.requestPath}`;
        const body = {
          ...preset.requestBody ?? {},
          model: options.model,
          system: request.systemPrompt,
          messages: [{ role: "user", content: request.userPrompt }],
          ...options.maxOutputTokens !== void 0 ? { max_tokens: options.maxOutputTokens } : {},
          ...options.temperature !== void 0 ? { temperature: options.temperature } : {}
        };
        const result = await postJsonWithRetry(fetchFn, url, body, headers(options.apiKey));
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        return readTextContent(result.response, url);
      },
      async completeStream(request, options, onTextDelta) {
        const url = `${preset.baseUrl}${preset.requestPath}`;
        const body = {
          ...preset.requestBody ?? {},
          model: options.model,
          system: request.systemPrompt,
          messages: [{ role: "user", content: request.userPrompt }],
          ...options.maxOutputTokens !== void 0 ? { max_tokens: options.maxOutputTokens } : {},
          ...options.temperature !== void 0 ? { temperature: options.temperature } : {},
          stream: true
        };
        const result = await postJsonWithRetry(fetchFn, url, body, headers(options.apiKey));
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        return readStreamingTextContent(result.response, url, onTextDelta);
      },
      async listModels(apiKey) {
        const url = `${preset.baseUrl}${preset.modelsPath}`;
        const result = await getWithRetry(fetchFn, url, headers(apiKey));
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        return readModelIds(result.response);
      }
    };
  }

  // src/shared/providers/openai-compatible.ts
  var BAD_RESPONSE2 = { reason: "bad-response", message: "Provider returned a malformed response." };
  function isRecord4(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  async function readContent(response, endpoint) {
    let payload;
    try {
      payload = JSON.parse(await response.text());
    } catch {
      console.warn("[xTranslator] LLM returned non-JSON completion data", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    if (!isRecord4(payload) || !Array.isArray(payload.choices)) {
      console.warn("[xTranslator] LLM returned a non-Chat-Completions payload", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    const first = payload.choices[0];
    if (!isRecord4(first) || !isRecord4(first.message) || typeof first.message.content !== "string") {
      console.warn("[xTranslator] LLM completion has no text message content", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    const content = first.message.content.trim();
    return content ? { ok: true, text: content } : { ok: false, error: { ...BAD_RESPONSE2 } };
  }
  async function readStreamingContent(response, endpoint, onTextDelta) {
    if (!response.headers.get("content-type")?.includes("text/event-stream")) {
      return readContent(response, endpoint);
    }
    let text = "";
    try {
      await readServerSentEvents(response, (event) => {
        if (event.data === "[DONE]") {
          return;
        }
        const payload = JSON.parse(event.data);
        if (!isRecord4(payload) || !Array.isArray(payload.choices)) {
          return;
        }
        const first = payload.choices[0];
        if (!isRecord4(first) || !isRecord4(first.delta) || typeof first.delta.content !== "string") {
          return;
        }
        text += first.delta.content;
        onTextDelta(first.delta.content);
      });
    } catch {
      console.warn("[xTranslator] LLM streaming response was malformed", { endpoint });
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    const content = text.trim();
    return content ? { ok: true, text: content } : { ok: false, error: { ...BAD_RESPONSE2 } };
  }
  async function readModelIds2(response) {
    let payload;
    try {
      payload = JSON.parse(await response.text());
    } catch {
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    if (!isRecord4(payload) || !Array.isArray(payload.data)) {
      return { ok: false, error: { ...BAD_RESPONSE2 } };
    }
    const models = payload.data.map((item) => isRecord4(item) && typeof item.id === "string" ? item.id : null).filter((id) => id !== null && id.length > 0);
    return models.length > 0 ? { ok: true, models } : { ok: false, error: { ...BAD_RESPONSE2 } };
  }
  function createOpenAiAdapter(preset, fetchFn) {
    const buildBody = (request, options, stream) => ({
      ...preset.requestBody ?? {},
      model: options.model,
      messages: [
        { role: "system", content: request.systemPrompt },
        { role: "user", content: request.userPrompt }
      ],
      ...options.temperature !== void 0 ? { temperature: options.temperature } : {},
      ...options.maxOutputTokens !== void 0 ? { max_tokens: options.maxOutputTokens } : {},
      ...stream ? { stream: true } : {}
    });
    return {
      preset,
      async complete(request, options) {
        const url = `${preset.baseUrl}${preset.requestPath}`;
        const result = await postJsonWithRetry(fetchFn, url, buildBody(request, options, false), {
          "content-type": "application/json",
          authorization: `Bearer ${options.apiKey}`
        });
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        return readContent(result.response, url);
      },
      async completeStream(request, options, onTextDelta) {
        const url = `${preset.baseUrl}${preset.requestPath}`;
        const result = await postJsonWithRetry(fetchFn, url, buildBody(request, options, true), {
          "content-type": "application/json",
          authorization: `Bearer ${options.apiKey}`
        });
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        return readStreamingContent(result.response, url, onTextDelta);
      },
      async listModels(apiKey) {
        if (!preset.modelsPath) {
          return preset.models && preset.models.length > 0 ? { ok: true, models: [...preset.models] } : { ok: false, error: { ...BAD_RESPONSE2 } };
        }
        const url = `${preset.baseUrl}${preset.modelsPath}`;
        const result = await getWithRetry(fetchFn, url, {
          authorization: `Bearer ${apiKey}`
        });
        if (!result.ok) {
          return { ok: false, error: result.error };
        }
        const listed = await readModelIds2(result.response);
        return listed;
      }
    };
  }

  // src/shared/providers/provider-registry.ts
  var PROVIDER_PRESETS = [
    {
      id: "deepseek",
      displayName: "DeepSeek",
      apiKeyUrl: "https://platform.deepseek.com/api_keys",
      kind: "openai-compatible",
      baseUrl: "https://api.deepseek.com",
      modelLimits: {
        "deepseek-v4-flash": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 },
        "deepseek-v4-pro": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 }
      },
      requestBody: { thinking: { type: "disabled" } },
      requestPath: "/chat/completions",
      modelsPath: "/models"
    },
    {
      id: "openai",
      displayName: "OpenAI",
      apiKeyUrl: "https://platform.openai.com/api-keys",
      kind: "openai-compatible",
      baseUrl: "https://api.openai.com",
      modelLimits: {
        "gpt-4o-mini": { contextWindowTokens: 128e3, maxOutputTokens: 16384 },
        "gpt-4o": { contextWindowTokens: 128e3, maxOutputTokens: 16384 }
      },
      requestPath: "/v1/chat/completions",
      modelsPath: "/v1/models"
    },
    {
      id: "anthropic",
      displayName: "Anthropic",
      apiKeyUrl: "https://platform.claude.com/settings/keys",
      kind: "anthropic-messages",
      baseUrl: "https://api.anthropic.com",
      modelLimits: {
        "claude-haiku-4-5-20251001": { contextWindowTokens: 2e5, maxOutputTokens: 64e3 },
        "claude-sonnet-5": { contextWindowTokens: 1e6, maxOutputTokens: 128e3 }
      },
      requestPath: "/v1/messages",
      modelsPath: "/v1/models"
    },
    {
      id: "agnes",
      displayName: "Agnes AI",
      apiKeyUrl: "https://platform.agnes-ai.com/settings/apiKeys",
      kind: "openai-compatible",
      baseUrl: "https://apihub.agnes-ai.com/v1",
      models: ["agnes-2.5-flash"],
      modelLimits: {
        "agnes-2.5-flash": { contextWindowTokens: 512e3, maxOutputTokens: 65536 }
      },
      requestPath: "/chat/completions"
    }
  ];
  function getProviderPreset(id) {
    return PROVIDER_PRESETS.find((preset) => preset.id === id) ?? null;
  }
  function listProviderPresets() {
    return PROVIDER_PRESETS;
  }
  function createProviderAdapter(preset, fetchFn) {
    return createAdapterForKind(preset.kind, preset, fetchFn);
  }
  function createAdapterForKind(kind, preset, fetchFn) {
    if (kind === "anthropic-messages") {
      return createAnthropicAdapter(preset, fetchFn);
    }
    return createOpenAiAdapter(preset, fetchFn);
  }

  // src/shared/storage/settings-repository.ts
  var SETTINGS_STORAGE_KEY = "settings";
  var SettingsRepository = class {
    constructor(storageArea) {
      this.storageArea = storageArea;
    }
    async loadSettings() {
      const stored = await this.storageArea.get(SETTINGS_STORAGE_KEY);
      return parseExtensionSettings(stored[SETTINGS_STORAGE_KEY]) ?? { ...DEFAULT_SETTINGS };
    }
    async saveSettings(settings) {
      await this.storageArea.set({ [SETTINGS_STORAGE_KEY]: settings });
    }
  };
  function createChromeSettingsRepository() {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      throw new Error("xTranslator settings are only available inside Chrome.");
    }
    return new SettingsRepository(chrome.storage.local);
  }

  // src/shared/extension-update.ts
  var UPDATE_MANIFEST_URL = "https://cdn.jsdelivr.net/gh/LZKDreamer/xTranslator@latest/public/updates/latest.json";
  function parseVersion(version) {
    const parts = version.split(".");
    if (parts.length === 0 || parts.length > 4 || parts.some((part) => !/^(?:0|[1-9]\d{0,4})$/u.test(part))) {
      return null;
    }
    const values = parts.map(Number);
    return values.every((part) => part <= 65535) ? values : null;
  }
  function compareExtensionVersions(left, right) {
    const leftParts = parseVersion(left);
    const rightParts = parseVersion(right);
    if (!leftParts || !rightParts) {
      return null;
    }
    for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
      const difference = (leftParts[index] ?? 0) - (rightParts[index] ?? 0);
      if (difference !== 0) {
        return difference;
      }
    }
    return 0;
  }
  function getAvailableUpdate(value, installedVersion) {
    if (!value || typeof value !== "object") {
      return null;
    }
    const { version, downloadUrl } = value;
    if (typeof version !== "string" || typeof downloadUrl !== "string") {
      return null;
    }
    let url;
    try {
      url = new URL(downloadUrl);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" || url.hostname !== "cdn.jsdelivr.net" || !url.pathname.startsWith("/gh/LZKDreamer/xTranslator@v") || !url.pathname.endsWith(".zip")) {
      return null;
    }
    const comparison = compareExtensionVersions(version, installedVersion);
    return comparison !== null && comparison > 0 ? { version, downloadUrl } : null;
  }
  async function checkForExtensionUpdate(installedVersion, request = fetch) {
    try {
      const response = await request(UPDATE_MANIFEST_URL, { cache: "no-store" });
      if (!response.ok) {
        return { state: "unavailable" };
      }
      const update = getAvailableUpdate(await response.json(), installedVersion);
      return update ? { state: "available", update } : { state: "up-to-date" };
    } catch {
      return { state: "unavailable" };
    }
  }

  // src/shared/i18n/index.ts
  var en = {
    "popup.openSettings": "Open settings",
    "popup.translationLanguage": "Translation language",
    "popup.followBrowserLanguage": "Follow browser language",
    "popup.translationEngine": "Translation engine",
    "popup.loading": "Loading\u2026",
    "popup.watchStatus": "Viewing status",
    "popup.readyToTranslate": "Ready to translate",
    "popup.openYoutubeVideo": "Open a YouTube video and click the xTranslator button in the player.",
    "popup.connected": "Connected to {name}{model}",
    "popup.notConnected": "No translation service is connected. Open settings to connect one.",
    "popup.updateAvailable": "Update available",
    "popup.updateDetail": "Version {version} is ready to download.",
    "popup.downloadUpdate": "Download update",
    "popup.browserLanguage": "Follow browser language \xB7 {language}",
    "popup.preparingCaptions": "Preparing captions\u2026",
    "popup.captionsReady": "Captions are ready. Translation will begin shortly.",
    "popup.translatingCaptions": "Translating {count} caption segments\u2026",
    "popup.noTranslationNeeded": "The captions are already in the target language.",
    "popup.translationComplete": "Translation complete \xB7 {translated}/{total} caption segments",
    "popup.videoUnavailable": "This video cannot be translated right now. Please try again later.",
    "popup.statusUnavailable": "Video translation status is temporarily unavailable.",
    "options.title": "xTranslator Preferences",
    "options.preferences": "Preferences",
    "options.versionUpdate": "Version update",
    "options.currentVersion": "Current version",
    "options.latestVersion": "Latest version",
    "options.updateChecking": "Checking for updates\u2026",
    "options.updateAvailable": "Version {version} is ready to download.",
    "options.updateUpToDate": "You have the latest version.",
    "options.updateUnavailable": "Updates cannot be checked right now. Please try again later.",
    "options.downloadUpdate": "Download update",
    "options.translationService": "Translation service",
    "options.serviceHelp": "Enter a service key and load a model. Your settings are saved automatically when all three fields are complete.",
    "options.setupSteps": "Translation service setup",
    "options.stepProvider": "Provider",
    "options.stepApiKey": "API Key",
    "options.stepModel": "Model",
    "options.stepComplete": "Complete",
    "options.stepCurrent": "Current step",
    "options.stepNeedsApiKey": "Enter key",
    "options.stepNeedsModel": "Load a model",
    "options.serviceKey": "Service key (API Key)",
    "options.keyHelp": "Your key is stored only on this device and is used to connect to the selected translation service.",
    "options.createApiKey": "Create a {name} API key",
    "options.loadModels": "Load models",
    "options.translationModel": "Translation model",
    "options.subtitleDisplay": "Caption display",
    "options.subtitlePreview": "Live preview",
    "options.previewPlayer": "Player",
    "options.previewTranslation": "The answer is already in the details.",
    "options.previewOriginal": "\u7B54\u6848\u5C31\u5728\u7EC6\u8282\u91CC\u3002",
    "options.captionMode": "Caption mode",
    "options.originalOnly": "Original only",
    "options.translationOnly": "Translation only",
    "options.bilingual": "Original + translation",
    "options.captionModeHelp": "Choose how captions appear in videos. Changes apply to the current video immediately.",
    "options.enableShortsTranslation": "Enable Shorts translation",
    "options.shortsTranslationHelp": "When disabled, the translation button is hidden in Shorts. Comment translation remains available.",
    "options.subtitleStyle": "Caption style",
    "options.translationColor": "Translation color",
    "options.originalColor": "Original color",
    "options.translationFontSize": "Translation size",
    "options.originalFontSize": "Original size",
    "options.captionPositionHelp": "Drag captions vertically in the player to avoid important content. Their position and style are saved automatically.",
    "options.resetCaptionStyle": "Restore default caption style and position",
    "options.pageTranslation": "Page translation",
    "options.viewTranslation": "Viewing-page translation",
    "options.autoTranslateTitle": "Automatically translate video titles",
    "options.autoTranslateTitleHelp": "Shows the original title immediately, then displays its translation below when ready.",
    "options.selectionTranslation": "Selection translation",
    "options.enableSelectionTranslation": "Enable selection translation",
    "options.selectionDisabledHelp": "When disabled, selecting text will not show the translation panel and the context menu will not start a translation.",
    "options.includeContext": "Use surrounding context when translating selected text",
    "options.includeContextHelp": "When enabled, the surrounding sentences help produce a more natural translation.",
    "options.translationHistory": "Translation history",
    "options.dataMaintenance": "Data & maintenance",
    "options.historyHelp": "Recent entries are shown first. Open the full list when needed.",
    "options.historyCount": "{count} entries",
    "options.viewAllHistory": "View all {count} entries",
    "options.showRecentHistory": "Show recent entries",
    "options.emptyHistory": "No translation history has been saved.",
    "options.reload": "Reload",
    "options.clearHistory": "Clear history",
    "options.confirmClearHistory": "Clear all saved translation history? This cannot be undone.",
    "options.unknownService": "The selected translation service is not recognized.",
    "options.enterApiKey": "Enter an API key to load models.",
    "options.findingModels": "Finding available models\u2026",
    "options.modelsFound": "Found {count} available models.",
    "options.modelsFoundEnterKey": "Found {count} models. Enter an API key before saving.",
    "options.noModels": "No models are available.",
    "options.modelsUnavailable": "The model list is temporarily unavailable. Check your network connection or service key.",
    "options.historyUnavailable": "Translation history is temporarily unavailable.",
    "options.historyStats": "{count} saved entries \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} segments \xB7 {date}",
    "options.delete": "Delete",
    "options.deleteHistoryEntry": "Delete the translation history for {title}",
    "options.deleteFailed": "This history entry could not be deleted. Please try again later.",
    "options.saving": "Saving settings\u2026",
    "options.saved": "Settings saved.",
    "options.saveFailed": "Settings could not be saved. Please try again later.",
    "options.preferencesSaveFailed": "Preferences could not be saved. Please try again later.",
    "options.apiKeyChanged": "The API key changed. Click Load models.",
    "options.loadingConfiguredModels": "Loading configured models\u2026",
    "options.clearFailed": "Translation history could not be cleared. Please try again later.",
    "options.captionStyleRestored": "Default caption style and automatic position restored.",
    "options.loadFailed": "Preferences are temporarily unavailable. Refresh and try again.",
    "content.pageUnsupported": "This YouTube page is not supported.",
    "content.captionHttp": "The caption link has expired or is temporarily unavailable. Please try again.",
    "content.captionNetwork": "Captions could not be read. Check your network connection and try again.",
    "content.captionUnsupported": "This caption format is not supported yet. Please try again later.",
    "content.partialTranslation": "Translation is incomplete. Some captions are ready; click to continue.",
    "content.startTranslation": "Start translation",
    "content.cacheLoaded": "Loaded cached translation: {count} segments",
    "content.translateAgain": "Translate again",
    "content.translating": "Translating",
    "content.readingCache": "Reading cached translation\u2026",
    "content.noCaptionsOrCache": "This video has no available captions or local translation cache.",
    "content.retryCaptions": "Retry captions",
    "content.readingCaptions": "Reading captions\u2026",
    "content.translatingSegments": "Translating {count} segments\u2026",
    "content.translatingProgress": "Translating {translated}/{total}\u2026",
    "content.noTranslationNeeded": "The captions are already in the target language.",
    "content.noTranslation": "No translation needed",
    "content.translationComplete": "Translation complete: {count} segments",
    "content.translationCompleteProgress": "Translation complete {translated}/{total}",
    "content.continueTranslation": "Continue translation",
    "content.partialTranslationProgress": "{translated}/{total} translated \xB7 {missing} remaining. Click to continue.",
    "content.retry": "Retry",
    "content.serviceUnavailable": "The translation service could not be reached. Check extension settings and try again.",
    "content.captionPosition": "Drag up or down to adjust caption position",
    "content.translatingTitle": "Translating title\u2026",
    "content.titleTranslationFailed": "Title translation failed.",
    "content.retryTitleTranslation": "Retry",
    "content.translateDescription": "Translate description",
    "content.descriptionActionAria": "xTranslator: {action}",
    "content.translatingDescription": "Translating description\u2026",
    "content.descriptionTranslation": "Translation",
    "content.descriptionTranslationFailed": "Description translation failed. Click to retry.",
    "content.hideDescriptionTranslation": "Hide translation",
    "content.showDescriptionTranslation": "Show translation",
    "comment.translateVisible": "Translate {count} visible comments",
    "comment.translateVisiblePrefix": "Translate",
    "comment.translateVisibleAria": "Translate {count} currently visible comments",
    "comment.translateThread": "Translate this thread ({count})",
    "comment.translateThreadAria": "Translate this thread ({count})",
    "comment.translatedVisible": "Translated {count} comments",
    "comment.translatedThread": "Translated thread ({count})",
    "comment.noExpandedReplies": "No expanded replies found",
    "comment.noTranslatableComments": "No translatable comments found",
    "comment.translating": "Translating\u2026",
    "comment.translatingProgress": "Translating {completed}/{total}\u2026",
    "comment.retryIncomplete": "Retry incomplete translations",
    "comment.retryIncompleteCount": "Retry incomplete ({count})",
    "comment.translationFailedRetry": "Translation failed. Click to retry",
    "comment.retryComment": "Retry translation for comment: {id}",
    "comment.retried": "Retried",
    "selection.toolbar": "Selection translation",
    "selection.translate": "Translate",
    "selection.translateAria": "Translate selected text",
    "selection.copyAria": "Copy selected text",
    "selection.closeAria": "Close selection panel",
    "selection.translating": "Translating\u2026",
    "selection.failed": "Translation failed. Please try again.",
    "selection.copyTranslationAria": "Copy translation",
    "selection.cancelAria": "Cancel translation",
    "selection.closeTranslationAria": "Close translation panel",
    "background.notConnected": "No translation service is connected. Complete preferences first.",
    "background.unknownService": "The translation service is not recognized: {id}",
    "background.noModel": "No translation model is selected. Open settings, load models, and select one.",
    "background.contextMenu": "Translate selected text",
    "background.videoFailed": "Video translation failed. Please try again.",
    "background.translationFailed": "Translation failed. Please try again.",
    "translation.missingCaptions": "{count} caption segments did not receive a valid translation. Completed segments were saved; please try again.",
    "provider.auth": "The service key is invalid or lacks permission. Check it in Preferences.",
    "provider.rateLimit": "The translation service is busy. Please try again later.",
    "provider.timeout": "The translation request timed out. Please try again.",
    "provider.network": "The translation service could not be reached. Check your network connection and try again.",
    "provider.model": "The selected model is unavailable. Choose another model in Preferences.",
    "provider.badResponse": "The translation service is temporarily unavailable. Please try again later."
  };
  var zhCN = {
    "popup.openSettings": "\u6253\u5F00\u8BBE\u7F6E",
    "popup.translationLanguage": "\u7FFB\u8BD1\u8BED\u8A00",
    "popup.followBrowserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00",
    "popup.translationEngine": "\u7FFB\u8BD1\u5F15\u64CE",
    "popup.loading": "\u52A0\u8F7D\u4E2D\u2026",
    "popup.watchStatus": "\u89C2\u770B\u72B6\u6001",
    "popup.readyToTranslate": "\u51C6\u5907\u597D\u5F00\u59CB\u7FFB\u8BD1",
    "popup.openYoutubeVideo": "\u6253\u5F00 YouTube \u89C6\u9891\uFF0C\u70B9\u51FB\u64AD\u653E\u5668\u4E2D\u7684 xTranslator \u6309\u94AE\u3002",
    "popup.connected": "\u5DF2\u8FDE\u63A5 {name}{model}",
    "popup.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E\u5B8C\u6210\u8FDE\u63A5\u3002",
    "popup.updateAvailable": "\u53D1\u73B0\u65B0\u7248\u672C",
    "popup.updateDetail": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "popup.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "popup.browserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00 \xB7 {language}",
    "popup.preparingCaptions": "\u6B63\u5728\u51C6\u5907\u5B57\u5E55\u2026",
    "popup.captionsReady": "\u5B57\u5E55\u5DF2\u51C6\u5907\u597D\uFF0C\u9A6C\u4E0A\u5F00\u59CB\u7FFB\u8BD1\u3002",
    "popup.translatingCaptions": "\u6B63\u5728\u7FFB\u8BD1 {count} \u5904\u5B57\u5E55\u2026",
    "popup.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "popup.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210 \xB7 {translated}/{total} \u5904\u5B57\u5E55",
    "popup.videoUnavailable": "\u8FD9\u6BB5\u89C6\u9891\u6682\u65F6\u65E0\u6CD5\u7FFB\u8BD1\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "popup.statusUnavailable": "\u89C6\u9891\u7FFB\u8BD1\u72B6\u6001\u6682\u65F6\u4E0D\u53EF\u7528\u3002",
    "options.title": "xTranslator \u504F\u597D\u8BBE\u7F6E",
    "options.preferences": "\u504F\u597D\u8BBE\u7F6E",
    "options.versionUpdate": "\u7248\u672C\u66F4\u65B0",
    "options.currentVersion": "\u5F53\u524D\u7248\u672C",
    "options.latestVersion": "\u6700\u65B0\u7248\u672C",
    "options.updateChecking": "\u6B63\u5728\u68C0\u67E5\u66F4\u65B0\u2026",
    "options.updateAvailable": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "options.updateUpToDate": "\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\u672C\u3002",
    "options.updateUnavailable": "\u6682\u65F6\u65E0\u6CD5\u68C0\u67E5\u66F4\u65B0\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "options.translationService": "\u7FFB\u8BD1\u670D\u52A1",
    "options.serviceHelp": "\u586B\u5199\u670D\u52A1\u5BC6\u94A5\u5E76\u52A0\u8F7D\u6A21\u578B\uFF0C\u4E09\u9879\u914D\u7F6E\u5B8C\u6574\u540E\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.setupSteps": "\u7FFB\u8BD1\u670D\u52A1\u914D\u7F6E\u6B65\u9AA4",
    "options.stepProvider": "\u670D\u52A1\u5546",
    "options.stepApiKey": "API Key",
    "options.stepModel": "\u6A21\u578B",
    "options.stepComplete": "\u5DF2\u5B8C\u6210",
    "options.stepCurrent": "\u5F53\u524D\u6B65\u9AA4",
    "options.stepNeedsApiKey": "\u8BF7\u586B\u5199\u5BC6\u94A5",
    "options.stepNeedsModel": "\u8BF7\u52A0\u8F7D\u6A21\u578B",
    "options.serviceKey": "\u670D\u52A1\u5BC6\u94A5\uFF08API Key\uFF09",
    "options.keyHelp": "\u5BC6\u94A5\u53EA\u4FDD\u5B58\u5728\u672C\u673A\uFF0C\u7528\u4E8E\u8FDE\u63A5\u4F60\u9009\u62E9\u7684\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.createApiKey": "\u524D\u5F80 {name} \u521B\u5EFA API Key",
    "options.loadModels": "\u52A0\u8F7D\u6A21\u578B",
    "options.translationModel": "\u7FFB\u8BD1\u6A21\u578B",
    "options.subtitleDisplay": "\u5B57\u5E55\u663E\u793A",
    "options.subtitlePreview": "\u5373\u65F6\u9884\u89C8",
    "options.previewPlayer": "\u64AD\u653E\u5668",
    "options.previewTranslation": "\u7B54\u6848\u5DF2\u7ECF\u5728\u7EC6\u8282\u91CC\u3002",
    "options.previewOriginal": "The answer is already in the details.",
    "options.captionMode": "\u5B57\u5E55\u6A21\u5F0F",
    "options.originalOnly": "\u4EC5\u663E\u793A\u539F\u6587",
    "options.translationOnly": "\u4EC5\u663E\u793A\u8BD1\u6587",
    "options.bilingual": "\u539F\u6587 + \u8BD1\u6587",
    "options.captionModeHelp": "\u9009\u62E9\u89C6\u9891\u4E2D\u7684\u5B57\u5E55\u5448\u73B0\u65B9\u5F0F\uFF0C\u4FDD\u5B58\u540E\u4F1A\u7ACB\u5373\u5E94\u7528\u5230\u6B63\u5728\u64AD\u653E\u7684\u89C6\u9891\u3002",
    "options.enableShortsTranslation": "\u542F\u7528 Shorts \u7FFB\u8BD1",
    "options.shortsTranslationHelp": "\u5173\u95ED\u540E\uFF0CShorts \u64AD\u653E\u5668\u4E2D\u4E0D\u663E\u793A\u7FFB\u8BD1\u6309\u94AE\uFF1B\u8BC4\u8BBA\u7FFB\u8BD1\u4E0D\u53D7\u5F71\u54CD\u3002",
    "options.subtitleStyle": "\u5B57\u5E55\u6837\u5F0F",
    "options.translationColor": "\u8BD1\u6587\u989C\u8272",
    "options.originalColor": "\u539F\u6587\u989C\u8272",
    "options.translationFontSize": "\u8BD1\u6587\u5B57\u53F7",
    "options.originalFontSize": "\u539F\u6587\u5B57\u53F7",
    "options.captionPositionHelp": "\u5B57\u5E55\u5728\u64AD\u653E\u5668\u5185\u53EF\u4E0A\u4E0B\u62D6\u52A8\u4EE5\u907F\u5F00\u753B\u9762\u5185\u5BB9\uFF1B\u4F4D\u7F6E\u548C\u6837\u5F0F\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.resetCaptionStyle": "\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u4F4D\u7F6E",
    "options.pageTranslation": "\u9875\u9762\u7FFB\u8BD1",
    "options.viewTranslation": "\u89C2\u770B\u9875\u7FFB\u8BD1\u529F\u80FD",
    "options.autoTranslateTitle": "\u81EA\u52A8\u7FFB\u8BD1\u89C6\u9891\u6807\u9898",
    "options.autoTranslateTitleHelp": "\u539F\u6807\u9898\u4F1A\u7ACB\u5373\u663E\u793A\uFF0C\u8BD1\u6587\u51C6\u5907\u597D\u540E\u4F1A\u663E\u793A\u5728\u4E0B\u65B9\u3002",
    "options.selectionTranslation": "\u5212\u8BCD\u7FFB\u8BD1",
    "options.enableSelectionTranslation": "\u542F\u7528\u5212\u8BCD\u7FFB\u8BD1",
    "options.selectionDisabledHelp": "\u5173\u95ED\u540E\uFF0C\u9009\u4E2D\u6587\u5B57\u4E0D\u4F1A\u663E\u793A\u7FFB\u8BD1\u6D6E\u5C42\uFF0C\u53F3\u952E\u83DC\u5355\u4E5F\u4E0D\u4F1A\u89E6\u53D1\u5212\u8BCD\u7FFB\u8BD1\u3002",
    "options.includeContext": "\u7FFB\u8BD1\u9009\u4E2D\u6587\u672C\u65F6\u53C2\u8003\u524D\u540E\u6587",
    "options.includeContextHelp": "\u5F00\u542F\u540E\u4F1A\u7ED3\u5408\u524D\u540E\u53E5\uFF0C\u8BA9\u7FFB\u8BD1\u66F4\u8D34\u5408\u8BED\u5883\u3002",
    "options.translationHistory": "\u7FFB\u8BD1\u8BB0\u5F55",
    "options.dataMaintenance": "\u6570\u636E\u4E0E\u7EF4\u62A4",
    "options.historyHelp": "\u6700\u8FD1\u8BB0\u5F55\u4F18\u5148\u663E\u793A\uFF0C\u9700\u8981\u65F6\u518D\u5C55\u5F00\u5B8C\u6574\u5217\u8868\u3002",
    "options.historyCount": "{count} \u6761\u8BB0\u5F55",
    "options.viewAllHistory": "\u67E5\u770B\u5168\u90E8 {count} \u6761\u8BB0\u5F55",
    "options.showRecentHistory": "\u53EA\u770B\u6700\u8FD1\u8BB0\u5F55",
    "options.emptyHistory": "\u8FD8\u6CA1\u6709\u4FDD\u5B58\u7684\u7FFB\u8BD1\u8BB0\u5F55\u3002",
    "options.reload": "\u91CD\u65B0\u52A0\u8F7D",
    "options.clearHistory": "\u6E05\u7A7A\u8BB0\u5F55",
    "options.confirmClearHistory": "\u786E\u5B9A\u8981\u6E05\u7A7A\u5168\u90E8\u7FFB\u8BD1\u8BB0\u5F55\u5417\uFF1F\u6B64\u64CD\u4F5C\u65E0\u6CD5\u64A4\u9500\u3002",
    "options.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u8BE5\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.enterApiKey": "\u8BF7\u586B\u5199 API Key \u540E\u52A0\u8F7D\u6A21\u578B\u3002",
    "options.findingModels": "\u6B63\u5728\u67E5\u627E\u53EF\u7528\u6A21\u578B\u2026",
    "options.modelsFound": "\u627E\u5230 {count} \u4E2A\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsFoundEnterKey": "\u627E\u5230 {count} \u4E2A\u6A21\u578B\uFF0C\u8BF7\u586B\u5199 API Key \u540E\u4FDD\u5B58\u3002",
    "options.noModels": "\u6CA1\u6709\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsUnavailable": "\u6A21\u578B\u5217\u8868\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u670D\u52A1\u5BC6\u94A5\u3002",
    "options.historyUnavailable": "\u7FFB\u8BD1\u8BB0\u5F55\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002",
    "options.historyStats": "\u5DF2\u4FDD\u5B58 {count} \u6761\u8BB0\u5F55 \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} \u6BB5 \xB7 {date}",
    "options.delete": "\u5220\u9664",
    "options.deleteHistoryEntry": "\u5220\u9664 {title} \u7684\u7FFB\u8BD1\u8BB0\u5F55",
    "options.deleteFailed": "\u5220\u9664\u8FD9\u6761\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.saving": "\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\u2026",
    "options.saved": "\u914D\u7F6E\u5DF2\u4FDD\u5B58\u3002",
    "options.saveFailed": "\u914D\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.preferencesSaveFailed": "\u504F\u597D\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.apiKeyChanged": "API Key \u5DF2\u53D8\u5316\uFF0C\u8BF7\u70B9\u51FB\u201C\u52A0\u8F7D\u6A21\u578B\u201D\u3002",
    "options.loadingConfiguredModels": "\u6B63\u5728\u52A0\u8F7D\u5DF2\u914D\u7F6E\u6A21\u578B\u2026",
    "options.clearFailed": "\u6E05\u7A7A\u7FFB\u8BD1\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.captionStyleRestored": "\u5DF2\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u81EA\u52A8\u4F4D\u7F6E\u3002",
    "options.loadFailed": "\u504F\u597D\u8BBE\u7F6E\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5\u3002",
    "content.pageUnsupported": "\u5F53\u524D YouTube \u9875\u9762\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\u3002",
    "content.captionHttp": "\u5B57\u5E55\u94FE\u63A5\u5DF2\u5931\u6548\u6216\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "content.captionNetwork": "\u65E0\u6CD5\u8BFB\u53D6\u5B57\u5E55\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
    "content.captionUnsupported": "\u5F53\u524D\u5B57\u5E55\u683C\u5F0F\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "content.partialTranslation": "\u7FFB\u8BD1\u672A\u5B8C\u6210\uFF0C\u90E8\u5206\u5B57\u5E55\u5DF2\u5B8C\u6210\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.startTranslation": "\u5F00\u59CB\u7FFB\u8BD1",
    "content.cacheLoaded": "\u5DF2\u52A0\u8F7D\u7F13\u5B58\uFF1A{count} \u6BB5",
    "content.translateAgain": "\u518D\u6B21\u7FFB\u8BD1",
    "content.translating": "\u7FFB\u8BD1\u4E2D",
    "content.readingCache": "\u6B63\u5728\u8BFB\u53D6\u7F13\u5B58\u2026",
    "content.noCaptionsOrCache": "\u5F53\u524D\u89C6\u9891\u6CA1\u6709\u53EF\u7528\u5B57\u5E55\uFF0C\u4E14\u6CA1\u6709\u672C\u5730\u7FFB\u8BD1\u7F13\u5B58\u3002",
    "content.retryCaptions": "\u91CD\u8BD5\u5B57\u5E55",
    "content.readingCaptions": "\u6B63\u5728\u8BFB\u53D6\u5B57\u5E55\u2026",
    "content.translatingSegments": "\u6B63\u5728\u7FFB\u8BD1 {count} \u6BB5\u2026",
    "content.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {translated}/{total}\u2026",
    "content.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "content.noTranslation": "\u65E0\u9700\u7FFB\u8BD1",
    "content.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210\uFF1A{count} \u6BB5",
    "content.translationCompleteProgress": "\u7FFB\u8BD1\u5B8C\u6210 {translated}/{total}",
    "content.continueTranslation": "\u7EE7\u7EED\u7FFB\u8BD1",
    "content.partialTranslationProgress": "\u5DF2\u5B8C\u6210 {translated}/{total}\uFF0C\u5269\u4F59 {missing} \u9879\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.retry": "\u91CD\u8BD5",
    "content.serviceUnavailable": "\u65E0\u6CD5\u8FDE\u63A5\u5230\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u8BBE\u7F6E\u540E\u91CD\u8BD5\u3002",
    "content.captionPosition": "\u4E0A\u4E0B\u62D6\u52A8\u53EF\u8C03\u6574\u5B57\u5E55\u4F4D\u7F6E",
    "content.translatingTitle": "\u6B63\u5728\u7FFB\u8BD1\u6807\u9898\u2026",
    "content.titleTranslationFailed": "\u6807\u9898\u7FFB\u8BD1\u5931\u8D25\u3002",
    "content.retryTitleTranslation": "\u91CD\u8BD5",
    "content.translateDescription": "\u7FFB\u8BD1\u7B80\u4ECB",
    "content.descriptionActionAria": "xTranslator\uFF1A{action}",
    "content.translatingDescription": "\u6B63\u5728\u7FFB\u8BD1\u7B80\u4ECB\u2026",
    "content.descriptionTranslation": "\u8BD1\u6587",
    "content.descriptionTranslationFailed": "\u7B80\u4ECB\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5\u3002",
    "content.hideDescriptionTranslation": "\u6536\u8D77\u8BD1\u6587",
    "content.showDescriptionTranslation": "\u663E\u793A\u8BD1\u6587",
    "comment.translateVisible": "\u7FFB\u8BD1\u53EF\u89C1\u7684 {count} \u6761",
    "comment.translateVisiblePrefix": "\u7FFB\u8BD1\u53EF\u89C1\u7684",
    "comment.translateVisibleAria": "\u7FFB\u8BD1\u5F53\u524D\u53EF\u89C1\u7684 {count} \u6761\u8BC4\u8BBA",
    "comment.translateThread": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translateThreadAria": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translatedVisible": "\u5DF2\u7FFB\u8BD1 {count} \u6761\u8BC4\u8BBA",
    "comment.translatedThread": "\u5DF2\u7FFB\u8BD1\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.noExpandedReplies": "\u672A\u53D1\u73B0\u5DF2\u5C55\u5F00\u56DE\u590D",
    "comment.noTranslatableComments": "\u672A\u53D1\u73B0\u53EF\u8BD1\u8BC4\u8BBA",
    "comment.translating": "\u7FFB\u8BD1\u4E2D\u2026",
    "comment.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {completed}/{total}\u2026",
    "comment.retryIncomplete": "\u91CD\u8BD5\u672A\u5B8C\u6210\u7FFB\u8BD1",
    "comment.retryIncompleteCount": "\u91CD\u8BD5\u672A\u5B8C\u6210\uFF08{count}\uFF09",
    "comment.translationFailedRetry": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5",
    "comment.retryComment": "\u91CD\u8BD5\u7FFB\u8BD1\u8BC4\u8BBA\uFF1A{id}",
    "comment.retried": "\u5DF2\u91CD\u8BD5",
    "selection.toolbar": "\u5212\u8BCD\u7FFB\u8BD1",
    "selection.translate": "\u7FFB\u8BD1",
    "selection.translateAria": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "selection.copyAria": "\u590D\u5236\u6240\u9009\u6587\u672C",
    "selection.closeAria": "\u5173\u95ED\u5212\u8BCD\u6D6E\u5C42",
    "selection.translating": "\u6B63\u5728\u7FFB\u8BD1\u2026",
    "selection.failed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "selection.copyTranslationAria": "\u590D\u5236\u8BD1\u6587",
    "selection.cancelAria": "\u53D6\u6D88\u7FFB\u8BD1",
    "selection.closeTranslationAria": "\u5173\u95ED\u8BD1\u6587\u9762\u677F",
    "background.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u5148\u5B8C\u6210\u504F\u597D\u8BBE\u7F6E\u3002",
    "background.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u7FFB\u8BD1\u670D\u52A1\uFF1A{id}",
    "background.noModel": "\u5C1A\u672A\u9009\u62E9\u7FFB\u8BD1\u6A21\u578B\uFF0C\u8BF7\u5148\u6253\u5F00\u8BBE\u7F6E\u52A0\u8F7D\u5E76\u9009\u62E9\u6A21\u578B\u3002",
    "background.contextMenu": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "background.videoFailed": "\u89C6\u9891\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "background.translationFailed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "translation.missingCaptions": "{count} \u6BB5\u5B57\u5E55\u6CA1\u6709\u83B7\u5F97\u6709\u6548\u8BD1\u6587\uFF0C\u5DF2\u4FDD\u5B58\u5DF2\u5B8C\u6210\u90E8\u5206\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.auth": "\u670D\u52A1\u5BC6\u94A5\u65E0\u6548\u6216\u6743\u9650\u4E0D\u8DB3\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u68C0\u67E5\u3002",
    "provider.rateLimit": "\u7FFB\u8BD1\u670D\u52A1\u5F53\u524D\u8F83\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "provider.timeout": "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.network": "\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u518D\u8BD5\u3002",
    "provider.model": "\u5F53\u524D\u6A21\u578B\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u66F4\u6362\u6A21\u578B\u3002",
    "provider.badResponse": "\u7FFB\u8BD1\u670D\u52A1\u6682\u65F6\u5F02\u5E38\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002"
  };
  var messages = { en, "zh-CN": zhCN };
  function getUiLocale(language = typeof navigator === "undefined" ? "" : navigator.language) {
    try {
      const locale = new Intl.Locale(language).maximize();
      return locale.language === "zh" && locale.script === "Hans" ? "zh-CN" : "en";
    } catch {
      return language.toLowerCase() === "zh-cn" ? "zh-CN" : "en";
    }
  }
  function translate(locale, key, values = {}) {
    return messages[locale][key].replace(/\{(\w+)\}/gu, (placeholder, name) => {
      const value = values[name];
      return value === void 0 ? placeholder : String(value);
    });
  }
  function t(key, values = {}) {
    return translate(getUiLocale(), key, values);
  }
  function translateAttribute(key) {
    return key in en ? t(key) : null;
  }
  function localizeDocument(documentNode) {
    documentNode.documentElement.lang = getUiLocale();
    documentNode.querySelectorAll("[data-i18n]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18n ?? "");
      if (translated !== null) {
        element.textContent = translated;
      }
    });
    documentNode.querySelectorAll("[data-i18n-aria-label]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18nAriaLabel ?? "");
      if (translated !== null) {
        element.setAttribute("aria-label", translated);
      }
    });
    documentNode.querySelectorAll("[data-i18n-title]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18nTitle ?? "");
      if (translated !== null) {
        element.setAttribute("title", translated);
      }
    });
    const title = documentNode.querySelector("title[data-i18n]");
    if (title) {
      documentNode.title = title.textContent ?? documentNode.title;
    }
  }

  // src/options/index.ts
  function queryRequired(selector) {
    const element = document.querySelector(selector);
    if (!element) {
      throw new Error(`Missing options element: ${selector}`);
    }
    return element;
  }
  function showToast(message, tone = "info") {
    const container = queryRequired("#toast-container");
    const toast = document.createElement("div");
    toast.className = `toast toast-${tone}`;
    toast.textContent = message;
    container.append(toast);
    window.setTimeout(() => toast.remove(), 3200);
  }
  function formatBytes(bytes) {
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  function formatDate(value) {
    return new Date(value).toLocaleString(getUiLocale());
  }
  function populateProviders(selectedId) {
    const select = queryRequired("#provider-id");
    select.replaceChildren();
    for (const preset of listProviderPresets()) {
      const option = document.createElement("option");
      option.value = preset.id;
      option.textContent = preset.displayName;
      if (preset.id === selectedId) {
        option.selected = true;
      }
      select.append(option);
    }
  }
  function updateCreateApiKeyLink(providerId) {
    const link = queryRequired("#create-api-key");
    const preset = getProviderPreset(providerId);
    if (!preset) {
      link.hidden = true;
      return;
    }
    link.href = preset.apiKeyUrl;
    link.textContent = t("options.createApiKey", { name: preset.displayName });
    link.hidden = false;
  }
  function populateModels(models, current) {
    const select = queryRequired("#model");
    select.replaceChildren();
    const availableModels = [...new Set(models.map((model) => model.trim()).filter(Boolean))];
    let preferred = current;
    if (!preferred || !availableModels.includes(preferred)) {
      preferred = availableModels[0] ?? "";
    }
    for (const model of availableModels) {
      const option = document.createElement("option");
      option.value = model;
      option.textContent = model;
      select.append(option);
    }
    if (preferred) {
      select.value = preferred;
    }
    select.disabled = availableModels.length === 0;
    return select.value;
  }
  async function loadModels(providerId, apiKey, currentModel = "", isCurrent = () => true) {
    const modelSelect = queryRequired("#model");
    const loadModelsButton = queryRequired("#load-models");
    const normalizedApiKey = apiKey.trim();
    const preset = getProviderPreset(providerId);
    if (!preset) {
      if (!isCurrent()) {
        return "";
      }
      modelSelect.replaceChildren();
      modelSelect.disabled = true;
      loadModelsButton.disabled = true;
      setTranslationStatus(t("options.unknownService"), "error");
      return "";
    }
    const hasStaticModels = !preset.modelsPath && Boolean(preset.models?.length);
    if (!normalizedApiKey && !hasStaticModels) {
      if (!isCurrent()) {
        return "";
      }
      modelSelect.replaceChildren();
      modelSelect.disabled = true;
      loadModelsButton.disabled = true;
      setTranslationStatus(t("options.enterApiKey"));
      return "";
    }
    if (!isCurrent()) {
      return "";
    }
    loadModelsButton.disabled = true;
    setTranslationStatus(t("options.findingModels"));
    try {
      const adapter = createProviderAdapter(preset, (input, init) => fetch(input, init));
      const result = await adapter.listModels(normalizedApiKey);
      if (!isCurrent()) {
        return "";
      }
      if (result.ok) {
        const model = populateModels(result.models, currentModel);
        providerDrafts.set(providerId, {
          apiKey: normalizedApiKey,
          model,
          modelLoadedForApiKey: normalizedApiKey
        });
        setTranslationStatus(model ? normalizedApiKey ? t("options.modelsFound", { count: result.models.length }) : t("options.modelsFoundEnterKey", { count: result.models.length }) : t("options.noModels"), model ? "success" : "error");
        loadModelsButton.disabled = !normalizedApiKey;
        return model;
      } else {
        modelSelect.replaceChildren();
        modelSelect.disabled = true;
        setTranslationStatus(result.error.message, "error");
      }
    } catch {
      if (isCurrent()) {
        modelSelect.replaceChildren();
        modelSelect.disabled = true;
        setTranslationStatus(t("options.modelsUnavailable"), "error");
      }
    } finally {
      if (isCurrent()) {
        loadModelsButton.disabled = !normalizedApiKey;
      }
    }
    return "";
  }
  async function loadCacheList() {
    const listEl = queryRequired("#cache-list");
    const statsEl = queryRequired("#cache-stats");
    const emptyEl = queryRequired("#cache-empty");
    const countEl = queryRequired("#cache-count");
    const toggleEl = queryRequired("#toggle-cache-list");
    let response;
    try {
      response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.listCache });
    } catch {
      listEl.replaceChildren();
      statsEl.textContent = "";
      queryRequired("#cache-count").textContent = "";
      queryRequired("#toggle-cache-list").hidden = true;
      emptyEl.textContent = t("options.historyUnavailable");
      emptyEl.hidden = false;
      return;
    }
    if (!isListCacheResponse(response)) {
      listEl.replaceChildren();
      statsEl.textContent = "";
      countEl.textContent = "";
      toggleEl.hidden = true;
      emptyEl.textContent = t("options.historyUnavailable");
      emptyEl.hidden = false;
      return;
    }
    listEl.replaceChildren();
    listEl.dataset.expanded = cacheListExpanded ? "true" : "false";
    countEl.textContent = t("options.historyCount", { count: response.entries.length });
    statsEl.textContent = t("options.historyStats", { count: response.entries.length, size: formatBytes(response.totalBytes) });
    emptyEl.hidden = response.entries.length > 0;
    toggleEl.hidden = response.entries.length <= 5;
    toggleEl.textContent = cacheListExpanded ? t("options.showRecentHistory") : t("options.viewAllHistory", { count: response.entries.length });
    toggleEl.setAttribute("aria-expanded", cacheListExpanded ? "true" : "false");
    for (const entry of response.entries) {
      const item = document.createElement("li");
      item.className = "cache-item";
      const info = document.createElement("div");
      info.className = "cache-item-info";
      const title = document.createElement("p");
      title.className = "cache-item-title";
      title.textContent = entry.title;
      const meta = document.createElement("p");
      meta.className = "cache-item-meta";
      meta.textContent = t("options.historyEntry", {
        source: entry.sourceLanguage,
        target: entry.targetLanguage,
        count: entry.blockCount,
        date: formatDate(entry.updatedAt)
      });
      info.append(title, meta);
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "cache-delete";
      deleteButton.textContent = t("options.delete");
      deleteButton.setAttribute("aria-label", t("options.deleteHistoryEntry", { title: entry.title }));
      deleteButton.addEventListener("click", () => {
        void chrome.runtime.sendMessage({ type: MESSAGE_TYPE.clearVideoCache, videoId: entry.videoId }).then(() => loadCacheList()).catch(() => showToast(t("options.deleteFailed"), "error"));
      });
      item.append(info, deleteButton);
      listEl.append(item);
    }
  }
  var committedSettings = null;
  var activeProviderId = "";
  var providerDrafts = /* @__PURE__ */ new Map();
  var pendingSettings = null;
  var inFlightSettings = null;
  var pendingTranslationSave = false;
  var saveTimer = null;
  var saveInFlight = false;
  var modelLoadVersion = 0;
  var cacheListExpanded = false;
  function updateSetupSteps() {
    const providerId = queryRequired("#provider-id").value.trim();
    const apiKey = queryRequired("#api-key").value.trim();
    const model = queryRequired("#model").value.trim();
    const draft = getProviderDraft(providerId);
    const modelReady = Boolean(model && apiKey && draft.modelLoadedForApiKey === apiKey);
    const steps = [
      {
        id: "provider-step",
        state: providerId ? "complete" : "current",
        status: providerId ? t("options.stepComplete") : t("options.stepCurrent")
      },
      {
        id: "api-key-step",
        state: apiKey ? "complete" : providerId ? "current" : "pending",
        status: apiKey ? t("options.stepComplete") : t("options.stepNeedsApiKey")
      },
      {
        id: "model-step",
        state: modelReady ? "complete" : apiKey ? "current" : "pending",
        status: modelReady ? t("options.stepComplete") : t("options.stepNeedsModel")
      }
    ];
    for (const step of steps) {
      const element = queryRequired(`#${step.id}`);
      element.dataset.stepState = step.state;
      const status = element.querySelector(".setup-step-status");
      if (status) {
        status.textContent = step.status;
      }
    }
  }
  function setTranslationStatus(message, state = "info") {
    const status = queryRequired("#model-status");
    status.textContent = message;
    status.dataset.state = state;
    updateSetupSteps();
  }
  async function loadUpdate() {
    const currentVersion = chrome.runtime.getManifest().version;
    const currentVersionElement = queryRequired("#current-version");
    const latestVersionElement = queryRequired("#latest-version");
    const statusElement = queryRequired("#version-update-status");
    const downloadLink = queryRequired("#options-download-update");
    currentVersionElement.textContent = currentVersion;
    latestVersionElement.textContent = "\u2014";
    statusElement.textContent = t("options.updateChecking");
    statusElement.dataset.state = "info";
    downloadLink.hidden = true;
    const result = await checkForExtensionUpdate(currentVersion);
    switch (result.state) {
      case "available":
        latestVersionElement.textContent = result.update.version;
        statusElement.textContent = t("options.updateAvailable", { version: result.update.version });
        statusElement.dataset.state = "success";
        downloadLink.href = result.update.downloadUrl;
        downloadLink.hidden = false;
        break;
      case "up-to-date":
        latestVersionElement.textContent = currentVersion;
        statusElement.textContent = t("options.updateUpToDate");
        statusElement.dataset.state = "success";
        break;
      case "unavailable":
        statusElement.textContent = t("options.updateUnavailable");
        statusElement.dataset.state = "error";
        break;
    }
  }
  function getProviderDraft(providerId) {
    const existing = providerDrafts.get(providerId);
    if (existing) {
      return existing;
    }
    const draft = {
      apiKey: committedSettings ? resolveProviderApiKey(committedSettings, providerId) : "",
      model: committedSettings ? resolveProviderModel(committedSettings, providerId) : "",
      modelLoadedForApiKey: ""
    };
    if (draft.apiKey && draft.model) {
      draft.modelLoadedForApiKey = draft.apiKey;
    }
    providerDrafts.set(providerId, draft);
    return draft;
  }
  function updateLoadModelsButton() {
    const button = queryRequired("#load-models");
    const apiKey = queryRequired("#api-key").value.trim();
    button.disabled = !apiKey;
  }
  function updateSubtitlePreview() {
    const stage = queryRequired("#subtitle-preview-stage");
    const mode = parseCaptionDisplayMode(queryRequired("#caption-mode").value);
    if (mode) {
      stage.dataset.mode = mode;
    }
    stage.style.setProperty("--preview-translation-color", queryRequired("#translation-color").value);
    stage.style.setProperty("--preview-original-color", queryRequired("#original-color").value);
    stage.style.setProperty(
      "--preview-translation-scale",
      String(Number(queryRequired("#translation-font-scale").value) / 100)
    );
    stage.style.setProperty(
      "--preview-original-scale",
      String(Number(queryRequired("#original-font-scale").value) / 100)
    );
  }
  function syncSelectionContextControl() {
    const selectionEnabled = queryRequired("#selection-enabled").checked;
    queryRequired("#include-context").disabled = !selectionEnabled;
  }
  function captureActiveProviderDraft() {
    if (!activeProviderId) {
      return;
    }
    const apiKey = queryRequired("#api-key").value;
    const model = queryRequired("#model").value;
    const existing = getProviderDraft(activeProviderId);
    providerDrafts.set(activeProviderId, {
      apiKey,
      model,
      modelLoadedForApiKey: existing.modelLoadedForApiKey === apiKey ? apiKey : ""
    });
  }
  function buildGeneralSettings() {
    const base = pendingSettings ?? inFlightSettings ?? committedSettings;
    if (!base) {
      return null;
    }
    const displayMode = parseCaptionDisplayMode(queryRequired("#caption-mode").value);
    const shortsTranslationEnabled = queryRequired("#shorts-translation-enabled").checked;
    const autoTranslateTitle = queryRequired("#auto-translate-title").checked;
    const translationColor = queryRequired("#translation-color").value;
    const originalColor = queryRequired("#original-color").value;
    const translationFontScale = Number(queryRequired("#translation-font-scale").value);
    const originalFontScale = Number(queryRequired("#original-font-scale").value);
    if (!displayMode || !/^#[0-9a-f]{6}$/iu.test(translationColor) || !/^#[0-9a-f]{6}$/iu.test(originalColor) || !Number.isInteger(translationFontScale) || translationFontScale < 80 || translationFontScale > 160 || !Number.isInteger(originalFontScale) || originalFontScale < 80 || originalFontScale > 160) {
      return null;
    }
    return {
      ...base,
      subtitles: {
        ...base.subtitles,
        displayMode,
        shortsTranslationEnabled,
        translationColor,
        originalColor,
        translationFontScale,
        originalFontScale
      },
      page: {
        autoTranslateTitle
      },
      selection: {
        enabled: queryRequired("#selection-enabled").checked,
        includeContext: queryRequired("#include-context").checked
      }
    };
  }
  function scheduleSettingsSave(settings, translationSave = false) {
    pendingSettings = settings;
    pendingTranslationSave ||= translationSave;
    if (translationSave) {
      setTranslationStatus(t("options.saving"));
    }
    if (saveTimer !== null) {
      window.clearTimeout(saveTimer);
    }
    saveTimer = window.setTimeout(() => {
      saveTimer = null;
      void flushSettingsSave();
    }, 180);
  }
  async function flushSettingsSave() {
    if (saveInFlight || !pendingSettings) {
      return;
    }
    const settings = pendingSettings;
    const translationSave = pendingTranslationSave;
    pendingSettings = null;
    inFlightSettings = settings;
    pendingTranslationSave = false;
    saveInFlight = true;
    let saveFailed = false;
    try {
      await createChromeSettingsRepository().saveSettings(settings);
      committedSettings = settings;
      if (translationSave && queryRequired("#provider-id").value === settings.provider.providerId) {
        const draft = getProviderDraft(settings.provider.providerId);
        if (draft.apiKey.trim() === settings.apiKeys[settings.provider.providerId] && draft.model === settings.provider.model) {
          setTranslationStatus(t("options.saved"), "success");
        }
      }
      if (translationSave) {
        void chrome.runtime.sendMessage({ type: MESSAGE_TYPE.updateVideoTranslationStatus, status: { phase: "idle" } }).catch(() => void 0);
      }
    } catch {
      saveFailed = true;
      pendingSettings ??= settings;
      pendingTranslationSave ||= translationSave;
      if (translationSave) {
        setTranslationStatus(t("options.saveFailed"), "error");
      } else {
        showToast(t("options.preferencesSaveFailed"), "error");
      }
    } finally {
      inFlightSettings = null;
      saveInFlight = false;
      if (pendingSettings && !saveFailed) {
        void flushSettingsSave();
      }
    }
  }
  function saveGeneralSettings() {
    const settings = buildGeneralSettings();
    if (settings) {
      scheduleSettingsSave(settings);
    }
  }
  function getTranslationFormValues() {
    const providerId = queryRequired("#provider-id").value.trim();
    const apiKey = queryRequired("#api-key").value.trim();
    const model = queryRequired("#model").value.trim();
    const draft = getProviderDraft(providerId);
    if (!providerId || !apiKey || !model || draft.apiKey.trim() !== apiKey || draft.model !== model || draft.modelLoadedForApiKey !== apiKey) {
      return null;
    }
    return { providerId, apiKey, model };
  }
  function commitTranslationService() {
    const values = getTranslationFormValues();
    if (!values || !committedSettings) {
      return false;
    }
    const base = pendingSettings ?? inFlightSettings ?? committedSettings;
    const next = {
      ...base,
      provider: { providerId: values.providerId, model: values.model },
      apiKeys: { ...base.apiKeys, [values.providerId]: values.apiKey },
      providerModels: { ...base.providerModels, [values.providerId]: values.model }
    };
    const currentApiKey = base.apiKeys[values.providerId] ?? "";
    const currentModel = resolveProviderModel(base, values.providerId);
    if (base.provider.providerId === values.providerId && currentApiKey === values.apiKey && currentModel === values.model) {
      setTranslationStatus(t("options.saved"), "success");
      return true;
    }
    scheduleSettingsSave(next, true);
    return true;
  }
  async function loadOptions() {
    const settings = await createChromeSettingsRepository().loadSettings();
    const supportedProviderId = getProviderPreset(settings.provider.providerId) ? settings.provider.providerId : DEFAULT_PROVIDER_ID;
    const providerSettings = supportedProviderId === settings.provider.providerId ? settings : {
      ...settings,
      provider: { providerId: supportedProviderId, model: "" }
    };
    const apiKey = resolveProviderApiKey(providerSettings);
    committedSettings = providerSettings;
    providerDrafts.clear();
    providerDrafts.set(providerSettings.provider.providerId, {
      apiKey,
      model: resolveProviderModel(providerSettings),
      modelLoadedForApiKey: apiKey && resolveProviderModel(providerSettings) ? apiKey : ""
    });
    queryRequired("#api-key").value = apiKey;
    queryRequired("#caption-mode").value = providerSettings.subtitles.displayMode;
    queryRequired("#shorts-translation-enabled").checked = providerSettings.subtitles.shortsTranslationEnabled;
    queryRequired("#auto-translate-title").checked = providerSettings.page.autoTranslateTitle;
    queryRequired("#translation-color").value = providerSettings.subtitles.translationColor;
    queryRequired("#original-color").value = providerSettings.subtitles.originalColor;
    queryRequired("#translation-font-scale").value = String(providerSettings.subtitles.translationFontScale);
    queryRequired("#original-font-scale").value = String(providerSettings.subtitles.originalFontScale);
    updateSubtitleFontScaleLabels();
    updateSubtitlePreview();
    queryRequired("#selection-enabled").checked = providerSettings.selection.enabled;
    queryRequired("#include-context").checked = providerSettings.selection.includeContext;
    syncSelectionContextControl();
    populateProviders(providerSettings.provider.providerId);
    activeProviderId = providerSettings.provider.providerId;
    updateCreateApiKeyLink(activeProviderId);
    updateSetupSteps();
    const resolvedModel = await loadModels(providerSettings.provider.providerId, apiKey, resolveProviderModel(providerSettings));
    if (resolvedModel && apiKey) {
      commitTranslationService();
    }
    await loadCacheList();
  }
  function bindForm() {
    const form = queryRequired("#settings-form");
    const providerSelect = queryRequired("#provider-id");
    const apiKeyInput = queryRequired("#api-key");
    const modelSelect = queryRequired("#model");
    const loadModelsButton = queryRequired("#load-models");
    const captionModeSelect = queryRequired("#caption-mode");
    const shortsTranslationEnabledInput = queryRequired("#shorts-translation-enabled");
    const autoTranslateTitleInput = queryRequired("#auto-translate-title");
    const translationColorInput = queryRequired("#translation-color");
    const originalColorInput = queryRequired("#original-color");
    const translationFontScaleInput = queryRequired("#translation-font-scale");
    const originalFontScaleInput = queryRequired("#original-font-scale");
    const selectionEnabledInput = queryRequired("#selection-enabled");
    const includeContextInput = queryRequired("#include-context");
    modelSelect.addEventListener("change", () => {
      const providerId = providerSelect.value;
      const draft = getProviderDraft(providerId);
      providerDrafts.set(providerId, { ...draft, model: modelSelect.value });
      updateSetupSteps();
      commitTranslationService();
    });
    captionModeSelect.addEventListener("change", () => {
      updateSubtitlePreview();
      saveGeneralSettings();
    });
    shortsTranslationEnabledInput.addEventListener("change", saveGeneralSettings);
    autoTranslateTitleInput.addEventListener("change", saveGeneralSettings);
    translationColorInput.addEventListener("input", () => {
      updateSubtitlePreview();
      saveGeneralSettings();
    });
    originalColorInput.addEventListener("input", () => {
      updateSubtitlePreview();
      saveGeneralSettings();
    });
    translationFontScaleInput.addEventListener("input", () => {
      updateSubtitleFontScaleLabels();
      updateSubtitlePreview();
      saveGeneralSettings();
    });
    originalFontScaleInput.addEventListener("input", () => {
      updateSubtitleFontScaleLabels();
      updateSubtitlePreview();
      saveGeneralSettings();
    });
    selectionEnabledInput.addEventListener("change", () => {
      syncSelectionContextControl();
      saveGeneralSettings();
    });
    includeContextInput.addEventListener("change", saveGeneralSettings);
    apiKeyInput.addEventListener("input", () => {
      const providerId = providerSelect.value;
      providerDrafts.set(providerId, {
        apiKey: apiKeyInput.value,
        model: "",
        modelLoadedForApiKey: ""
      });
      modelSelect.replaceChildren();
      modelSelect.disabled = true;
      setTranslationStatus(apiKeyInput.value.trim() ? t("options.apiKeyChanged") : t("options.enterApiKey"));
      updateLoadModelsButton();
    });
    providerSelect.addEventListener("change", () => {
      captureActiveProviderDraft();
      activeProviderId = providerSelect.value;
      const providerId = activeProviderId;
      updateCreateApiKeyLink(providerId);
      const loadVersion = ++modelLoadVersion;
      const draft = getProviderDraft(providerId);
      apiKeyInput.value = draft.apiKey;
      modelSelect.replaceChildren();
      modelSelect.disabled = true;
      updateLoadModelsButton();
      setTranslationStatus(draft.apiKey ? t("options.loadingConfiguredModels") : t("options.enterApiKey"));
      if (draft.apiKey && draft.model && draft.modelLoadedForApiKey === draft.apiKey) {
        void commitTranslationService();
      }
      void loadModels(providerId, draft.apiKey, draft.model, () => loadVersion === modelLoadVersion && providerSelect.value === providerId).then(() => {
        if (loadVersion === modelLoadVersion && providerSelect.value === providerId) {
          commitTranslationService();
        }
      });
    });
    loadModelsButton.addEventListener("click", () => {
      const providerId = providerSelect.value;
      const loadVersion = ++modelLoadVersion;
      void loadModels(providerId, apiKeyInput.value, "", () => loadVersion === modelLoadVersion && providerSelect.value === providerId).then(() => {
        if (loadVersion === modelLoadVersion && providerSelect.value === providerId) {
          commitTranslationService();
        }
      });
    });
    queryRequired("#refresh-cache").addEventListener("click", () => {
      void loadCacheList();
    });
    queryRequired("#toggle-cache-list").addEventListener("click", () => {
      cacheListExpanded = !cacheListExpanded;
      void loadCacheList();
    });
    queryRequired("#clear-all-cache").addEventListener("click", () => {
      if (!window.confirm(t("options.confirmClearHistory"))) {
        return;
      }
      void chrome.runtime.sendMessage({ type: MESSAGE_TYPE.clearAllCache }).then(() => loadCacheList()).catch(() => showToast(t("options.clearFailed"), "error"));
    });
    queryRequired("#reset-subtitle-style").addEventListener("click", () => {
      translationColorInput.value = DEFAULT_SUBTITLE_SETTINGS.translationColor;
      originalColorInput.value = DEFAULT_SUBTITLE_SETTINGS.originalColor;
      translationFontScaleInput.value = String(DEFAULT_SUBTITLE_SETTINGS.translationFontScale);
      originalFontScaleInput.value = String(DEFAULT_SUBTITLE_SETTINGS.originalFontScale);
      updateSubtitleFontScaleLabels();
      updateSubtitlePreview();
      const base = pendingSettings ?? inFlightSettings ?? committedSettings;
      const displayMode = parseCaptionDisplayMode(captionModeSelect.value);
      if (base && displayMode) {
        scheduleSettingsSave({
          ...base,
          subtitles: {
            ...DEFAULT_SUBTITLE_SETTINGS,
            displayMode
          }
        });
        showToast(t("options.captionStyleRestored"), "success");
      }
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (apiKeyInput.value.trim() && !modelSelect.value) {
        loadModelsButton.click();
        return;
      }
      commitTranslationService();
    });
  }
  function updateSubtitleFontScaleLabels() {
    const translationScale = queryRequired("#translation-font-scale").value;
    const originalScale = queryRequired("#original-font-scale").value;
    queryRequired("#translation-font-scale-value").value = `${translationScale}%`;
    queryRequired("#original-font-scale-value").value = `${originalScale}%`;
  }
  async function initialize() {
    bindForm();
    void loadUpdate();
    try {
      await loadOptions();
    } catch {
      showToast(t("options.loadFailed"), "error");
    }
  }
  localizeDocument(document);
  void initialize();
})();
//# sourceMappingURL=index.js.map
