"use strict";
(() => {
  // src/shared/contracts/settings.ts
  var DEFAULT_PROVIDER_ID = "deepseek";
  var DEFAULT_CAPTION_DISPLAY_MODE = "bilingual";
  var DEFAULT_API_KEYS = {};
  var DEFAULT_PROVIDER_MODELS = {};
  var DEFAULT_PROVIDER_SETTINGS = {
    providerId: DEFAULT_PROVIDER_ID,
    model: ""
  };
  var DEFAULT_SUBTITLE_SETTINGS = {
    displayMode: DEFAULT_CAPTION_DISPLAY_MODE,
    shortsTranslationEnabled: false,
    translationColor: "#ffd438",
    originalColor: "#ececf0",
    translationFontScale: 100,
    originalFontScale: 100,
    verticalPosition: null
  };
  var DEFAULT_SELECTION_SETTINGS = {
    enabled: true,
    includeContext: false
  };
  var DEFAULT_PAGE_TRANSLATION_SETTINGS = {
    autoTranslateTitle: true
  };
  var DEFAULT_SETTINGS = {
    provider: { ...DEFAULT_PROVIDER_SETTINGS },
    apiKeys: { ...DEFAULT_API_KEYS },
    providerModels: { ...DEFAULT_PROVIDER_MODELS },
    subtitles: { ...DEFAULT_SUBTITLE_SETTINGS },
    page: { ...DEFAULT_PAGE_TRANSLATION_SETTINGS },
    selection: { ...DEFAULT_SELECTION_SETTINGS }
  };
  function parseCaptionDisplayMode(value) {
    if (value === "original" || value === "translation" || value === "bilingual") {
      return value;
    }
    return null;
  }
  function resolveProviderApiKey(settings, providerId = settings.provider.providerId) {
    return settings.apiKeys[providerId] ?? "";
  }

  // src/shared/contracts/messages.ts
  var MESSAGE_TYPE = {
    getSettings: "get-settings",
    getVideoTranslationCache: "get-video-translation-cache",
    getVideoTranslationStatus: "get-video-translation-status",
    updateVideoTranslationStatus: "update-video-translation-status",
    translateVideo: "translate-video",
    translateVideoProgress: "translate-video-progress",
    translateText: "translate-text",
    translateTextProgress: "translate-text-progress",
    translateSelectionFromContext: "translate-selection-from-context",
    getCacheStats: "get-cache-stats",
    listCache: "list-cache",
    clearVideoCache: "clear-video-cache",
    clearAllCache: "clear-all-cache"
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function parseVideoTranslationStatus(value) {
    if (!isRecord(value) || typeof value.phase !== "string") {
      return null;
    }
    const hasOptionalString = (key) => value[key] === void 0 || typeof value[key] === "string";
    const hasOptionalCount = (key) => value[key] === void 0 || typeof value[key] === "number" && Number.isSafeInteger(value[key]) && value[key] >= 0;
    if (!hasOptionalString("videoId") || !hasOptionalString("videoTitle") || !hasOptionalString("errorMessage") || !hasOptionalCount("segmentCount") || !hasOptionalCount("translatedCount")) {
      return null;
    }
    const phase = value.phase;
    if (phase === "idle" || phase === "reading-captions") {
      return {
        phase,
        ...typeof value.videoId === "string" ? { videoId: value.videoId } : {},
        ...typeof value.videoTitle === "string" ? { videoTitle: value.videoTitle } : {}
      };
    }
    if (phase === "ready-for-translation" || phase === "translating") {
      return typeof value.videoId === "string" && typeof value.videoTitle === "string" && typeof value.segmentCount === "number" ? {
        phase,
        videoId: value.videoId,
        videoTitle: value.videoTitle,
        segmentCount: value.segmentCount,
        ...typeof value.translatedCount === "number" ? { translatedCount: value.translatedCount } : {}
      } : null;
    }
    if (phase === "translated") {
      return typeof value.videoId === "string" && typeof value.videoTitle === "string" && typeof value.segmentCount === "number" && typeof value.translatedCount === "number" ? { phase, videoId: value.videoId, videoTitle: value.videoTitle, segmentCount: value.segmentCount, translatedCount: value.translatedCount } : null;
    }
    if (phase === "error") {
      return typeof value.videoId === "string" && typeof value.videoTitle === "string" && typeof value.errorMessage === "string" ? { phase, videoId: value.videoId, videoTitle: value.videoTitle, errorMessage: value.errorMessage } : null;
    }
    return null;
  }
  function isVideoTranslationStatus(value) {
    return parseVideoTranslationStatus(value) !== null;
  }
  function isSettingsMessageResponse(value) {
    if (!isRecord(value) || typeof value.resolvedTargetLocale !== "string") {
      return false;
    }
    const settings = value.settings;
    return isRecord(settings) && isRecord(settings.provider) && typeof settings.provider.providerId === "string" && typeof settings.provider.model === "string" && isRecord(settings.apiKeys) && Object.values(settings.apiKeys).every((key) => typeof key === "string") && isRecord(settings.providerModels) && Object.values(settings.providerModels).every((model) => typeof model === "string") && isRecord(settings.subtitles) && parseCaptionDisplayMode(settings.subtitles.displayMode) !== null && isRecord(settings.page) && typeof settings.page.autoTranslateTitle === "boolean" && isRecord(settings.selection) && typeof settings.selection.enabled === "boolean" && typeof settings.selection.includeContext === "boolean";
  }

  // src/shared/icons/index.ts
  var SVG_ATTRIBUTES = 'xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  function svgFromIcon(icon) {
    const container = document.createElement("div");
    container.innerHTML = `<svg ${SVG_ATTRIBUTES}>${icon.elementMarkup}</svg>`;
    const svg = container.firstElementChild;
    if (!(svg instanceof SVGElement)) {
      throw new Error(`Invalid icon definition: ${icon.name}`);
    }
    return svg;
  }
  function createIcons(options) {
    for (const icon of Object.values(options.icons)) {
      const elements = document.querySelectorAll(`[data-lucide="${icon.name}"]`);
      for (const element of elements) {
        element.replaceWith(svgFromIcon(icon));
      }
    }
  }
  var Settings = {
    name: "settings",
    elementMarkup: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>'
  };

  // src/shared/providers/provider-registry.ts
  var PROVIDER_PRESETS = [
    {
      id: "deepseek",
      displayName: "DeepSeek",
      apiKeyUrl: "https://platform.deepseek.com/api_keys",
      kind: "openai-compatible",
      baseUrl: "https://api.deepseek.com",
      modelLimits: {
        "deepseek-v4-flash": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 },
        "deepseek-v4-pro": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 }
      },
      requestBody: { thinking: { type: "disabled" } },
      requestPath: "/chat/completions",
      modelsPath: "/models"
    },
    {
      id: "openai",
      displayName: "OpenAI",
      apiKeyUrl: "https://platform.openai.com/api-keys",
      kind: "openai-compatible",
      baseUrl: "https://api.openai.com",
      modelLimits: {
        "gpt-4o-mini": { contextWindowTokens: 128e3, maxOutputTokens: 16384 },
        "gpt-4o": { contextWindowTokens: 128e3, maxOutputTokens: 16384 }
      },
      requestPath: "/v1/chat/completions",
      modelsPath: "/v1/models"
    },
    {
      id: "anthropic",
      displayName: "Anthropic",
      apiKeyUrl: "https://platform.claude.com/settings/keys",
      kind: "anthropic-messages",
      baseUrl: "https://api.anthropic.com",
      modelLimits: {
        "claude-haiku-4-5-20251001": { contextWindowTokens: 2e5, maxOutputTokens: 64e3 },
        "claude-sonnet-5": { contextWindowTokens: 1e6, maxOutputTokens: 128e3 }
      },
      requestPath: "/v1/messages",
      modelsPath: "/v1/models"
    },
    {
      id: "agnes",
      displayName: "Agnes AI",
      apiKeyUrl: "https://platform.agnes-ai.com/settings/apiKeys",
      kind: "openai-compatible",
      baseUrl: "https://apihub.agnes-ai.com/v1",
      models: ["agnes-2.5-flash"],
      modelLimits: {
        "agnes-2.5-flash": { contextWindowTokens: 512e3, maxOutputTokens: 65536 }
      },
      requestPath: "/chat/completions"
    }
  ];
  function getProviderPreset(id) {
    return PROVIDER_PRESETS.find((preset) => preset.id === id) ?? null;
  }

  // src/shared/extension-update.ts
  var UPDATE_MANIFEST_URL = "https://cdn.jsdelivr.net/gh/LZKDreamer/xTranslator@latest/public/updates/latest.json";
  function parseVersion(version) {
    const parts = version.split(".");
    if (parts.length === 0 || parts.length > 4 || parts.some((part) => !/^(?:0|[1-9]\d{0,4})$/u.test(part))) {
      return null;
    }
    const values = parts.map(Number);
    return values.every((part) => part <= 65535) ? values : null;
  }
  function compareExtensionVersions(left, right) {
    const leftParts = parseVersion(left);
    const rightParts = parseVersion(right);
    if (!leftParts || !rightParts) {
      return null;
    }
    for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
      const difference = (leftParts[index] ?? 0) - (rightParts[index] ?? 0);
      if (difference !== 0) {
        return difference;
      }
    }
    return 0;
  }
  function getAvailableUpdate(value, installedVersion) {
    if (!value || typeof value !== "object") {
      return null;
    }
    const { version, downloadUrl } = value;
    if (typeof version !== "string" || typeof downloadUrl !== "string") {
      return null;
    }
    let url;
    try {
      url = new URL(downloadUrl);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" || url.hostname !== "cdn.jsdelivr.net" || !url.pathname.startsWith("/gh/LZKDreamer/xTranslator@v") || !url.pathname.endsWith(".zip")) {
      return null;
    }
    const comparison = compareExtensionVersions(version, installedVersion);
    return comparison !== null && comparison > 0 ? { version, downloadUrl } : null;
  }
  async function checkForExtensionUpdate(installedVersion, request = fetch) {
    try {
      const response = await request(UPDATE_MANIFEST_URL, { cache: "no-store" });
      if (!response.ok) {
        return { state: "unavailable" };
      }
      const update = getAvailableUpdate(await response.json(), installedVersion);
      return update ? { state: "available", update } : { state: "up-to-date" };
    } catch {
      return { state: "unavailable" };
    }
  }

  // src/shared/i18n/index.ts
  var en = {
    "popup.openSettings": "Open settings",
    "popup.translationLanguage": "Translation language",
    "popup.followBrowserLanguage": "Follow browser language",
    "popup.translationEngine": "Translation engine",
    "popup.loading": "Loading\u2026",
    "popup.watchStatus": "Viewing status",
    "popup.readyToTranslate": "Ready to translate",
    "popup.openYoutubeVideo": "Open a YouTube video and click the xTranslator button in the player.",
    "popup.connected": "Connected to {name}{model}",
    "popup.notConnected": "No translation service is connected. Open settings to connect one.",
    "popup.updateAvailable": "Update available",
    "popup.updateDetail": "Version {version} is ready to download.",
    "popup.downloadUpdate": "Download update",
    "popup.browserLanguage": "Follow browser language \xB7 {language}",
    "popup.preparingCaptions": "Preparing captions\u2026",
    "popup.captionsReady": "Captions are ready. Translation will begin shortly.",
    "popup.translatingCaptions": "Translating {count} caption segments\u2026",
    "popup.noTranslationNeeded": "The captions are already in the target language.",
    "popup.translationComplete": "Translation complete \xB7 {translated}/{total} caption segments",
    "popup.videoUnavailable": "This video cannot be translated right now. Please try again later.",
    "popup.statusUnavailable": "Video translation status is temporarily unavailable.",
    "options.title": "xTranslator Preferences",
    "options.preferences": "Preferences",
    "options.versionUpdate": "Version update",
    "options.currentVersion": "Current version",
    "options.latestVersion": "Latest version",
    "options.updateChecking": "Checking for updates\u2026",
    "options.updateAvailable": "Version {version} is ready to download.",
    "options.updateUpToDate": "You have the latest version.",
    "options.updateUnavailable": "Updates cannot be checked right now. Please try again later.",
    "options.downloadUpdate": "Download update",
    "options.translationService": "Translation service",
    "options.serviceHelp": "Enter a service key and load a model. Your settings are saved automatically when all three fields are complete.",
    "options.setupSteps": "Translation service setup",
    "options.stepProvider": "Provider",
    "options.stepApiKey": "API Key",
    "options.stepModel": "Model",
    "options.stepComplete": "Complete",
    "options.stepCurrent": "Current step",
    "options.stepNeedsApiKey": "Enter key",
    "options.stepNeedsModel": "Load a model",
    "options.serviceKey": "Service key (API Key)",
    "options.keyHelp": "Your key is stored only on this device and is used to connect to the selected translation service.",
    "options.createApiKey": "Create a {name} API key",
    "options.loadModels": "Load models",
    "options.translationModel": "Translation model",
    "options.subtitleDisplay": "Caption display",
    "options.subtitlePreview": "Live preview",
    "options.previewPlayer": "Player",
    "options.previewTranslation": "The answer is already in the details.",
    "options.previewOriginal": "\u7B54\u6848\u5C31\u5728\u7EC6\u8282\u91CC\u3002",
    "options.captionMode": "Caption mode",
    "options.originalOnly": "Original only",
    "options.translationOnly": "Translation only",
    "options.bilingual": "Original + translation",
    "options.captionModeHelp": "Choose how captions appear in videos. Changes apply to the current video immediately.",
    "options.enableShortsTranslation": "Enable Shorts translation",
    "options.shortsTranslationHelp": "When disabled, the translation button is hidden in Shorts. Comment translation remains available.",
    "options.subtitleStyle": "Caption style",
    "options.translationColor": "Translation color",
    "options.originalColor": "Original color",
    "options.translationFontSize": "Translation size",
    "options.originalFontSize": "Original size",
    "options.captionPositionHelp": "Drag captions vertically in the player to avoid important content. Their position and style are saved automatically.",
    "options.resetCaptionStyle": "Restore default caption style and position",
    "options.pageTranslation": "Page translation",
    "options.viewTranslation": "Viewing-page translation",
    "options.autoTranslateTitle": "Automatically translate video titles",
    "options.autoTranslateTitleHelp": "Shows the original title immediately, then displays its translation below when ready.",
    "options.selectionTranslation": "Selection translation",
    "options.enableSelectionTranslation": "Enable selection translation",
    "options.selectionDisabledHelp": "When disabled, selecting text will not show the translation panel and the context menu will not start a translation.",
    "options.includeContext": "Use surrounding context when translating selected text",
    "options.includeContextHelp": "When enabled, the surrounding sentences help produce a more natural translation.",
    "options.translationHistory": "Translation history",
    "options.dataMaintenance": "Data & maintenance",
    "options.historyHelp": "Recent entries are shown first. Open the full list when needed.",
    "options.historyCount": "{count} entries",
    "options.viewAllHistory": "View all {count} entries",
    "options.showRecentHistory": "Show recent entries",
    "options.emptyHistory": "No translation history has been saved.",
    "options.reload": "Reload",
    "options.clearHistory": "Clear history",
    "options.confirmClearHistory": "Clear all saved translation history? This cannot be undone.",
    "options.unknownService": "The selected translation service is not recognized.",
    "options.enterApiKey": "Enter an API key to load models.",
    "options.findingModels": "Finding available models\u2026",
    "options.modelsFound": "Found {count} available models.",
    "options.modelsFoundEnterKey": "Found {count} models. Enter an API key before saving.",
    "options.noModels": "No models are available.",
    "options.modelsUnavailable": "The model list is temporarily unavailable. Check your network connection or service key.",
    "options.historyUnavailable": "Translation history is temporarily unavailable.",
    "options.historyStats": "{count} saved entries \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} segments \xB7 {date}",
    "options.delete": "Delete",
    "options.deleteHistoryEntry": "Delete the translation history for {title}",
    "options.deleteFailed": "This history entry could not be deleted. Please try again later.",
    "options.saving": "Saving settings\u2026",
    "options.saved": "Settings saved.",
    "options.saveFailed": "Settings could not be saved. Please try again later.",
    "options.preferencesSaveFailed": "Preferences could not be saved. Please try again later.",
    "options.apiKeyChanged": "The API key changed. Click Load models.",
    "options.loadingConfiguredModels": "Loading configured models\u2026",
    "options.clearFailed": "Translation history could not be cleared. Please try again later.",
    "options.captionStyleRestored": "Default caption style and automatic position restored.",
    "options.loadFailed": "Preferences are temporarily unavailable. Refresh and try again.",
    "content.pageUnsupported": "This YouTube page is not supported.",
    "content.captionHttp": "The caption link has expired or is temporarily unavailable. Please try again.",
    "content.captionNetwork": "Captions could not be read. Check your network connection and try again.",
    "content.captionUnsupported": "This caption format is not supported yet. Please try again later.",
    "content.partialTranslation": "Translation is incomplete. Some captions are ready; click to continue.",
    "content.startTranslation": "Start translation",
    "content.cacheLoaded": "Loaded cached translation: {count} segments",
    "content.translateAgain": "Translate again",
    "content.translating": "Translating",
    "content.readingCache": "Reading cached translation\u2026",
    "content.noCaptionsOrCache": "This video has no available captions or local translation cache.",
    "content.retryCaptions": "Retry captions",
    "content.readingCaptions": "Reading captions\u2026",
    "content.translatingSegments": "Translating {count} segments\u2026",
    "content.translatingProgress": "Translating {translated}/{total}\u2026",
    "content.noTranslationNeeded": "The captions are already in the target language.",
    "content.noTranslation": "No translation needed",
    "content.translationComplete": "Translation complete: {count} segments",
    "content.translationCompleteProgress": "Translation complete {translated}/{total}",
    "content.continueTranslation": "Continue translation",
    "content.partialTranslationProgress": "{translated}/{total} translated \xB7 {missing} remaining. Click to continue.",
    "content.retry": "Retry",
    "content.serviceUnavailable": "The translation service could not be reached. Check extension settings and try again.",
    "content.captionPosition": "Drag up or down to adjust caption position",
    "content.translatingTitle": "Translating title\u2026",
    "content.titleTranslationFailed": "Title translation failed.",
    "content.retryTitleTranslation": "Retry",
    "content.translateDescription": "Translate description",
    "content.descriptionActionAria": "xTranslator: {action}",
    "content.translatingDescription": "Translating description\u2026",
    "content.descriptionTranslation": "Translation",
    "content.descriptionTranslationFailed": "Description translation failed. Click to retry.",
    "content.hideDescriptionTranslation": "Hide translation",
    "content.showDescriptionTranslation": "Show translation",
    "comment.translateVisible": "Translate {count} visible comments",
    "comment.translateVisiblePrefix": "Translate",
    "comment.translateVisibleAria": "Translate {count} currently visible comments",
    "comment.translateThread": "Translate this thread ({count})",
    "comment.translateThreadAria": "Translate this thread ({count})",
    "comment.translatedVisible": "Translated {count} comments",
    "comment.translatedThread": "Translated thread ({count})",
    "comment.noExpandedReplies": "No expanded replies found",
    "comment.noTranslatableComments": "No translatable comments found",
    "comment.translating": "Translating\u2026",
    "comment.translatingProgress": "Translating {completed}/{total}\u2026",
    "comment.retryIncomplete": "Retry incomplete translations",
    "comment.retryIncompleteCount": "Retry incomplete ({count})",
    "comment.translationFailedRetry": "Translation failed. Click to retry",
    "comment.retryComment": "Retry translation for comment: {id}",
    "comment.retried": "Retried",
    "selection.toolbar": "Selection translation",
    "selection.translate": "Translate",
    "selection.translateAria": "Translate selected text",
    "selection.copyAria": "Copy selected text",
    "selection.closeAria": "Close selection panel",
    "selection.translating": "Translating\u2026",
    "selection.failed": "Translation failed. Please try again.",
    "selection.copyTranslationAria": "Copy translation",
    "selection.cancelAria": "Cancel translation",
    "selection.closeTranslationAria": "Close translation panel",
    "background.notConnected": "No translation service is connected. Complete preferences first.",
    "background.unknownService": "The translation service is not recognized: {id}",
    "background.noModel": "No translation model is selected. Open settings, load models, and select one.",
    "background.contextMenu": "Translate selected text",
    "background.videoFailed": "Video translation failed. Please try again.",
    "background.translationFailed": "Translation failed. Please try again.",
    "translation.missingCaptions": "{count} caption segments did not receive a valid translation. Completed segments were saved; please try again.",
    "provider.auth": "The service key is invalid or lacks permission. Check it in Preferences.",
    "provider.rateLimit": "The translation service is busy. Please try again later.",
    "provider.timeout": "The translation request timed out. Please try again.",
    "provider.network": "The translation service could not be reached. Check your network connection and try again.",
    "provider.model": "The selected model is unavailable. Choose another model in Preferences.",
    "provider.badResponse": "The translation service is temporarily unavailable. Please try again later."
  };
  var zhCN = {
    "popup.openSettings": "\u6253\u5F00\u8BBE\u7F6E",
    "popup.translationLanguage": "\u7FFB\u8BD1\u8BED\u8A00",
    "popup.followBrowserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00",
    "popup.translationEngine": "\u7FFB\u8BD1\u5F15\u64CE",
    "popup.loading": "\u52A0\u8F7D\u4E2D\u2026",
    "popup.watchStatus": "\u89C2\u770B\u72B6\u6001",
    "popup.readyToTranslate": "\u51C6\u5907\u597D\u5F00\u59CB\u7FFB\u8BD1",
    "popup.openYoutubeVideo": "\u6253\u5F00 YouTube \u89C6\u9891\uFF0C\u70B9\u51FB\u64AD\u653E\u5668\u4E2D\u7684 xTranslator \u6309\u94AE\u3002",
    "popup.connected": "\u5DF2\u8FDE\u63A5 {name}{model}",
    "popup.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E\u5B8C\u6210\u8FDE\u63A5\u3002",
    "popup.updateAvailable": "\u53D1\u73B0\u65B0\u7248\u672C",
    "popup.updateDetail": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "popup.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "popup.browserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00 \xB7 {language}",
    "popup.preparingCaptions": "\u6B63\u5728\u51C6\u5907\u5B57\u5E55\u2026",
    "popup.captionsReady": "\u5B57\u5E55\u5DF2\u51C6\u5907\u597D\uFF0C\u9A6C\u4E0A\u5F00\u59CB\u7FFB\u8BD1\u3002",
    "popup.translatingCaptions": "\u6B63\u5728\u7FFB\u8BD1 {count} \u5904\u5B57\u5E55\u2026",
    "popup.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "popup.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210 \xB7 {translated}/{total} \u5904\u5B57\u5E55",
    "popup.videoUnavailable": "\u8FD9\u6BB5\u89C6\u9891\u6682\u65F6\u65E0\u6CD5\u7FFB\u8BD1\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "popup.statusUnavailable": "\u89C6\u9891\u7FFB\u8BD1\u72B6\u6001\u6682\u65F6\u4E0D\u53EF\u7528\u3002",
    "options.title": "xTranslator \u504F\u597D\u8BBE\u7F6E",
    "options.preferences": "\u504F\u597D\u8BBE\u7F6E",
    "options.versionUpdate": "\u7248\u672C\u66F4\u65B0",
    "options.currentVersion": "\u5F53\u524D\u7248\u672C",
    "options.latestVersion": "\u6700\u65B0\u7248\u672C",
    "options.updateChecking": "\u6B63\u5728\u68C0\u67E5\u66F4\u65B0\u2026",
    "options.updateAvailable": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "options.updateUpToDate": "\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\u672C\u3002",
    "options.updateUnavailable": "\u6682\u65F6\u65E0\u6CD5\u68C0\u67E5\u66F4\u65B0\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "options.translationService": "\u7FFB\u8BD1\u670D\u52A1",
    "options.serviceHelp": "\u586B\u5199\u670D\u52A1\u5BC6\u94A5\u5E76\u52A0\u8F7D\u6A21\u578B\uFF0C\u4E09\u9879\u914D\u7F6E\u5B8C\u6574\u540E\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.setupSteps": "\u7FFB\u8BD1\u670D\u52A1\u914D\u7F6E\u6B65\u9AA4",
    "options.stepProvider": "\u670D\u52A1\u5546",
    "options.stepApiKey": "API Key",
    "options.stepModel": "\u6A21\u578B",
    "options.stepComplete": "\u5DF2\u5B8C\u6210",
    "options.stepCurrent": "\u5F53\u524D\u6B65\u9AA4",
    "options.stepNeedsApiKey": "\u8BF7\u586B\u5199\u5BC6\u94A5",
    "options.stepNeedsModel": "\u8BF7\u52A0\u8F7D\u6A21\u578B",
    "options.serviceKey": "\u670D\u52A1\u5BC6\u94A5\uFF08API Key\uFF09",
    "options.keyHelp": "\u5BC6\u94A5\u53EA\u4FDD\u5B58\u5728\u672C\u673A\uFF0C\u7528\u4E8E\u8FDE\u63A5\u4F60\u9009\u62E9\u7684\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.createApiKey": "\u524D\u5F80 {name} \u521B\u5EFA API Key",
    "options.loadModels": "\u52A0\u8F7D\u6A21\u578B",
    "options.translationModel": "\u7FFB\u8BD1\u6A21\u578B",
    "options.subtitleDisplay": "\u5B57\u5E55\u663E\u793A",
    "options.subtitlePreview": "\u5373\u65F6\u9884\u89C8",
    "options.previewPlayer": "\u64AD\u653E\u5668",
    "options.previewTranslation": "\u7B54\u6848\u5DF2\u7ECF\u5728\u7EC6\u8282\u91CC\u3002",
    "options.previewOriginal": "The answer is already in the details.",
    "options.captionMode": "\u5B57\u5E55\u6A21\u5F0F",
    "options.originalOnly": "\u4EC5\u663E\u793A\u539F\u6587",
    "options.translationOnly": "\u4EC5\u663E\u793A\u8BD1\u6587",
    "options.bilingual": "\u539F\u6587 + \u8BD1\u6587",
    "options.captionModeHelp": "\u9009\u62E9\u89C6\u9891\u4E2D\u7684\u5B57\u5E55\u5448\u73B0\u65B9\u5F0F\uFF0C\u4FDD\u5B58\u540E\u4F1A\u7ACB\u5373\u5E94\u7528\u5230\u6B63\u5728\u64AD\u653E\u7684\u89C6\u9891\u3002",
    "options.enableShortsTranslation": "\u542F\u7528 Shorts \u7FFB\u8BD1",
    "options.shortsTranslationHelp": "\u5173\u95ED\u540E\uFF0CShorts \u64AD\u653E\u5668\u4E2D\u4E0D\u663E\u793A\u7FFB\u8BD1\u6309\u94AE\uFF1B\u8BC4\u8BBA\u7FFB\u8BD1\u4E0D\u53D7\u5F71\u54CD\u3002",
    "options.subtitleStyle": "\u5B57\u5E55\u6837\u5F0F",
    "options.translationColor": "\u8BD1\u6587\u989C\u8272",
    "options.originalColor": "\u539F\u6587\u989C\u8272",
    "options.translationFontSize": "\u8BD1\u6587\u5B57\u53F7",
    "options.originalFontSize": "\u539F\u6587\u5B57\u53F7",
    "options.captionPositionHelp": "\u5B57\u5E55\u5728\u64AD\u653E\u5668\u5185\u53EF\u4E0A\u4E0B\u62D6\u52A8\u4EE5\u907F\u5F00\u753B\u9762\u5185\u5BB9\uFF1B\u4F4D\u7F6E\u548C\u6837\u5F0F\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.resetCaptionStyle": "\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u4F4D\u7F6E",
    "options.pageTranslation": "\u9875\u9762\u7FFB\u8BD1",
    "options.viewTranslation": "\u89C2\u770B\u9875\u7FFB\u8BD1\u529F\u80FD",
    "options.autoTranslateTitle": "\u81EA\u52A8\u7FFB\u8BD1\u89C6\u9891\u6807\u9898",
    "options.autoTranslateTitleHelp": "\u539F\u6807\u9898\u4F1A\u7ACB\u5373\u663E\u793A\uFF0C\u8BD1\u6587\u51C6\u5907\u597D\u540E\u4F1A\u663E\u793A\u5728\u4E0B\u65B9\u3002",
    "options.selectionTranslation": "\u5212\u8BCD\u7FFB\u8BD1",
    "options.enableSelectionTranslation": "\u542F\u7528\u5212\u8BCD\u7FFB\u8BD1",
    "options.selectionDisabledHelp": "\u5173\u95ED\u540E\uFF0C\u9009\u4E2D\u6587\u5B57\u4E0D\u4F1A\u663E\u793A\u7FFB\u8BD1\u6D6E\u5C42\uFF0C\u53F3\u952E\u83DC\u5355\u4E5F\u4E0D\u4F1A\u89E6\u53D1\u5212\u8BCD\u7FFB\u8BD1\u3002",
    "options.includeContext": "\u7FFB\u8BD1\u9009\u4E2D\u6587\u672C\u65F6\u53C2\u8003\u524D\u540E\u6587",
    "options.includeContextHelp": "\u5F00\u542F\u540E\u4F1A\u7ED3\u5408\u524D\u540E\u53E5\uFF0C\u8BA9\u7FFB\u8BD1\u66F4\u8D34\u5408\u8BED\u5883\u3002",
    "options.translationHistory": "\u7FFB\u8BD1\u8BB0\u5F55",
    "options.dataMaintenance": "\u6570\u636E\u4E0E\u7EF4\u62A4",
    "options.historyHelp": "\u6700\u8FD1\u8BB0\u5F55\u4F18\u5148\u663E\u793A\uFF0C\u9700\u8981\u65F6\u518D\u5C55\u5F00\u5B8C\u6574\u5217\u8868\u3002",
    "options.historyCount": "{count} \u6761\u8BB0\u5F55",
    "options.viewAllHistory": "\u67E5\u770B\u5168\u90E8 {count} \u6761\u8BB0\u5F55",
    "options.showRecentHistory": "\u53EA\u770B\u6700\u8FD1\u8BB0\u5F55",
    "options.emptyHistory": "\u8FD8\u6CA1\u6709\u4FDD\u5B58\u7684\u7FFB\u8BD1\u8BB0\u5F55\u3002",
    "options.reload": "\u91CD\u65B0\u52A0\u8F7D",
    "options.clearHistory": "\u6E05\u7A7A\u8BB0\u5F55",
    "options.confirmClearHistory": "\u786E\u5B9A\u8981\u6E05\u7A7A\u5168\u90E8\u7FFB\u8BD1\u8BB0\u5F55\u5417\uFF1F\u6B64\u64CD\u4F5C\u65E0\u6CD5\u64A4\u9500\u3002",
    "options.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u8BE5\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.enterApiKey": "\u8BF7\u586B\u5199 API Key \u540E\u52A0\u8F7D\u6A21\u578B\u3002",
    "options.findingModels": "\u6B63\u5728\u67E5\u627E\u53EF\u7528\u6A21\u578B\u2026",
    "options.modelsFound": "\u627E\u5230 {count} \u4E2A\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsFoundEnterKey": "\u627E\u5230 {count} \u4E2A\u6A21\u578B\uFF0C\u8BF7\u586B\u5199 API Key \u540E\u4FDD\u5B58\u3002",
    "options.noModels": "\u6CA1\u6709\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsUnavailable": "\u6A21\u578B\u5217\u8868\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u670D\u52A1\u5BC6\u94A5\u3002",
    "options.historyUnavailable": "\u7FFB\u8BD1\u8BB0\u5F55\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002",
    "options.historyStats": "\u5DF2\u4FDD\u5B58 {count} \u6761\u8BB0\u5F55 \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} \u6BB5 \xB7 {date}",
    "options.delete": "\u5220\u9664",
    "options.deleteHistoryEntry": "\u5220\u9664 {title} \u7684\u7FFB\u8BD1\u8BB0\u5F55",
    "options.deleteFailed": "\u5220\u9664\u8FD9\u6761\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.saving": "\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\u2026",
    "options.saved": "\u914D\u7F6E\u5DF2\u4FDD\u5B58\u3002",
    "options.saveFailed": "\u914D\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.preferencesSaveFailed": "\u504F\u597D\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.apiKeyChanged": "API Key \u5DF2\u53D8\u5316\uFF0C\u8BF7\u70B9\u51FB\u201C\u52A0\u8F7D\u6A21\u578B\u201D\u3002",
    "options.loadingConfiguredModels": "\u6B63\u5728\u52A0\u8F7D\u5DF2\u914D\u7F6E\u6A21\u578B\u2026",
    "options.clearFailed": "\u6E05\u7A7A\u7FFB\u8BD1\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.captionStyleRestored": "\u5DF2\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u81EA\u52A8\u4F4D\u7F6E\u3002",
    "options.loadFailed": "\u504F\u597D\u8BBE\u7F6E\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5\u3002",
    "content.pageUnsupported": "\u5F53\u524D YouTube \u9875\u9762\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\u3002",
    "content.captionHttp": "\u5B57\u5E55\u94FE\u63A5\u5DF2\u5931\u6548\u6216\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "content.captionNetwork": "\u65E0\u6CD5\u8BFB\u53D6\u5B57\u5E55\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
    "content.captionUnsupported": "\u5F53\u524D\u5B57\u5E55\u683C\u5F0F\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "content.partialTranslation": "\u7FFB\u8BD1\u672A\u5B8C\u6210\uFF0C\u90E8\u5206\u5B57\u5E55\u5DF2\u5B8C\u6210\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.startTranslation": "\u5F00\u59CB\u7FFB\u8BD1",
    "content.cacheLoaded": "\u5DF2\u52A0\u8F7D\u7F13\u5B58\uFF1A{count} \u6BB5",
    "content.translateAgain": "\u518D\u6B21\u7FFB\u8BD1",
    "content.translating": "\u7FFB\u8BD1\u4E2D",
    "content.readingCache": "\u6B63\u5728\u8BFB\u53D6\u7F13\u5B58\u2026",
    "content.noCaptionsOrCache": "\u5F53\u524D\u89C6\u9891\u6CA1\u6709\u53EF\u7528\u5B57\u5E55\uFF0C\u4E14\u6CA1\u6709\u672C\u5730\u7FFB\u8BD1\u7F13\u5B58\u3002",
    "content.retryCaptions": "\u91CD\u8BD5\u5B57\u5E55",
    "content.readingCaptions": "\u6B63\u5728\u8BFB\u53D6\u5B57\u5E55\u2026",
    "content.translatingSegments": "\u6B63\u5728\u7FFB\u8BD1 {count} \u6BB5\u2026",
    "content.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {translated}/{total}\u2026",
    "content.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "content.noTranslation": "\u65E0\u9700\u7FFB\u8BD1",
    "content.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210\uFF1A{count} \u6BB5",
    "content.translationCompleteProgress": "\u7FFB\u8BD1\u5B8C\u6210 {translated}/{total}",
    "content.continueTranslation": "\u7EE7\u7EED\u7FFB\u8BD1",
    "content.partialTranslationProgress": "\u5DF2\u5B8C\u6210 {translated}/{total}\uFF0C\u5269\u4F59 {missing} \u9879\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.retry": "\u91CD\u8BD5",
    "content.serviceUnavailable": "\u65E0\u6CD5\u8FDE\u63A5\u5230\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u8BBE\u7F6E\u540E\u91CD\u8BD5\u3002",
    "content.captionPosition": "\u4E0A\u4E0B\u62D6\u52A8\u53EF\u8C03\u6574\u5B57\u5E55\u4F4D\u7F6E",
    "content.translatingTitle": "\u6B63\u5728\u7FFB\u8BD1\u6807\u9898\u2026",
    "content.titleTranslationFailed": "\u6807\u9898\u7FFB\u8BD1\u5931\u8D25\u3002",
    "content.retryTitleTranslation": "\u91CD\u8BD5",
    "content.translateDescription": "\u7FFB\u8BD1\u7B80\u4ECB",
    "content.descriptionActionAria": "xTranslator\uFF1A{action}",
    "content.translatingDescription": "\u6B63\u5728\u7FFB\u8BD1\u7B80\u4ECB\u2026",
    "content.descriptionTranslation": "\u8BD1\u6587",
    "content.descriptionTranslationFailed": "\u7B80\u4ECB\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5\u3002",
    "content.hideDescriptionTranslation": "\u6536\u8D77\u8BD1\u6587",
    "content.showDescriptionTranslation": "\u663E\u793A\u8BD1\u6587",
    "comment.translateVisible": "\u7FFB\u8BD1\u53EF\u89C1\u7684 {count} \u6761",
    "comment.translateVisiblePrefix": "\u7FFB\u8BD1\u53EF\u89C1\u7684",
    "comment.translateVisibleAria": "\u7FFB\u8BD1\u5F53\u524D\u53EF\u89C1\u7684 {count} \u6761\u8BC4\u8BBA",
    "comment.translateThread": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translateThreadAria": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translatedVisible": "\u5DF2\u7FFB\u8BD1 {count} \u6761\u8BC4\u8BBA",
    "comment.translatedThread": "\u5DF2\u7FFB\u8BD1\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.noExpandedReplies": "\u672A\u53D1\u73B0\u5DF2\u5C55\u5F00\u56DE\u590D",
    "comment.noTranslatableComments": "\u672A\u53D1\u73B0\u53EF\u8BD1\u8BC4\u8BBA",
    "comment.translating": "\u7FFB\u8BD1\u4E2D\u2026",
    "comment.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {completed}/{total}\u2026",
    "comment.retryIncomplete": "\u91CD\u8BD5\u672A\u5B8C\u6210\u7FFB\u8BD1",
    "comment.retryIncompleteCount": "\u91CD\u8BD5\u672A\u5B8C\u6210\uFF08{count}\uFF09",
    "comment.translationFailedRetry": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5",
    "comment.retryComment": "\u91CD\u8BD5\u7FFB\u8BD1\u8BC4\u8BBA\uFF1A{id}",
    "comment.retried": "\u5DF2\u91CD\u8BD5",
    "selection.toolbar": "\u5212\u8BCD\u7FFB\u8BD1",
    "selection.translate": "\u7FFB\u8BD1",
    "selection.translateAria": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "selection.copyAria": "\u590D\u5236\u6240\u9009\u6587\u672C",
    "selection.closeAria": "\u5173\u95ED\u5212\u8BCD\u6D6E\u5C42",
    "selection.translating": "\u6B63\u5728\u7FFB\u8BD1\u2026",
    "selection.failed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "selection.copyTranslationAria": "\u590D\u5236\u8BD1\u6587",
    "selection.cancelAria": "\u53D6\u6D88\u7FFB\u8BD1",
    "selection.closeTranslationAria": "\u5173\u95ED\u8BD1\u6587\u9762\u677F",
    "background.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u5148\u5B8C\u6210\u504F\u597D\u8BBE\u7F6E\u3002",
    "background.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u7FFB\u8BD1\u670D\u52A1\uFF1A{id}",
    "background.noModel": "\u5C1A\u672A\u9009\u62E9\u7FFB\u8BD1\u6A21\u578B\uFF0C\u8BF7\u5148\u6253\u5F00\u8BBE\u7F6E\u52A0\u8F7D\u5E76\u9009\u62E9\u6A21\u578B\u3002",
    "background.contextMenu": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "background.videoFailed": "\u89C6\u9891\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "background.translationFailed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "translation.missingCaptions": "{count} \u6BB5\u5B57\u5E55\u6CA1\u6709\u83B7\u5F97\u6709\u6548\u8BD1\u6587\uFF0C\u5DF2\u4FDD\u5B58\u5DF2\u5B8C\u6210\u90E8\u5206\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.auth": "\u670D\u52A1\u5BC6\u94A5\u65E0\u6548\u6216\u6743\u9650\u4E0D\u8DB3\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u68C0\u67E5\u3002",
    "provider.rateLimit": "\u7FFB\u8BD1\u670D\u52A1\u5F53\u524D\u8F83\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "provider.timeout": "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.network": "\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u518D\u8BD5\u3002",
    "provider.model": "\u5F53\u524D\u6A21\u578B\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u66F4\u6362\u6A21\u578B\u3002",
    "provider.badResponse": "\u7FFB\u8BD1\u670D\u52A1\u6682\u65F6\u5F02\u5E38\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002"
  };
  var messages = { en, "zh-CN": zhCN };
  function getUiLocale(language = typeof navigator === "undefined" ? "" : navigator.language) {
    try {
      const locale = new Intl.Locale(language).maximize();
      return locale.language === "zh" && locale.script === "Hans" ? "zh-CN" : "en";
    } catch {
      return language.toLowerCase() === "zh-cn" ? "zh-CN" : "en";
    }
  }
  function translate(locale, key, values = {}) {
    return messages[locale][key].replace(/\{(\w+)\}/gu, (placeholder, name) => {
      const value = values[name];
      return value === void 0 ? placeholder : String(value);
    });
  }
  function t(key, values = {}) {
    return translate(getUiLocale(), key, values);
  }
  function translateAttribute(key) {
    return key in en ? t(key) : null;
  }
  function localizeDocument(documentNode) {
    documentNode.documentElement.lang = getUiLocale();
    documentNode.querySelectorAll("[data-i18n]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18n ?? "");
      if (translated !== null) {
        element.textContent = translated;
      }
    });
    documentNode.querySelectorAll("[data-i18n-aria-label]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18nAriaLabel ?? "");
      if (translated !== null) {
        element.setAttribute("aria-label", translated);
      }
    });
    documentNode.querySelectorAll("[data-i18n-title]").forEach((element) => {
      const translated = translateAttribute(element.dataset.i18nTitle ?? "");
      if (translated !== null) {
        element.setAttribute("title", translated);
      }
    });
    const title = documentNode.querySelector("title[data-i18n]");
    if (title) {
      documentNode.title = title.textContent ?? documentNode.title;
    }
  }

  // src/popup/index.ts
  function queryRequired(selector) {
    const element = document.querySelector(selector);
    if (!element) {
      throw new Error(`Missing popup element: ${selector}`);
    }
    return element;
  }
  function updateConfig(response) {
    const detail = queryRequired("#config-detail");
    const panel = queryRequired("#config-panel");
    const preset = getProviderPreset(response.settings.provider.providerId);
    const name = preset?.displayName ?? response.settings.provider.providerId;
    const model = response.settings.provider.model;
    if (resolveProviderApiKey(response.settings)) {
      detail.textContent = t("popup.connected", { name, model: model ? ` \xB7 ${model}` : "" });
      panel.dataset.state = "ready";
    } else {
      detail.textContent = t("popup.notConnected");
      panel.dataset.state = "error";
    }
  }
  function formatLocaleName(locale) {
    try {
      return new Intl.DisplayNames([getUiLocale()], { type: "language" }).of(locale) ?? locale;
    } catch {
      return locale;
    }
  }
  function updateLocale(response) {
    const detail = queryRequired("#locale-detail");
    const panel = queryRequired("#locale-panel");
    detail.textContent = t("popup.browserLanguage", { language: formatLocaleName(response.resolvedTargetLocale) });
    panel.dataset.state = "ready";
  }
  function updateVideoTranslationStatus(status) {
    const title = queryRequired("#translation-video-title");
    const detail = queryRequired("#translation-detail");
    const panel = queryRequired("#translation-panel");
    title.textContent = status.videoTitle ?? t("popup.readyToTranslate");
    switch (status.phase) {
      case "idle":
        detail.textContent = t("popup.openYoutubeVideo");
        panel.dataset.state = "idle";
        break;
      case "reading-captions":
        detail.textContent = t("popup.preparingCaptions");
        panel.dataset.state = "loading";
        break;
      case "ready-for-translation":
        detail.textContent = t("popup.captionsReady");
        panel.dataset.state = "success";
        break;
      case "translating":
        detail.textContent = t("popup.translatingCaptions", { count: status.segmentCount ?? 0 });
        panel.dataset.state = "loading";
        break;
      case "translated":
        detail.textContent = status.segmentCount === 0 ? t("popup.noTranslationNeeded") : t("popup.translationComplete", { translated: status.translatedCount ?? 0, total: status.segmentCount ?? 0 });
        panel.dataset.state = "success";
        break;
      case "error":
        detail.textContent = status.errorMessage ?? t("popup.videoUnavailable");
        panel.dataset.state = "error";
        break;
    }
  }
  async function loadConfig() {
    try {
      const response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.getSettings });
      if (!isSettingsMessageResponse(response)) {
        throw new Error("Invalid settings response.");
      }
      updateConfig(response);
      updateLocale(response);
    } catch {
    }
  }
  async function loadVideoTranslationStatus() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tabs[0]?.id;
      const response = await chrome.runtime.sendMessage({
        type: MESSAGE_TYPE.getVideoTranslationStatus,
        ...typeof tabId === "number" ? { tabId } : {}
      });
      if (!isVideoTranslationStatus(response)) {
        throw new Error("Invalid video translation status.");
      }
      updateVideoTranslationStatus(response);
    } catch {
      updateVideoTranslationStatus({ phase: "error", errorMessage: t("popup.statusUnavailable") });
    }
  }
  function bindOptionsButton() {
    queryRequired("#open-options").addEventListener("click", () => {
      void chrome.runtime.openOptionsPage();
    });
  }
  async function loadUpdate() {
    const result = await checkForExtensionUpdate(chrome.runtime.getManifest().version);
    if (result.state === "available") {
      const panel = queryRequired("#update-panel");
      const detail = queryRequired("#update-detail");
      const link = queryRequired("#download-update");
      detail.textContent = t("popup.updateDetail", { version: result.update.version });
      link.href = result.update.downloadUrl;
      panel.hidden = false;
    }
  }
  createIcons({ icons: { Settings } });
  localizeDocument(document);
  bindOptionsButton();
  void loadConfig();
  void loadVideoTranslationStatus();
  void loadUpdate();
  window.setInterval(() => void loadVideoTranslationStatus(), 1e3);
})();
//# sourceMappingURL=index.js.map
