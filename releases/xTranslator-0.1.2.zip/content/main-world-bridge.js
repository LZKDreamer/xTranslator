"use strict";
(() => {
  // src/shared/youtube/caption-request.ts
  var TIMEDTEXT_PATHNAME = "/api/timedtext";
  var GET_TRANSCRIPT_PATHNAME = "/youtubei/v1/get_transcript";
  function parseUrl(url) {
    try {
      return new URL(url);
    } catch {
      return null;
    }
  }
  function isCaptionRequestUrl(url) {
    const parsed = parseUrl(url);
    if (!parsed || parsed.hostname !== "www.youtube.com") {
      return false;
    }
    return parsed.pathname === TIMEDTEXT_PATHNAME || parsed.pathname === GET_TRANSCRIPT_PATHNAME;
  }
  function readCaptionVideoId(url) {
    if (!isCaptionRequestUrl(url)) {
      return null;
    }
    const videoId = parseUrl(url)?.searchParams.get("v");
    return videoId && videoId.length > 0 ? videoId : null;
  }

  // src/shared/youtube/main-world-messages.ts
  var CONTENT_BRIDGE_SOURCE = "xtranslator-content";
  var MAIN_WORLD_BRIDGE_SOURCE = "xtranslator-main-world";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isBridgeCaptionTrack(value) {
    if (!isRecord(value)) {
      return false;
    }
    return typeof value.baseUrl === "string" && value.baseUrl.length > 0 && typeof value.vssId === "string" && value.vssId.length > 0 && typeof value.languageCode === "string" && value.languageCode.length > 0;
  }
  function isRequestTranscriptMessage(value) {
    if (!isRecord(value) || value.source !== CONTENT_BRIDGE_SOURCE || value.type !== "request-transcript") {
      return false;
    }
    return typeof value.requestId === "string" && value.requestId.length > 0 && typeof value.videoId === "string" && value.videoId.length > 0 && isBridgeCaptionTrack(value.track);
  }
  function isRequestPlayerResponseMessage(value) {
    return isRecord(value) && value.source === CONTENT_BRIDGE_SOURCE && value.type === "request-player-response" && typeof value.requestId === "string" && value.requestId.length > 0 && typeof value.videoId === "string" && value.videoId.length > 0;
  }

  // src/shared/youtube/youtube-page-contract.ts
  var YOUTUBE_PAGE_SELECTOR = {
    // Shorts uses a separate player host from the regular watch page, but keeps
    // the same YouTube player controls and caption APIs inside it.
    player: "#movie_player, #shorts-player",
    playerRightControls: ".ytp-right-controls",
    playerTopControls: ".ytp-chrome-top-buttons",
    progressBarContainer: ".ytp-progress-bar-container",
    title: "ytd-watch-metadata h1, ytd-reel-player-header-renderer #title",
    description: "#description-inline-expander, ytd-reel-player-header-renderer #description",
    descriptionText: "#description-inline-expander #expanded > yt-attributed-string",
    descriptionCollapse: "#description-inline-expander #collapse",
    subtitleButton: ".ytp-subtitles-button",
    captionWindow: ".ytp-caption-window-container",
    playerResponseScripts: "script",
    extensionMount: "[data-xtranslator-mount]",
    // A Short opens comments in an engagement panel. Depending on the current
    // YouTube rollout, the panel either contains `#comments` or is itself the
    // stable root while comments are hydrated lazily.
    shortsCommentsRoot: "ytd-reel-engagement-panel-section-renderer ytd-comments, ytd-reel-engagement-panel-section-renderer[target-id='engagement-panel-comments-section'], ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-comments-section']",
    commentsRoot: "#comments, ytd-reel-engagement-panel-section-renderer ytd-comments, ytd-reel-engagement-panel-section-renderer[target-id='engagement-panel-comments-section'], ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-comments-section']",
    // The comment element tag changed to `ytd-comment-view-model`; keep the older
    // `ytd-comment-renderer` as a fallback so the adapter tolerates both layouts.
    comment: "ytd-comment-view-model, ytd-comment-renderer",
    commentThread: "ytd-comment-thread-renderer, ytd-comment-thread-view-model",
    commentContent: "#content-text",
    commentContentContainer: "#content",
    commentExpander: "#expander",
    commentAuthor: "#author-text, ytd-comment-view-model #author-text",
    commentHeader: "ytd-comments-header-renderer",
    commentRepliesContainer: "ytd-comment-replies-renderer, ytd-comment-replies-view-model",
    commentPermalink: "a[href*='lc=']",
    commentReplyCount: "#reply-count-end, #comment-count",
    // Reply expand controls are owned by YouTube. The extension never expands
    // replies as a side effect of translation.
    commentReplyExpand: "[id='more-replies'], [id='more-replies-sub-thread']"
  };

  // src/content/main-world-bridge.ts
  var CAPTION_ACQUISITION_TIMEOUT_MS = 1e4;
  var ACQUISITION_POLL_MS = 150;
  var CAPTION_TRIGGER_RETRY_MS = 2500;
  var CAPTION_BUTTON_STATE_TIMEOUT_MS = 1e3;
  var CAPTION_HIDE_STYLE_ID = "xtranslator-hide-captions";
  var pendingCaptionCapture = null;
  function readPlayerResponseVideoId(response) {
    if (typeof response !== "object" || response === null) {
      return null;
    }
    const videoDetails = response.videoDetails;
    if (typeof videoDetails !== "object" || videoDetails === null) {
      return null;
    }
    const videoId = videoDetails.videoId;
    return typeof videoId === "string" && videoId.length > 0 ? videoId : null;
  }
  function readCurrentPlayerResponse(videoId) {
    const player = document.querySelector(YOUTUBE_PAGE_SELECTOR.player);
    const candidates = [];
    try {
      candidates.push(player?.getPlayerResponse?.());
    } catch {
    }
    candidates.push(window.ytInitialPlayerResponse);
    return candidates.find((response) => readPlayerResponseVideoId(response) === videoId) ?? null;
  }
  function setCaptionOverlayHidden(hidden) {
    let style = document.getElementById(CAPTION_HIDE_STYLE_ID);
    if (hidden) {
      if (!style) {
        style = document.createElement("style");
        style.id = CAPTION_HIDE_STYLE_ID;
        style.textContent = `${YOUTUBE_PAGE_SELECTOR.captionWindow} { visibility: hidden !important; }`;
        (document.head ?? document.documentElement).append(style);
      }
      return;
    }
    style?.remove();
  }
  function storeCaptionBody(url, body) {
    const videoId = readCaptionVideoId(url);
    const capture = pendingCaptionCapture;
    if (!capture || videoId !== capture.videoId || !body || body.trim().length === 0) {
      return;
    }
    try {
      const parsed = new URL(url);
      const requestedVssId = parsed.searchParams.get("vss_id");
      const requestedLanguage = parsed.searchParams.get("lang");
      const requestedKind = parsed.searchParams.get("kind");
      if (requestedVssId && requestedVssId !== capture.track.vssId) {
        return;
      }
      if (requestedLanguage && requestedLanguage !== capture.track.languageCode) {
        return;
      }
      if (requestedKind && requestedKind !== (capture.track.kind ?? "")) {
        return;
      }
    } catch {
      return;
    }
    capture.body = body;
  }
  function installFetchHook() {
    const originalFetch = window.fetch.bind(window);
    window.fetch = (input, init) => {
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const result = originalFetch(input, init);
      if (url && isCaptionRequestUrl(url)) {
        void result.then((response) => {
          void response.clone().text().then((body) => storeCaptionBody(url, body)).catch(() => void 0);
        }).catch(() => void 0);
      }
      return result;
    };
  }
  function installXhrHook() {
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(...args) {
      const url = args[1];
      if (typeof url === "string" || url instanceof URL) {
        this.__xtranslatorCaptionUrl = String(url);
      }
      return originalOpen.apply(this, args);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      const recorded = this.__xtranslatorCaptionUrl;
      if (recorded) {
        try {
          if (isCaptionRequestUrl(recorded)) {
            this.addEventListener("load", () => {
              try {
                storeCaptionBody(recorded, this.responseText ?? "");
              } catch {
              }
            });
          }
        } catch {
        }
      }
      return originalSend.apply(this, args);
    };
  }
  function isCaptionButtonPressed(button) {
    return button.getAttribute("aria-pressed") === "true" || button.classList.contains("ytp-button-pressed");
  }
  async function waitForCaptionButtonState(button, pressed) {
    const deadline = Date.now() + CAPTION_BUTTON_STATE_TIMEOUT_MS;
    while (Date.now() < deadline && isCaptionButtonPressed(button) !== pressed) {
      await sleep(50);
    }
  }
  async function selectCaptionTrack(player, track) {
    const withApi = player;
    if (typeof withApi.setOption === "function") {
      try {
        withApi.setOption("captions", "track", {
          vssId: track.vssId,
          languageCode: track.languageCode,
          kind: track.kind ?? "",
          isTranslatable: track.isTranslatable ?? true
        });
        withApi.setOption("captions", "reload", true);
        return true;
      } catch {
      }
    }
    const subtitlesButton = document.querySelector(YOUTUBE_PAGE_SELECTOR.subtitleButton);
    if (subtitlesButton) {
      if (isCaptionButtonPressed(subtitlesButton)) {
        subtitlesButton.click();
        await waitForCaptionButtonState(subtitlesButton, false);
        if (isCaptionButtonPressed(subtitlesButton)) {
          return false;
        }
      }
      subtitlesButton.click();
      await waitForCaptionButtonState(subtitlesButton, true);
      return true;
    }
    return false;
  }
  function readCaptionState(player) {
    const withApi = player;
    if (typeof withApi.getOption === "function") {
      try {
        const track = withApi.getOption("captions", "track");
        if (track) {
          return { wasOn: true, previousTrack: track };
        }
      } catch {
      }
    }
    const button = document.querySelector(YOUTUBE_PAGE_SELECTOR.subtitleButton);
    return { wasOn: button ? isCaptionButtonPressed(button) : false };
  }
  function restoreCaptionState(player, state) {
    const withApi = player;
    if (state.wasOn) {
      if (typeof withApi.setOption === "function" && state.previousTrack !== void 0) {
        try {
          withApi.setOption("captions", "track", state.previousTrack);
          withApi.setOption("captions", "reload", true);
        } catch {
        }
      } else {
        const button2 = document.querySelector(YOUTUBE_PAGE_SELECTOR.subtitleButton);
        if (button2 && !isCaptionButtonPressed(button2)) {
          button2.click();
        }
      }
      return;
    }
    const button = document.querySelector(YOUTUBE_PAGE_SELECTOR.subtitleButton);
    if (button && isCaptionButtonPressed(button)) {
      button.click();
      return;
    }
    if (typeof withApi.setOption === "function") {
      try {
        withApi.setOption("captions", "track", null);
        withApi.setOption("captions", "reload", true);
      } catch {
      }
    }
  }
  async function triggerCaptionLoad(track) {
    const player = document.querySelector(YOUTUBE_PAGE_SELECTOR.player);
    return player ? selectCaptionTrack(player, track) : false;
  }
  function sleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
  async function obtainTranscript(videoId, track) {
    const capture = { videoId, track, body: null };
    pendingCaptionCapture = capture;
    const player = document.querySelector(YOUTUBE_PAGE_SELECTOR.player);
    const state = player ? readCaptionState(player) : { wasOn: false };
    setCaptionOverlayHidden(true);
    const deadline = Date.now() + CAPTION_ACQUISITION_TIMEOUT_MS;
    let changedPlayerState = false;
    let body = null;
    while (Date.now() < deadline) {
      changedPlayerState = await triggerCaptionLoad(track) || changedPlayerState;
      body = capture.body;
      if (body) {
        break;
      }
      const retryDeadline = Math.min(Date.now() + CAPTION_TRIGGER_RETRY_MS, deadline);
      while (Date.now() < retryDeadline && !capture.body) {
        await sleep(ACQUISITION_POLL_MS);
      }
      body = capture.body;
    }
    if (player && changedPlayerState) {
      restoreCaptionState(player, state);
    }
    setCaptionOverlayHidden(false);
    if (pendingCaptionCapture === capture) {
      pendingCaptionCapture = null;
    }
    return body;
  }
  function postToContent(message) {
    window.postMessage(message, window.location.origin);
  }
  function replyWithFailure(requestId, reason) {
    postToContent({ source: MAIN_WORLD_BRIDGE_SOURCE, type: "transcript-error", requestId, reason });
  }
  function installMessageListener() {
    window.addEventListener("message", (event) => {
      if (event.origin !== window.location.origin) {
        return;
      }
      const message = event.data;
      if (isRequestPlayerResponseMessage(message)) {
        const response = readCurrentPlayerResponse(message.videoId);
        postToContent({ source: MAIN_WORLD_BRIDGE_SOURCE, type: "player-response-ready", requestId: message.requestId, response });
        return;
      }
      if (!isRequestTranscriptMessage(message)) {
        return;
      }
      void (async () => {
        const body = await obtainTranscript(message.videoId, message.track);
        if (body) {
          postToContent({ source: MAIN_WORLD_BRIDGE_SOURCE, type: "transcript-ready", requestId: message.requestId, body });
        } else {
          replyWithFailure(message.requestId, "no-caption-fetch");
        }
      })();
    });
  }
  if (typeof window.fetch === "function") {
    installFetchHook();
  }
  if (typeof XMLHttpRequest !== "undefined") {
    installXhrHook();
  }
  installMessageListener();
})();
//# sourceMappingURL=main-world-bridge.js.map
