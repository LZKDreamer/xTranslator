"use strict";
(() => {
  // src/shared/icons/index.ts
  var SVG_ATTRIBUTES = 'xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  function svgFromIcon(icon) {
    const container = document.createElement("div");
    container.innerHTML = `<svg ${SVG_ATTRIBUTES}>${icon.elementMarkup}</svg>`;
    const svg = container.firstElementChild;
    if (!(svg instanceof SVGElement)) {
      throw new Error(`Invalid icon definition: ${icon.name}`);
    }
    return svg;
  }
  function createElement(icon) {
    return svgFromIcon(icon);
  }
  var Check = {
    name: "check",
    elementMarkup: '<path d="M20 6 9 17l-5-5"/>'
  };
  var CircleAlert = {
    name: "circle-alert",
    elementMarkup: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>'
  };
  var MousePointer2 = {
    name: "mouse-pointer-2",
    elementMarkup: '<path d="m4 4 7.07 17 2.51-7.39L21 11.07z"/>'
  };
  var Copy = {
    name: "copy",
    elementMarkup: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>'
  };
  var X = {
    name: "x",
    elementMarkup: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>'
  };
  var LoaderCircle = {
    name: "loader-circle",
    elementMarkup: '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>'
  };

  // src/shared/brand-assets.ts
  var BRAND_MARK_PATH = {
    dark: "icons/icon-32.png",
    light: "icons/icon-light-32.png"
  };
  var FALLBACK_BRAND_MARK_URL = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='8' fill='%23192345'/%3E%3Cpath d='M9 8l15 16M23 8L8 24' fill='none' stroke='%2333d6ff' stroke-linecap='round' stroke-width='4'/%3E%3Cpath d='M10 8l14 16M22 8L8 24' fill='none' stroke='%23a78bfa' stroke-linecap='round' stroke-width='2'/%3E%3C/svg%3E";
  function resolveBrandMarkUrl(path) {
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
        return chrome.runtime.getURL(path);
      }
      return path;
    } catch {
      return null;
    }
  }
  function createBrandMark(documentNode, variant, size) {
    const image = documentNode.createElement("img");
    image.className = "xtranslator-brand-mark";
    const url = resolveBrandMarkUrl(BRAND_MARK_PATH[variant]);
    const useFallback = () => {
      if (image.dataset.fallbackApplied === "true") {
        return;
      }
      image.dataset.fallbackApplied = "true";
      image.src = FALLBACK_BRAND_MARK_URL;
    };
    image.addEventListener("error", useFallback, { once: true });
    image.src = url ?? FALLBACK_BRAND_MARK_URL;
    image.alt = "";
    image.width = size;
    image.height = size;
    image.setAttribute("aria-hidden", "true");
    return image;
  }

  // src/shared/contracts/settings.ts
  var DEFAULT_PROVIDER_ID = "deepseek";
  var DEFAULT_CAPTION_DISPLAY_MODE = "bilingual";
  var DEFAULT_API_KEYS = {};
  var DEFAULT_PROVIDER_MODELS = {};
  var DEFAULT_PROVIDER_SETTINGS = {
    providerId: DEFAULT_PROVIDER_ID,
    model: ""
  };
  var DEFAULT_SUBTITLE_SETTINGS = {
    displayMode: DEFAULT_CAPTION_DISPLAY_MODE,
    shortsTranslationEnabled: false,
    translationColor: "#ffd438",
    originalColor: "#ececf0",
    translationFontScale: 100,
    originalFontScale: 100,
    verticalPosition: null
  };
  var DEFAULT_SELECTION_SETTINGS = {
    enabled: true,
    includeContext: false
  };
  var DEFAULT_PAGE_TRANSLATION_SETTINGS = {
    autoTranslateTitle: true
  };
  var DEFAULT_SETTINGS = {
    provider: { ...DEFAULT_PROVIDER_SETTINGS },
    apiKeys: { ...DEFAULT_API_KEYS },
    providerModels: { ...DEFAULT_PROVIDER_MODELS },
    subtitles: { ...DEFAULT_SUBTITLE_SETTINGS },
    page: { ...DEFAULT_PAGE_TRANSLATION_SETTINGS },
    selection: { ...DEFAULT_SELECTION_SETTINGS }
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function parseCaptionDisplayMode(value) {
    if (value === "original" || value === "translation" || value === "bilingual") {
      return value;
    }
    return null;
  }
  function parseProviderSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    if (typeof value.providerId !== "string" || !value.providerId.trim()) {
      return null;
    }
    if (typeof value.model !== "string") {
      return null;
    }
    return {
      providerId: value.providerId.trim(),
      model: value.model.trim()
    };
  }
  function parseApiKeys(value) {
    if (!isRecord(value)) {
      return null;
    }
    const apiKeys = {};
    for (const [providerId, apiKey] of Object.entries(value)) {
      if (typeof apiKey !== "string") {
        return null;
      }
      apiKeys[providerId] = apiKey;
    }
    return apiKeys;
  }
  function parseProviderModels(value) {
    if (value === void 0) {
      return {};
    }
    if (!isRecord(value)) {
      return null;
    }
    const models = {};
    for (const [providerId, model] of Object.entries(value)) {
      if (typeof model !== "string") {
        return null;
      }
      models[providerId] = model.trim();
    }
    return models;
  }
  function parseSubtitleSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const displayMode = parseCaptionDisplayMode(value.displayMode);
    if (!displayMode) {
      return null;
    }
    const shortsTranslationEnabled2 = value.shortsTranslationEnabled === void 0 ? DEFAULT_SUBTITLE_SETTINGS.shortsTranslationEnabled : value.shortsTranslationEnabled;
    if (typeof shortsTranslationEnabled2 !== "boolean") {
      return null;
    }
    const translationColor = value.translationColor === void 0 ? DEFAULT_SUBTITLE_SETTINGS.translationColor : parseCaptionColor(value.translationColor);
    const originalColor = value.originalColor === void 0 ? DEFAULT_SUBTITLE_SETTINGS.originalColor : parseCaptionColor(value.originalColor);
    const translationFontScale = value.translationFontScale === void 0 ? DEFAULT_SUBTITLE_SETTINGS.translationFontScale : parseCaptionFontScale(value.translationFontScale);
    const originalFontScale = value.originalFontScale === void 0 ? DEFAULT_SUBTITLE_SETTINGS.originalFontScale : parseCaptionFontScale(value.originalFontScale);
    if (!translationColor || !originalColor || !translationFontScale || !originalFontScale) {
      return null;
    }
    const verticalPosition = parseVerticalCaptionPosition(value.verticalPosition);
    if (verticalPosition === void 0) {
      return null;
    }
    return {
      displayMode,
      shortsTranslationEnabled: shortsTranslationEnabled2,
      translationColor,
      originalColor,
      translationFontScale,
      originalFontScale,
      verticalPosition
    };
  }
  function parsePageTranslationSettings(value) {
    if (value === void 0) {
      return { ...DEFAULT_PAGE_TRANSLATION_SETTINGS };
    }
    if (!isRecord(value)) {
      return null;
    }
    const autoTranslateTitle = value.autoTranslateTitle === void 0 ? DEFAULT_PAGE_TRANSLATION_SETTINGS.autoTranslateTitle : value.autoTranslateTitle;
    return typeof autoTranslateTitle === "boolean" ? { autoTranslateTitle } : null;
  }
  function parseCaptionColor(value) {
    return typeof value === "string" && /^#[0-9a-f]{6}$/iu.test(value) ? value.toLowerCase() : null;
  }
  function parseCaptionFontScale(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= 80 && value <= 160 ? value : null;
  }
  function parseVerticalCaptionPosition(value) {
    if (value === void 0 || value === null) {
      return null;
    }
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1 ? value : void 0;
  }
  function parseSelectionSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const enabled = value.enabled === void 0 ? true : value.enabled;
    if (typeof enabled !== "boolean") {
      return null;
    }
    if (typeof value.includeContext !== "boolean") {
      return null;
    }
    return { enabled, includeContext: value.includeContext };
  }
  function parseExtensionSettings(value) {
    if (!isRecord(value)) {
      return null;
    }
    const provider = parseProviderSettings(value.provider);
    if (!provider) {
      return null;
    }
    let apiKeys = parseApiKeys(value.apiKeys);
    if (!apiKeys) {
      const legacyKey = isRecord(value.provider) ? value.provider.apiKey : void 0;
      if (typeof legacyKey === "string") {
        apiKeys = { [provider.providerId]: legacyKey };
      } else {
        return null;
      }
    }
    const providerModels = parseProviderModels(value.providerModels);
    if (!providerModels) {
      return null;
    }
    if (provider.model && providerModels[provider.providerId] === void 0) {
      providerModels[provider.providerId] = provider.model;
    }
    const subtitles = parseSubtitleSettings(value.subtitles);
    if (!subtitles) {
      return null;
    }
    const page = parsePageTranslationSettings(value.page);
    if (!page) {
      return null;
    }
    const selection = parseSelectionSettings(value.selection);
    if (!selection) {
      return null;
    }
    return { provider, apiKeys, providerModels, subtitles, page, selection };
  }

  // src/shared/contracts/messages.ts
  var MESSAGE_TYPE = {
    getSettings: "get-settings",
    getVideoTranslationCache: "get-video-translation-cache",
    getVideoTranslationStatus: "get-video-translation-status",
    updateVideoTranslationStatus: "update-video-translation-status",
    translateVideo: "translate-video",
    translateVideoProgress: "translate-video-progress",
    translateText: "translate-text",
    translateTextProgress: "translate-text-progress",
    translateSelectionFromContext: "translate-selection-from-context",
    getCacheStats: "get-cache-stats",
    listCache: "list-cache",
    clearVideoCache: "clear-video-cache",
    clearAllCache: "clear-all-cache"
  };
  function isRecord2(value) {
    return typeof value === "object" && value !== null;
  }
  function parseTranslateTextProgress(value) {
    if (!isRecord2(value) || value.type !== MESSAGE_TYPE.translateTextProgress) {
      return null;
    }
    const isCount = (key) => typeof value[key] === "number" && Number.isSafeInteger(value[key]) && value[key] >= 0;
    if (typeof value.runId !== "string" || !value.runId || value.scope !== "comment" && value.scope !== "selection" && value.scope !== "title" && value.scope !== "description" || !isCount("completed") || !isCount("total") || !isCount("translated") || !isCount("failed") || value.completed > value.total || value.translated + value.failed > value.completed) {
      return null;
    }
    return {
      type: MESSAGE_TYPE.translateTextProgress,
      runId: value.runId,
      scope: value.scope,
      completed: value.completed,
      total: value.total,
      translated: value.translated,
      failed: value.failed
    };
  }
  function parseTranslatedBlock(value, allowEmptyTranslation = false) {
    if (!isRecord2(value)) {
      return null;
    }
    if (typeof value.id !== "string" || !value.id) {
      return null;
    }
    if (!Array.isArray(value.segmentIds) || !value.segmentIds.every((id) => typeof id === "string" && id.length > 0)) {
      return null;
    }
    const segmentIds = value.segmentIds.filter((id) => typeof id === "string");
    if (typeof value.sourceText !== "string") {
      return null;
    }
    if (typeof value.translatedText !== "string") {
      return null;
    }
    if (!allowEmptyTranslation && value.sourceText.trim() && !value.translatedText.trim()) {
      return null;
    }
    if (typeof value.startMs !== "number" || !Number.isFinite(value.startMs)) {
      return null;
    }
    if (typeof value.endMs !== "number" || !Number.isFinite(value.endMs)) {
      return null;
    }
    return {
      id: value.id,
      segmentIds,
      sourceText: value.sourceText,
      translatedText: value.translatedText,
      startMs: value.startMs,
      endMs: value.endMs
    };
  }
  function isTranslateVideoProgressMessage(value) {
    if (!isRecord2(value)) {
      return false;
    }
    return value.type === MESSAGE_TYPE.translateVideoProgress && typeof value.runId === "string" && value.runId.length > 0 && typeof value.videoId === "string" && value.videoId.length > 0 && typeof value.sourceTrackFingerprint === "string" && value.sourceTrackFingerprint.length > 0 && typeof value.targetLanguage === "string" && parseCaptionDisplayMode(value.displayMode) !== null && parseTranslatedBlock(value.block) !== null;
  }
  function isTranslateTextResponse(value) {
    if (!isRecord2(value)) {
      return false;
    }
    if (value.ok === true) {
      if (typeof value.targetLanguage !== "string" || !Array.isArray(value.missingIds)) {
        return false;
      }
      if (!value.missingIds.every((id) => typeof id === "string")) {
        return false;
      }
      return isRecord2(value.translations) && Object.entries(value.translations).every(([key, text]) => key.length > 0 && typeof text === "string") && (value.skippedIds === void 0 || Array.isArray(value.skippedIds) && value.skippedIds.every((id) => typeof id === "string")) && (value.errorMessage === void 0 || typeof value.errorMessage === "string");
    }
    return value.ok === false && typeof value.errorMessage === "string";
  }
  function isTranslateTextProgressMessage(value) {
    return parseTranslateTextProgress(value) !== null;
  }
  function isSettingsMessageResponse(value) {
    if (!isRecord2(value) || typeof value.resolvedTargetLocale !== "string") {
      return false;
    }
    const settings = value.settings;
    return isRecord2(settings) && isRecord2(settings.provider) && typeof settings.provider.providerId === "string" && typeof settings.provider.model === "string" && isRecord2(settings.apiKeys) && Object.values(settings.apiKeys).every((key) => typeof key === "string") && isRecord2(settings.providerModels) && Object.values(settings.providerModels).every((model) => typeof model === "string") && isRecord2(settings.subtitles) && parseCaptionDisplayMode(settings.subtitles.displayMode) !== null && isRecord2(settings.page) && typeof settings.page.autoTranslateTitle === "boolean" && isRecord2(settings.selection) && typeof settings.selection.enabled === "boolean" && typeof settings.selection.includeContext === "boolean";
  }
  function isTranslateVideoResponse(value) {
    if (!isRecord2(value)) {
      return false;
    }
    if (value.ok === true) {
      return typeof value.targetLanguage === "string" && parseCaptionDisplayMode(value.displayMode) !== null && typeof value.fromCache === "boolean" && (value.skipped === void 0 || typeof value.skipped === "boolean") && Array.isArray(value.missingIds) && value.missingIds.every((id) => typeof id === "string") && Array.isArray(value.blocks) && value.blocks.every((entry) => parseTranslatedBlock(entry) !== null);
    }
    if (value.ok !== false || typeof value.errorMessage !== "string") {
      return false;
    }
    if (value.partial === void 0) {
      return true;
    }
    if (!isRecord2(value.partial)) {
      return false;
    }
    return typeof value.partial.targetLanguage === "string" && parseCaptionDisplayMode(value.partial.displayMode) !== null && Array.isArray(value.partial.missingIds) && value.partial.missingIds.every((id) => typeof id === "string") && Array.isArray(value.partial.blocks) && value.partial.blocks.every((entry) => parseTranslatedBlock(entry, true) !== null);
  }
  function isVideoTranslationCacheResponse(value) {
    if (!isRecord2(value)) {
      return false;
    }
    if (value.found === false) {
      return true;
    }
    return value.found === true && typeof value.videoId === "string" && typeof value.videoTitle === "string" && typeof value.sourceTrackFingerprint === "string" && typeof value.sourceLanguage === "string" && typeof value.targetLanguage === "string" && parseCaptionDisplayMode(value.displayMode) !== null && Array.isArray(value.blocks) && value.blocks.every((entry) => parseTranslatedBlock(entry, true) !== null);
  }

  // src/shared/providers/provider-registry.ts
  var UNKNOWN_MODEL_CONTEXT_WINDOW_TOKENS = 8192;
  var PROVIDER_PRESETS = [
    {
      id: "deepseek",
      displayName: "DeepSeek",
      apiKeyUrl: "https://platform.deepseek.com/api_keys",
      kind: "openai-compatible",
      baseUrl: "https://api.deepseek.com",
      modelLimits: {
        "deepseek-v4-flash": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 },
        "deepseek-v4-pro": { contextWindowTokens: 1e6, maxOutputTokens: 384e3 }
      },
      requestBody: { thinking: { type: "disabled" } },
      requestPath: "/chat/completions",
      modelsPath: "/models"
    },
    {
      id: "openai",
      displayName: "OpenAI",
      apiKeyUrl: "https://platform.openai.com/api-keys",
      kind: "openai-compatible",
      baseUrl: "https://api.openai.com",
      modelLimits: {
        "gpt-4o-mini": { contextWindowTokens: 128e3, maxOutputTokens: 16384 },
        "gpt-4o": { contextWindowTokens: 128e3, maxOutputTokens: 16384 }
      },
      requestPath: "/v1/chat/completions",
      modelsPath: "/v1/models"
    },
    {
      id: "anthropic",
      displayName: "Anthropic",
      apiKeyUrl: "https://platform.claude.com/settings/keys",
      kind: "anthropic-messages",
      baseUrl: "https://api.anthropic.com",
      modelLimits: {
        "claude-haiku-4-5-20251001": { contextWindowTokens: 2e5, maxOutputTokens: 64e3 },
        "claude-sonnet-5": { contextWindowTokens: 1e6, maxOutputTokens: 128e3 }
      },
      requestPath: "/v1/messages",
      modelsPath: "/v1/models"
    },
    {
      id: "agnes",
      displayName: "Agnes AI",
      apiKeyUrl: "https://platform.agnes-ai.com/settings/apiKeys",
      kind: "openai-compatible",
      baseUrl: "https://apihub.agnes-ai.com/v1",
      models: ["agnes-2.5-flash"],
      modelLimits: {
        "agnes-2.5-flash": { contextWindowTokens: 512e3, maxOutputTokens: 65536 }
      },
      requestPath: "/chat/completions"
    }
  ];
  function getProviderPreset(id) {
    return PROVIDER_PRESETS.find((preset) => preset.id === id) ?? null;
  }
  function getProviderModelLimits(preset, model) {
    return preset.modelLimits?.[model] ?? null;
  }
  function getProviderContextWindow(preset, model) {
    return getProviderModelLimits(preset, model)?.contextWindowTokens ?? UNKNOWN_MODEL_CONTEXT_WINDOW_TOKENS;
  }

  // src/shared/youtube/transcript-parser.ts
  function decodeXmlText(value) {
    return value.replace(/<[^>]+>/g, "").replace(/&#(x[\da-fA-F]+|\d+);/g, (_match, encoded) => {
      const codePoint = encoded.startsWith("x") ? Number.parseInt(encoded.slice(1), 16) : Number.parseInt(encoded, 10);
      return Number.isInteger(codePoint) && codePoint >= 0 && codePoint <= 1114111 ? String.fromCodePoint(codePoint) : "";
    }).replace(/&(amp|lt|gt|quot|apos);/g, (_match, entity) => {
      const entities = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
      return entities[entity] ?? "";
    }).replace(/\s+/g, " ").trim();
  }
  function readRequiredNumberAttribute(attributes, name) {
    const match = new RegExp(`\\b${name}\\s*=\\s*(["'])([^"']+)\\1`).exec(attributes);
    if (!match?.[2]) {
      return null;
    }
    const value = Number(match[2]);
    return Number.isFinite(value) && value >= 0 ? value : null;
  }
  function createStableSegmentId(trackFingerprint, startMs, durationMs, sourceText) {
    let hash = 2166136261;
    for (const character of `${trackFingerprint}\0${startMs}\0${durationMs}\0${sourceText}`) {
      hash ^= character.codePointAt(0) ?? 0;
      hash = Math.imul(hash, 16777619);
    }
    return `yt-${(hash >>> 0).toString(36)}`;
  }
  var XML_TRANSCRIPT = /^\s*(?:<\?xml[^>]*\?>\s*)?<transcript(?:\s[^>]*)?>([\s\S]*)<\/transcript>\s*$/;
  var XML_TEXT_SEGMENT = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
  function isRecord3(value) {
    return typeof value === "object" && value !== null;
  }
  function normalizeTranscriptText(value) {
    return value.replace(/\r\n?|[\u2028\u2029]/gu, " ").replace(/\u00a0/gu, " ").replace(/\u200B|\uFEFF/gu, "").replace(/\s+/gu, " ").trim();
  }
  function normalizeFragmentText(value) {
    return value.replace(/\r\n?|[\u2028\u2029]/gu, " ").replace(/\u00a0/gu, " ").replace(/\u200B|\uFEFF/gu, "");
  }
  function normalizeSegments(segments) {
    const seen = /* @__PURE__ */ new Set();
    const ordered = segments.filter((segment) => segment.durationMs > 0 && segment.sourceText.trim().length > 0).sort((a, b) => a.startMs - b.startMs || a.durationMs - b.durationMs).filter((segment) => {
      const key = `${segment.startMs}\0${segment.durationMs}\0${segment.sourceText}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
    const normalized = [];
    for (const segment of ordered) {
      const previous = normalized[normalized.length - 1];
      const segmentEndMs = segment.startMs + segment.durationMs;
      if (previous && previous.sourceText === segment.sourceText && segment.startMs <= previous.startMs + previous.durationMs) {
        previous.durationMs = Math.max(previous.startMs + previous.durationMs, segmentEndMs) - previous.startMs;
        continue;
      }
      normalized.push({ ...segment });
    }
    return normalized;
  }
  function toMilliseconds(value) {
    if (typeof value === "number" && Number.isFinite(value) && value >= 0) {
      return Math.round(value);
    }
    if (typeof value === "string" && /^\d+(?:\.\d+)?$/.test(value.trim())) {
      const parsed = Number(value);
      return Number.isFinite(parsed) && parsed >= 0 ? Math.round(parsed) : null;
    }
    return null;
  }
  function parseJson3Fragments(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.flatMap((segment) => {
      if (!isRecord3(segment) || typeof segment.utf8 !== "string" || !segment.utf8) {
        return [];
      }
      const text = normalizeFragmentText(segment.utf8);
      if (!text.trim()) {
        return [];
      }
      const offsetMs = toMilliseconds(segment.tOffsetMs);
      return [{
        text,
        ...offsetMs !== null ? { offsetMs } : {}
      }];
    });
  }
  var YouTubeTranscriptParser = class {
    parse(trackFingerprint, responseBody) {
      return this.parseXml(trackFingerprint, responseBody) ?? this.parseJson3(trackFingerprint, responseBody);
    }
    parseXml(trackFingerprint, responseBody) {
      const transcript = XML_TRANSCRIPT.exec(responseBody);
      if (!transcript?.[1]) {
        return null;
      }
      const segments = [];
      XML_TEXT_SEGMENT.lastIndex = 0;
      for (const match of transcript[1].matchAll(XML_TEXT_SEGMENT)) {
        const attributes = match[1];
        const sourceText = decodeXmlText(match[2] ?? "");
        const startSeconds = attributes ? readRequiredNumberAttribute(attributes, "start") : null;
        const durationSeconds = attributes ? readRequiredNumberAttribute(attributes, "dur") : null;
        if (startSeconds === null || durationSeconds === null || !sourceText) {
          continue;
        }
        const startMs = Math.round(startSeconds * 1e3);
        const durationMs = Math.round(durationSeconds * 1e3);
        segments.push({
          id: createStableSegmentId(trackFingerprint, startMs, durationMs, sourceText),
          startMs,
          durationMs,
          sourceText
        });
      }
      const normalizedSegments = normalizeSegments(segments);
      return normalizedSegments.length > 0 ? normalizedSegments : null;
    }
    parseJson3(trackFingerprint, responseBody) {
      let payload;
      try {
        payload = JSON.parse(responseBody);
      } catch {
        return null;
      }
      if (!isRecord3(payload) || !Array.isArray(payload.events)) {
        return null;
      }
      const segments = [];
      for (const event of payload.events) {
        if (!isRecord3(event)) {
          continue;
        }
        const segs = Array.isArray(event.segs) ? event.segs : [];
        const startMs = toMilliseconds(event.tStartMs);
        const durationMs = toMilliseconds(event.dDurationMs);
        if (startMs === null || durationMs === null) {
          continue;
        }
        const fragments = parseJson3Fragments(segs);
        const sourceText = normalizeTranscriptText(fragments.map((fragment) => fragment.text).join(""));
        if (!sourceText) {
          continue;
        }
        segments.push({
          id: createStableSegmentId(trackFingerprint, startMs, durationMs, sourceText),
          startMs,
          durationMs,
          sourceText,
          ...fragments.length > 0 ? { fragments } : {}
        });
      }
      const normalizedSegments = normalizeSegments(segments);
      return normalizedSegments.length > 0 ? normalizedSegments : null;
    }
  };
  function createCaptionTrackFingerprint(track) {
    return `${track.vssId}\0${track.languageCode}\0${track.kind ?? ""}`;
  }

  // src/shared/youtube/player-response-parser.ts
  function isRecord4(value) {
    return typeof value === "object" && value !== null;
  }
  function readString(record, key) {
    const value = record[key];
    return typeof value === "string" && value.length > 0 ? value : null;
  }
  function readCaptionTrack(value) {
    if (!isRecord4(value)) {
      return null;
    }
    const baseUrl = readString(value, "baseUrl");
    const vssId = readString(value, "vssId");
    const languageCode = readString(value, "languageCode");
    const nameValue = value.name;
    const name = isRecord4(nameValue) ? readString(nameValue, "simpleText") : null;
    if (!baseUrl || !vssId || !languageCode || !name) {
      return null;
    }
    return {
      baseUrl,
      vssId,
      languageCode,
      name,
      ...typeof value.kind === "string" ? { kind: value.kind } : {},
      ...typeof value.isTranslatable === "boolean" ? { isTranslatable: value.isTranslatable } : {}
    };
  }
  function readTranslationLanguages(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.flatMap((item) => {
      if (!isRecord4(item)) {
        return [];
      }
      const languageCode = readString(item, "languageCode");
      const languageName = item.languageName;
      const name = isRecord4(languageName) ? readString(languageName, "simpleText") : null;
      return languageCode && name ? [{ languageCode, name }] : [];
    });
  }
  function parseLengthSeconds(value) {
    if (typeof value !== "string" || !/^\d+$/.test(value)) {
      return null;
    }
    const seconds = Number(value);
    return Number.isSafeInteger(seconds) && seconds >= 0 ? seconds : null;
  }
  function parseYouTubePlayerResponse(value) {
    if (!isRecord4(value) || !isRecord4(value.videoDetails)) {
      return null;
    }
    const videoId = readString(value.videoDetails, "videoId");
    const title = readString(value.videoDetails, "title");
    const author = readString(value.videoDetails, "author");
    const shortDescription = readString(value.videoDetails, "shortDescription");
    const lengthSeconds = parseLengthSeconds(value.videoDetails.lengthSeconds);
    const captions = isRecord4(value.captions) ? value.captions : null;
    const trackList = captions && isRecord4(captions.playerCaptionsTracklistRenderer) ? captions.playerCaptionsTracklistRenderer : {};
    if (!videoId || !title || !author || shortDescription === null || lengthSeconds === null) {
      return null;
    }
    const captionTracks = Array.isArray(trackList.captionTracks) ? trackList.captionTracks.flatMap((track) => {
      const parsedTrack = readCaptionTrack(track);
      return parsedTrack ? [parsedTrack] : [];
    }) : [];
    return {
      videoId,
      title,
      author,
      lengthSeconds,
      shortDescription,
      captionTracks,
      translationLanguages: readTranslationLanguages(trackList.translationLanguages)
    };
  }
  function extractBalancedJson(source, startIndex) {
    const jsonStart = source.indexOf("{", startIndex);
    if (jsonStart < 0) {
      return null;
    }
    let depth = 0;
    let inString = false;
    let isEscaped = false;
    for (let index = jsonStart; index < source.length; index += 1) {
      const character = source[index];
      if (inString) {
        if (isEscaped) {
          isEscaped = false;
        } else if (character === "\\") {
          isEscaped = true;
        } else if (character === '"') {
          inString = false;
        }
        continue;
      }
      if (character === '"') {
        inString = true;
      } else if (character === "{") {
        depth += 1;
      } else if (character === "}") {
        depth -= 1;
        if (depth === 0) {
          return source.slice(jsonStart, index + 1);
        }
      }
    }
    return null;
  }
  var PLAYER_RESPONSE_ASSIGNMENT = /(?:\bvar\s+)?ytInitialPlayerResponse\s*=/g;
  function parseInitialPlayerResponse(scriptTexts) {
    for (const scriptText of scriptTexts) {
      PLAYER_RESPONSE_ASSIGNMENT.lastIndex = 0;
      const assignment = PLAYER_RESPONSE_ASSIGNMENT.exec(scriptText);
      if (!assignment) {
        continue;
      }
      const json = extractBalancedJson(scriptText, assignment.index + assignment[0].length);
      if (!json) {
        continue;
      }
      try {
        return parseYouTubePlayerResponse(JSON.parse(json));
      } catch {
        continue;
      }
    }
    return null;
  }

  // src/shared/youtube/main-world-messages.ts
  var CONTENT_BRIDGE_SOURCE = "xtranslator-content";
  var MAIN_WORLD_BRIDGE_SOURCE = "xtranslator-main-world";
  function isRecord5(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isTranscriptReadyMessage(value) {
    if (!isRecord5(value) || value.source !== MAIN_WORLD_BRIDGE_SOURCE || value.type !== "transcript-ready") {
      return false;
    }
    return typeof value.requestId === "string" && typeof value.body === "string";
  }
  function isTranscriptErrorMessage(value) {
    if (!isRecord5(value) || value.source !== MAIN_WORLD_BRIDGE_SOURCE || value.type !== "transcript-error") {
      return false;
    }
    return typeof value.requestId === "string" && value.reason === "no-caption-fetch";
  }
  function isPlayerResponseReadyMessage(value) {
    return isRecord5(value) && value.source === MAIN_WORLD_BRIDGE_SOURCE && value.type === "player-response-ready" && typeof value.requestId === "string" && "response" in value;
  }
  function bridgeTrackFromCaptionTrack(track) {
    return {
      baseUrl: track.baseUrl,
      vssId: track.vssId,
      languageCode: track.languageCode,
      ...track.kind !== void 0 ? { kind: track.kind } : {},
      ...track.isTranslatable !== void 0 ? { isTranslatable: track.isTranslatable } : {}
    };
  }

  // src/content/transcript-client.ts
  var REQUEST_TIMEOUT_MS = 15e3;
  var pending = /* @__PURE__ */ new Map();
  var pendingPlayerResponses = /* @__PURE__ */ new Map();
  var nextRequestId = 0;
  function requestTranscriptBody(videoId, track) {
    return new Promise((resolve, reject) => {
      const requestId = `xt-${nextRequestId += 1}`;
      const timer = window.setTimeout(() => {
        pending.delete(requestId);
        reject("timeout");
      }, REQUEST_TIMEOUT_MS);
      pending.set(requestId, { resolve, reject, timer });
      window.postMessage(
        {
          source: CONTENT_BRIDGE_SOURCE,
          type: "request-transcript",
          requestId,
          videoId,
          track: bridgeTrackFromCaptionTrack(track)
        },
        window.location.origin
      );
    });
  }
  function requestPlayerResponse(videoId) {
    return new Promise((resolve) => {
      const requestId = `xt-player-${nextRequestId += 1}`;
      const timer = window.setTimeout(() => {
        pendingPlayerResponses.delete(requestId);
        resolve(null);
      }, REQUEST_TIMEOUT_MS);
      pendingPlayerResponses.set(requestId, { resolve, timer });
      window.postMessage(
        { source: CONTENT_BRIDGE_SOURCE, type: "request-player-response", requestId, videoId },
        window.location.origin
      );
    });
  }
  window.addEventListener("message", (event) => {
    const message = event.data;
    if (isPlayerResponseReadyMessage(message)) {
      const entry = pendingPlayerResponses.get(message.requestId);
      if (entry) {
        pendingPlayerResponses.delete(message.requestId);
        window.clearTimeout(entry.timer);
        entry.resolve(message.response);
      }
      return;
    }
    if (isTranscriptReadyMessage(message)) {
      const entry = pending.get(message.requestId);
      if (entry) {
        pending.delete(message.requestId);
        window.clearTimeout(entry.timer);
        entry.resolve(message.body);
      }
      return;
    }
    if (isTranscriptErrorMessage(message)) {
      const entry = pending.get(message.requestId);
      if (entry) {
        pending.delete(message.requestId);
        window.clearTimeout(entry.timer);
        entry.reject(message.reason);
      }
    }
  });

  // src/shared/youtube/youtube-page-contract.ts
  var YOUTUBE_PAGE_SELECTOR = {
    // Shorts uses a separate player host from the regular watch page, but keeps
    // the same YouTube player controls and caption APIs inside it.
    player: "#movie_player, #shorts-player",
    playerRightControls: ".ytp-right-controls",
    playerTopControls: ".ytp-chrome-top-buttons",
    progressBarContainer: ".ytp-progress-bar-container",
    title: "ytd-watch-metadata h1, ytd-reel-player-header-renderer #title",
    description: "#description-inline-expander, ytd-reel-player-header-renderer #description",
    descriptionText: "#description-inline-expander #expanded > yt-attributed-string",
    descriptionCollapse: "#description-inline-expander #collapse",
    subtitleButton: ".ytp-subtitles-button",
    captionWindow: ".ytp-caption-window-container",
    playerResponseScripts: "script",
    extensionMount: "[data-xtranslator-mount]",
    // A Short opens comments in an engagement panel. Depending on the current
    // YouTube rollout, the panel either contains `#comments` or is itself the
    // stable root while comments are hydrated lazily.
    shortsCommentsRoot: "ytd-reel-engagement-panel-section-renderer ytd-comments, ytd-reel-engagement-panel-section-renderer[target-id='engagement-panel-comments-section'], ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-comments-section']",
    commentsRoot: "#comments, ytd-reel-engagement-panel-section-renderer ytd-comments, ytd-reel-engagement-panel-section-renderer[target-id='engagement-panel-comments-section'], ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-comments-section']",
    // The comment element tag changed to `ytd-comment-view-model`; keep the older
    // `ytd-comment-renderer` as a fallback so the adapter tolerates both layouts.
    comment: "ytd-comment-view-model, ytd-comment-renderer",
    commentThread: "ytd-comment-thread-renderer, ytd-comment-thread-view-model",
    commentContent: "#content-text",
    commentContentContainer: "#content",
    commentExpander: "#expander",
    commentAuthor: "#author-text, ytd-comment-view-model #author-text",
    commentHeader: "ytd-comments-header-renderer",
    commentRepliesContainer: "ytd-comment-replies-renderer, ytd-comment-replies-view-model",
    commentPermalink: "a[href*='lc=']",
    commentReplyCount: "#reply-count-end, #comment-count",
    // Reply expand controls are owned by YouTube. The extension never expands
    // replies as a side effect of translation.
    commentReplyExpand: "[id='more-replies'], [id='more-replies-sub-thread']"
  };
  var XTRANSLATOR_DOM = {
    mountAttribute: "data-xtranslator-mount",
    mountPlayer: "player",
    mountTitle: "title",
    mountDescription: "description",
    mountCaption: "caption",
    nativeCaptionSuppressedClass: "xtranslator-native-captions-suppressed",
    mountCommentTranslation: "comment-translation",
    mountCommentControl: "comment-control",
    mountSelection: "selection",
    styleId: "xtranslator-stage-two-style"
  };
  function readYouTubeRouteVideoId(href) {
    try {
      const url = new URL(href);
      if (url.pathname === "/watch") {
        return url.searchParams.get("v") || null;
      }
      const shortsMatch = /^\/shorts\/([^/?#]+)/u.exec(url.pathname);
      return shortsMatch?.[1] ?? null;
    } catch {
      return null;
    }
  }
  function isYouTubeWatchRoute(href) {
    try {
      return new URL(href).pathname === "/watch";
    } catch {
      return false;
    }
  }
  function findYouTubeExpandedDescriptionText(documentNode) {
    const collapseButton = documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.descriptionCollapse);
    if (!collapseButton || collapseButton.getClientRects().length === 0) {
      return null;
    }
    return documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.descriptionText);
  }
  function readYouTubeVideoSnapshot(documentNode) {
    const scriptTexts = Array.from(documentNode.querySelectorAll(YOUTUBE_PAGE_SELECTOR.playerResponseScripts)).map((script) => script.textContent ?? "").filter((text) => text.includes("ytInitialPlayerResponse"));
    return parseInitialPlayerResponse(scriptTexts);
  }
  function findYouTubePageAnchors(documentNode) {
    const player = documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.player);
    const playerRightControls = player?.querySelector(YOUTUBE_PAGE_SELECTOR.playerRightControls) ?? null;
    const playerTopControls = player?.querySelector(YOUTUBE_PAGE_SELECTOR.playerTopControls) ?? null;
    const title = documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.title);
    const description = documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.description);
    return player ? { player, playerRightControls, playerTopControls, title, description } : null;
  }
  function isYouTubeNativeCaptionsEnabled(documentNode, player) {
    const button = (player ?? documentNode).querySelector(YOUTUBE_PAGE_SELECTOR.subtitleButton);
    if (!button) {
      return false;
    }
    const unavailable = button.getAttribute("aria-disabled") === "true" || button.getAttribute("disabled") !== null || button.classList.contains("ytp-button-disabled");
    return !unavailable && (button.getAttribute("aria-pressed") === "true" || button.classList.contains("ytp-button-pressed"));
  }
  function shouldShowYouTubeTranslationControl(snapshot, nativeCaptionsEnabled) {
    return snapshot.captionTracks.length > 0 || nativeCaptionsEnabled;
  }
  function shouldKeepYouTubeTranslationControl(snapshot, nativeCaptionsEnabled, alreadyShownForVideo) {
    return alreadyShownForVideo || shouldShowYouTubeTranslationControl(snapshot, nativeCaptionsEnabled);
  }
  function findExtensionMount(documentNode, mount) {
    return documentNode.querySelector(`${YOUTUBE_PAGE_SELECTOR.extensionMount}[${XTRANSLATOR_DOM.mountAttribute}="${mount}"]`);
  }
  function hasExtensionMount(documentNode, mount) {
    return findExtensionMount(documentNode, mount) !== null;
  }
  function removeVideoExtensionMounts(documentNode) {
    const mounts = [
      XTRANSLATOR_DOM.mountPlayer,
      XTRANSLATOR_DOM.mountTitle,
      XTRANSLATOR_DOM.mountDescription,
      XTRANSLATOR_DOM.mountCaption
    ];
    documentNode.querySelectorAll(mounts.map((mount) => `[${XTRANSLATOR_DOM.mountAttribute}="${mount}"]`).join(",")).forEach((mount) => mount.remove());
  }

  // src/shared/i18n/index.ts
  var en = {
    "popup.openSettings": "Open settings",
    "popup.translationLanguage": "Translation language",
    "popup.followBrowserLanguage": "Follow browser language",
    "popup.translationEngine": "Translation engine",
    "popup.loading": "Loading\u2026",
    "popup.watchStatus": "Viewing status",
    "popup.readyToTranslate": "Ready to translate",
    "popup.openYoutubeVideo": "Open a YouTube video and click the xTranslator button in the player.",
    "popup.connected": "Connected to {name}{model}",
    "popup.notConnected": "No translation service is connected. Open settings to connect one.",
    "popup.updateAvailable": "Update available",
    "popup.updateDetail": "Version {version} is ready to download.",
    "popup.downloadUpdate": "Download update",
    "popup.browserLanguage": "Follow browser language \xB7 {language}",
    "popup.preparingCaptions": "Preparing captions\u2026",
    "popup.captionsReady": "Captions are ready. Translation will begin shortly.",
    "popup.translatingCaptions": "Translating {count} caption segments\u2026",
    "popup.noTranslationNeeded": "The captions are already in the target language.",
    "popup.translationComplete": "Translation complete \xB7 {translated}/{total} caption segments",
    "popup.videoUnavailable": "This video cannot be translated right now. Please try again later.",
    "popup.statusUnavailable": "Video translation status is temporarily unavailable.",
    "options.title": "xTranslator Preferences",
    "options.preferences": "Preferences",
    "options.versionUpdate": "Version update",
    "options.currentVersion": "Current version",
    "options.latestVersion": "Latest version",
    "options.updateChecking": "Checking for updates\u2026",
    "options.updateAvailable": "Version {version} is ready to download.",
    "options.updateUpToDate": "You have the latest version.",
    "options.updateUnavailable": "Updates cannot be checked right now. Please try again later.",
    "options.downloadUpdate": "Download update",
    "options.translationService": "Translation service",
    "options.serviceHelp": "Enter a service key and load a model. Your settings are saved automatically when all three fields are complete.",
    "options.setupSteps": "Translation service setup",
    "options.stepProvider": "Provider",
    "options.stepApiKey": "API Key",
    "options.stepModel": "Model",
    "options.stepComplete": "Complete",
    "options.stepCurrent": "Current step",
    "options.stepNeedsApiKey": "Enter key",
    "options.stepNeedsModel": "Load a model",
    "options.serviceKey": "Service key (API Key)",
    "options.keyHelp": "Your key is stored only on this device and is used to connect to the selected translation service.",
    "options.createApiKey": "Create a {name} API key",
    "options.loadModels": "Load models",
    "options.translationModel": "Translation model",
    "options.subtitleDisplay": "Caption display",
    "options.subtitlePreview": "Live preview",
    "options.previewPlayer": "Player",
    "options.previewTranslation": "The answer is already in the details.",
    "options.previewOriginal": "\u7B54\u6848\u5C31\u5728\u7EC6\u8282\u91CC\u3002",
    "options.captionMode": "Caption mode",
    "options.originalOnly": "Original only",
    "options.translationOnly": "Translation only",
    "options.bilingual": "Original + translation",
    "options.captionModeHelp": "Choose how captions appear in videos. Changes apply to the current video immediately.",
    "options.enableShortsTranslation": "Enable Shorts translation",
    "options.shortsTranslationHelp": "When disabled, the translation button is hidden in Shorts. Comment translation remains available.",
    "options.subtitleStyle": "Caption style",
    "options.translationColor": "Translation color",
    "options.originalColor": "Original color",
    "options.translationFontSize": "Translation size",
    "options.originalFontSize": "Original size",
    "options.captionPositionHelp": "Drag captions vertically in the player to avoid important content. Their position and style are saved automatically.",
    "options.resetCaptionStyle": "Restore default caption style and position",
    "options.pageTranslation": "Page translation",
    "options.viewTranslation": "Viewing-page translation",
    "options.autoTranslateTitle": "Automatically translate video titles",
    "options.autoTranslateTitleHelp": "Shows the original title immediately, then displays its translation below when ready.",
    "options.selectionTranslation": "Selection translation",
    "options.enableSelectionTranslation": "Enable selection translation",
    "options.selectionDisabledHelp": "When disabled, selecting text will not show the translation panel and the context menu will not start a translation.",
    "options.includeContext": "Use surrounding context when translating selected text",
    "options.includeContextHelp": "When enabled, the surrounding sentences help produce a more natural translation.",
    "options.translationHistory": "Translation history",
    "options.dataMaintenance": "Data & maintenance",
    "options.historyHelp": "Recent entries are shown first. Open the full list when needed.",
    "options.historyCount": "{count} entries",
    "options.viewAllHistory": "View all {count} entries",
    "options.showRecentHistory": "Show recent entries",
    "options.emptyHistory": "No translation history has been saved.",
    "options.reload": "Reload",
    "options.clearHistory": "Clear history",
    "options.confirmClearHistory": "Clear all saved translation history? This cannot be undone.",
    "options.unknownService": "The selected translation service is not recognized.",
    "options.enterApiKey": "Enter an API key to load models.",
    "options.findingModels": "Finding available models\u2026",
    "options.modelsFound": "Found {count} available models.",
    "options.modelsFoundEnterKey": "Found {count} models. Enter an API key before saving.",
    "options.noModels": "No models are available.",
    "options.modelsUnavailable": "The model list is temporarily unavailable. Check your network connection or service key.",
    "options.historyUnavailable": "Translation history is temporarily unavailable.",
    "options.historyStats": "{count} saved entries \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} segments \xB7 {date}",
    "options.delete": "Delete",
    "options.deleteHistoryEntry": "Delete the translation history for {title}",
    "options.deleteFailed": "This history entry could not be deleted. Please try again later.",
    "options.saving": "Saving settings\u2026",
    "options.saved": "Settings saved.",
    "options.saveFailed": "Settings could not be saved. Please try again later.",
    "options.preferencesSaveFailed": "Preferences could not be saved. Please try again later.",
    "options.apiKeyChanged": "The API key changed. Click Load models.",
    "options.loadingConfiguredModels": "Loading configured models\u2026",
    "options.clearFailed": "Translation history could not be cleared. Please try again later.",
    "options.captionStyleRestored": "Default caption style and automatic position restored.",
    "options.loadFailed": "Preferences are temporarily unavailable. Refresh and try again.",
    "content.pageUnsupported": "This YouTube page is not supported.",
    "content.captionHttp": "The caption link has expired or is temporarily unavailable. Please try again.",
    "content.captionNetwork": "Captions could not be read. Check your network connection and try again.",
    "content.captionUnsupported": "This caption format is not supported yet. Please try again later.",
    "content.partialTranslation": "Translation is incomplete. Some captions are ready; click to continue.",
    "content.startTranslation": "Start translation",
    "content.cacheLoaded": "Loaded cached translation: {count} segments",
    "content.translateAgain": "Translate again",
    "content.translating": "Translating",
    "content.readingCache": "Reading cached translation\u2026",
    "content.noCaptionsOrCache": "This video has no available captions or local translation cache.",
    "content.retryCaptions": "Retry captions",
    "content.readingCaptions": "Reading captions\u2026",
    "content.translatingSegments": "Translating {count} segments\u2026",
    "content.translatingProgress": "Translating {translated}/{total}\u2026",
    "content.noTranslationNeeded": "The captions are already in the target language.",
    "content.noTranslation": "No translation needed",
    "content.translationComplete": "Translation complete: {count} segments",
    "content.translationCompleteProgress": "Translation complete {translated}/{total}",
    "content.continueTranslation": "Continue translation",
    "content.partialTranslationProgress": "{translated}/{total} translated \xB7 {missing} remaining. Click to continue.",
    "content.retry": "Retry",
    "content.serviceUnavailable": "The translation service could not be reached. Check extension settings and try again.",
    "content.captionPosition": "Drag up or down to adjust caption position",
    "content.translatingTitle": "Translating title\u2026",
    "content.titleTranslationFailed": "Title translation failed.",
    "content.retryTitleTranslation": "Retry",
    "content.translateDescription": "Translate description",
    "content.descriptionActionAria": "xTranslator: {action}",
    "content.translatingDescription": "Translating description\u2026",
    "content.descriptionTranslation": "Translation",
    "content.descriptionTranslationFailed": "Description translation failed. Click to retry.",
    "content.hideDescriptionTranslation": "Hide translation",
    "content.showDescriptionTranslation": "Show translation",
    "comment.translateVisible": "Translate {count} visible comments",
    "comment.translateVisiblePrefix": "Translate",
    "comment.translateVisibleAria": "Translate {count} currently visible comments",
    "comment.translateThread": "Translate this thread ({count})",
    "comment.translateThreadAria": "Translate this thread ({count})",
    "comment.translatedVisible": "Translated {count} comments",
    "comment.translatedThread": "Translated thread ({count})",
    "comment.noExpandedReplies": "No expanded replies found",
    "comment.noTranslatableComments": "No translatable comments found",
    "comment.translating": "Translating\u2026",
    "comment.translatingProgress": "Translating {completed}/{total}\u2026",
    "comment.retryIncomplete": "Retry incomplete translations",
    "comment.retryIncompleteCount": "Retry incomplete ({count})",
    "comment.translationFailedRetry": "Translation failed. Click to retry",
    "comment.retryComment": "Retry translation for comment: {id}",
    "comment.retried": "Retried",
    "selection.toolbar": "Selection translation",
    "selection.translate": "Translate",
    "selection.translateAria": "Translate selected text",
    "selection.copyAria": "Copy selected text",
    "selection.closeAria": "Close selection panel",
    "selection.translating": "Translating\u2026",
    "selection.failed": "Translation failed. Please try again.",
    "selection.copyTranslationAria": "Copy translation",
    "selection.cancelAria": "Cancel translation",
    "selection.closeTranslationAria": "Close translation panel",
    "background.notConnected": "No translation service is connected. Complete preferences first.",
    "background.unknownService": "The translation service is not recognized: {id}",
    "background.noModel": "No translation model is selected. Open settings, load models, and select one.",
    "background.contextMenu": "Translate selected text",
    "background.videoFailed": "Video translation failed. Please try again.",
    "background.translationFailed": "Translation failed. Please try again.",
    "translation.missingCaptions": "{count} caption segments did not receive a valid translation. Completed segments were saved; please try again.",
    "provider.auth": "The service key is invalid or lacks permission. Check it in Preferences.",
    "provider.rateLimit": "The translation service is busy. Please try again later.",
    "provider.timeout": "The translation request timed out. Please try again.",
    "provider.network": "The translation service could not be reached. Check your network connection and try again.",
    "provider.model": "The selected model is unavailable. Choose another model in Preferences.",
    "provider.badResponse": "The translation service is temporarily unavailable. Please try again later."
  };
  var zhCN = {
    "popup.openSettings": "\u6253\u5F00\u8BBE\u7F6E",
    "popup.translationLanguage": "\u7FFB\u8BD1\u8BED\u8A00",
    "popup.followBrowserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00",
    "popup.translationEngine": "\u7FFB\u8BD1\u5F15\u64CE",
    "popup.loading": "\u52A0\u8F7D\u4E2D\u2026",
    "popup.watchStatus": "\u89C2\u770B\u72B6\u6001",
    "popup.readyToTranslate": "\u51C6\u5907\u597D\u5F00\u59CB\u7FFB\u8BD1",
    "popup.openYoutubeVideo": "\u6253\u5F00 YouTube \u89C6\u9891\uFF0C\u70B9\u51FB\u64AD\u653E\u5668\u4E2D\u7684 xTranslator \u6309\u94AE\u3002",
    "popup.connected": "\u5DF2\u8FDE\u63A5 {name}{model}",
    "popup.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E\u5B8C\u6210\u8FDE\u63A5\u3002",
    "popup.updateAvailable": "\u53D1\u73B0\u65B0\u7248\u672C",
    "popup.updateDetail": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "popup.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "popup.browserLanguage": "\u81EA\u52A8\u8DDF\u968F\u6D4F\u89C8\u5668\u8BED\u8A00 \xB7 {language}",
    "popup.preparingCaptions": "\u6B63\u5728\u51C6\u5907\u5B57\u5E55\u2026",
    "popup.captionsReady": "\u5B57\u5E55\u5DF2\u51C6\u5907\u597D\uFF0C\u9A6C\u4E0A\u5F00\u59CB\u7FFB\u8BD1\u3002",
    "popup.translatingCaptions": "\u6B63\u5728\u7FFB\u8BD1 {count} \u5904\u5B57\u5E55\u2026",
    "popup.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "popup.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210 \xB7 {translated}/{total} \u5904\u5B57\u5E55",
    "popup.videoUnavailable": "\u8FD9\u6BB5\u89C6\u9891\u6682\u65F6\u65E0\u6CD5\u7FFB\u8BD1\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "popup.statusUnavailable": "\u89C6\u9891\u7FFB\u8BD1\u72B6\u6001\u6682\u65F6\u4E0D\u53EF\u7528\u3002",
    "options.title": "xTranslator \u504F\u597D\u8BBE\u7F6E",
    "options.preferences": "\u504F\u597D\u8BBE\u7F6E",
    "options.versionUpdate": "\u7248\u672C\u66F4\u65B0",
    "options.currentVersion": "\u5F53\u524D\u7248\u672C",
    "options.latestVersion": "\u6700\u65B0\u7248\u672C",
    "options.updateChecking": "\u6B63\u5728\u68C0\u67E5\u66F4\u65B0\u2026",
    "options.updateAvailable": "\u7248\u672C {version} \u5DF2\u53EF\u4E0B\u8F7D\u3002",
    "options.updateUpToDate": "\u5F53\u524D\u5DF2\u662F\u6700\u65B0\u7248\u672C\u3002",
    "options.updateUnavailable": "\u6682\u65F6\u65E0\u6CD5\u68C0\u67E5\u66F4\u65B0\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.downloadUpdate": "\u4E0B\u8F7D\u66F4\u65B0",
    "options.translationService": "\u7FFB\u8BD1\u670D\u52A1",
    "options.serviceHelp": "\u586B\u5199\u670D\u52A1\u5BC6\u94A5\u5E76\u52A0\u8F7D\u6A21\u578B\uFF0C\u4E09\u9879\u914D\u7F6E\u5B8C\u6574\u540E\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.setupSteps": "\u7FFB\u8BD1\u670D\u52A1\u914D\u7F6E\u6B65\u9AA4",
    "options.stepProvider": "\u670D\u52A1\u5546",
    "options.stepApiKey": "API Key",
    "options.stepModel": "\u6A21\u578B",
    "options.stepComplete": "\u5DF2\u5B8C\u6210",
    "options.stepCurrent": "\u5F53\u524D\u6B65\u9AA4",
    "options.stepNeedsApiKey": "\u8BF7\u586B\u5199\u5BC6\u94A5",
    "options.stepNeedsModel": "\u8BF7\u52A0\u8F7D\u6A21\u578B",
    "options.serviceKey": "\u670D\u52A1\u5BC6\u94A5\uFF08API Key\uFF09",
    "options.keyHelp": "\u5BC6\u94A5\u53EA\u4FDD\u5B58\u5728\u672C\u673A\uFF0C\u7528\u4E8E\u8FDE\u63A5\u4F60\u9009\u62E9\u7684\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.createApiKey": "\u524D\u5F80 {name} \u521B\u5EFA API Key",
    "options.loadModels": "\u52A0\u8F7D\u6A21\u578B",
    "options.translationModel": "\u7FFB\u8BD1\u6A21\u578B",
    "options.subtitleDisplay": "\u5B57\u5E55\u663E\u793A",
    "options.subtitlePreview": "\u5373\u65F6\u9884\u89C8",
    "options.previewPlayer": "\u64AD\u653E\u5668",
    "options.previewTranslation": "\u7B54\u6848\u5DF2\u7ECF\u5728\u7EC6\u8282\u91CC\u3002",
    "options.previewOriginal": "The answer is already in the details.",
    "options.captionMode": "\u5B57\u5E55\u6A21\u5F0F",
    "options.originalOnly": "\u4EC5\u663E\u793A\u539F\u6587",
    "options.translationOnly": "\u4EC5\u663E\u793A\u8BD1\u6587",
    "options.bilingual": "\u539F\u6587 + \u8BD1\u6587",
    "options.captionModeHelp": "\u9009\u62E9\u89C6\u9891\u4E2D\u7684\u5B57\u5E55\u5448\u73B0\u65B9\u5F0F\uFF0C\u4FDD\u5B58\u540E\u4F1A\u7ACB\u5373\u5E94\u7528\u5230\u6B63\u5728\u64AD\u653E\u7684\u89C6\u9891\u3002",
    "options.enableShortsTranslation": "\u542F\u7528 Shorts \u7FFB\u8BD1",
    "options.shortsTranslationHelp": "\u5173\u95ED\u540E\uFF0CShorts \u64AD\u653E\u5668\u4E2D\u4E0D\u663E\u793A\u7FFB\u8BD1\u6309\u94AE\uFF1B\u8BC4\u8BBA\u7FFB\u8BD1\u4E0D\u53D7\u5F71\u54CD\u3002",
    "options.subtitleStyle": "\u5B57\u5E55\u6837\u5F0F",
    "options.translationColor": "\u8BD1\u6587\u989C\u8272",
    "options.originalColor": "\u539F\u6587\u989C\u8272",
    "options.translationFontSize": "\u8BD1\u6587\u5B57\u53F7",
    "options.originalFontSize": "\u539F\u6587\u5B57\u53F7",
    "options.captionPositionHelp": "\u5B57\u5E55\u5728\u64AD\u653E\u5668\u5185\u53EF\u4E0A\u4E0B\u62D6\u52A8\u4EE5\u907F\u5F00\u753B\u9762\u5185\u5BB9\uFF1B\u4F4D\u7F6E\u548C\u6837\u5F0F\u4F1A\u81EA\u52A8\u4FDD\u5B58\u3002",
    "options.resetCaptionStyle": "\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u4F4D\u7F6E",
    "options.pageTranslation": "\u9875\u9762\u7FFB\u8BD1",
    "options.viewTranslation": "\u89C2\u770B\u9875\u7FFB\u8BD1\u529F\u80FD",
    "options.autoTranslateTitle": "\u81EA\u52A8\u7FFB\u8BD1\u89C6\u9891\u6807\u9898",
    "options.autoTranslateTitleHelp": "\u539F\u6807\u9898\u4F1A\u7ACB\u5373\u663E\u793A\uFF0C\u8BD1\u6587\u51C6\u5907\u597D\u540E\u4F1A\u663E\u793A\u5728\u4E0B\u65B9\u3002",
    "options.selectionTranslation": "\u5212\u8BCD\u7FFB\u8BD1",
    "options.enableSelectionTranslation": "\u542F\u7528\u5212\u8BCD\u7FFB\u8BD1",
    "options.selectionDisabledHelp": "\u5173\u95ED\u540E\uFF0C\u9009\u4E2D\u6587\u5B57\u4E0D\u4F1A\u663E\u793A\u7FFB\u8BD1\u6D6E\u5C42\uFF0C\u53F3\u952E\u83DC\u5355\u4E5F\u4E0D\u4F1A\u89E6\u53D1\u5212\u8BCD\u7FFB\u8BD1\u3002",
    "options.includeContext": "\u7FFB\u8BD1\u9009\u4E2D\u6587\u672C\u65F6\u53C2\u8003\u524D\u540E\u6587",
    "options.includeContextHelp": "\u5F00\u542F\u540E\u4F1A\u7ED3\u5408\u524D\u540E\u53E5\uFF0C\u8BA9\u7FFB\u8BD1\u66F4\u8D34\u5408\u8BED\u5883\u3002",
    "options.translationHistory": "\u7FFB\u8BD1\u8BB0\u5F55",
    "options.dataMaintenance": "\u6570\u636E\u4E0E\u7EF4\u62A4",
    "options.historyHelp": "\u6700\u8FD1\u8BB0\u5F55\u4F18\u5148\u663E\u793A\uFF0C\u9700\u8981\u65F6\u518D\u5C55\u5F00\u5B8C\u6574\u5217\u8868\u3002",
    "options.historyCount": "{count} \u6761\u8BB0\u5F55",
    "options.viewAllHistory": "\u67E5\u770B\u5168\u90E8 {count} \u6761\u8BB0\u5F55",
    "options.showRecentHistory": "\u53EA\u770B\u6700\u8FD1\u8BB0\u5F55",
    "options.emptyHistory": "\u8FD8\u6CA1\u6709\u4FDD\u5B58\u7684\u7FFB\u8BD1\u8BB0\u5F55\u3002",
    "options.reload": "\u91CD\u65B0\u52A0\u8F7D",
    "options.clearHistory": "\u6E05\u7A7A\u8BB0\u5F55",
    "options.confirmClearHistory": "\u786E\u5B9A\u8981\u6E05\u7A7A\u5168\u90E8\u7FFB\u8BD1\u8BB0\u5F55\u5417\uFF1F\u6B64\u64CD\u4F5C\u65E0\u6CD5\u64A4\u9500\u3002",
    "options.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u8BE5\u7FFB\u8BD1\u670D\u52A1\u3002",
    "options.enterApiKey": "\u8BF7\u586B\u5199 API Key \u540E\u52A0\u8F7D\u6A21\u578B\u3002",
    "options.findingModels": "\u6B63\u5728\u67E5\u627E\u53EF\u7528\u6A21\u578B\u2026",
    "options.modelsFound": "\u627E\u5230 {count} \u4E2A\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsFoundEnterKey": "\u627E\u5230 {count} \u4E2A\u6A21\u578B\uFF0C\u8BF7\u586B\u5199 API Key \u540E\u4FDD\u5B58\u3002",
    "options.noModels": "\u6CA1\u6709\u53EF\u7528\u6A21\u578B\u3002",
    "options.modelsUnavailable": "\u6A21\u578B\u5217\u8868\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u6216\u670D\u52A1\u5BC6\u94A5\u3002",
    "options.historyUnavailable": "\u7FFB\u8BD1\u8BB0\u5F55\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\u3002",
    "options.historyStats": "\u5DF2\u4FDD\u5B58 {count} \u6761\u8BB0\u5F55 \xB7 {size}",
    "options.historyEntry": "{source} \u2192 {target} \xB7 {count} \u6BB5 \xB7 {date}",
    "options.delete": "\u5220\u9664",
    "options.deleteHistoryEntry": "\u5220\u9664 {title} \u7684\u7FFB\u8BD1\u8BB0\u5F55",
    "options.deleteFailed": "\u5220\u9664\u8FD9\u6761\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.saving": "\u6B63\u5728\u4FDD\u5B58\u914D\u7F6E\u2026",
    "options.saved": "\u914D\u7F6E\u5DF2\u4FDD\u5B58\u3002",
    "options.saveFailed": "\u914D\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.preferencesSaveFailed": "\u504F\u597D\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "options.apiKeyChanged": "API Key \u5DF2\u53D8\u5316\uFF0C\u8BF7\u70B9\u51FB\u201C\u52A0\u8F7D\u6A21\u578B\u201D\u3002",
    "options.loadingConfiguredModels": "\u6B63\u5728\u52A0\u8F7D\u5DF2\u914D\u7F6E\u6A21\u578B\u2026",
    "options.clearFailed": "\u6E05\u7A7A\u7FFB\u8BD1\u8BB0\u5F55\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "options.captionStyleRestored": "\u5DF2\u6062\u590D\u5B57\u5E55\u9ED8\u8BA4\u6837\u5F0F\u4E0E\u81EA\u52A8\u4F4D\u7F6E\u3002",
    "options.loadFailed": "\u504F\u597D\u8BBE\u7F6E\u6682\u65F6\u65E0\u6CD5\u52A0\u8F7D\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5\u3002",
    "content.pageUnsupported": "\u5F53\u524D YouTube \u9875\u9762\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\u3002",
    "content.captionHttp": "\u5B57\u5E55\u94FE\u63A5\u5DF2\u5931\u6548\u6216\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "content.captionNetwork": "\u65E0\u6CD5\u8BFB\u53D6\u5B57\u5E55\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
    "content.captionUnsupported": "\u5F53\u524D\u5B57\u5E55\u683C\u5F0F\u6682\u4E0D\u652F\u6301\u8BFB\u53D6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
    "content.partialTranslation": "\u7FFB\u8BD1\u672A\u5B8C\u6210\uFF0C\u90E8\u5206\u5B57\u5E55\u5DF2\u5B8C\u6210\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.startTranslation": "\u5F00\u59CB\u7FFB\u8BD1",
    "content.cacheLoaded": "\u5DF2\u52A0\u8F7D\u7F13\u5B58\uFF1A{count} \u6BB5",
    "content.translateAgain": "\u518D\u6B21\u7FFB\u8BD1",
    "content.translating": "\u7FFB\u8BD1\u4E2D",
    "content.readingCache": "\u6B63\u5728\u8BFB\u53D6\u7F13\u5B58\u2026",
    "content.noCaptionsOrCache": "\u5F53\u524D\u89C6\u9891\u6CA1\u6709\u53EF\u7528\u5B57\u5E55\uFF0C\u4E14\u6CA1\u6709\u672C\u5730\u7FFB\u8BD1\u7F13\u5B58\u3002",
    "content.retryCaptions": "\u91CD\u8BD5\u5B57\u5E55",
    "content.readingCaptions": "\u6B63\u5728\u8BFB\u53D6\u5B57\u5E55\u2026",
    "content.translatingSegments": "\u6B63\u5728\u7FFB\u8BD1 {count} \u6BB5\u2026",
    "content.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {translated}/{total}\u2026",
    "content.noTranslationNeeded": "\u5F53\u524D\u5B57\u5E55\u5DF2\u662F\u76EE\u6807\u8BED\u8A00\uFF0C\u65E0\u9700\u7FFB\u8BD1\u3002",
    "content.noTranslation": "\u65E0\u9700\u7FFB\u8BD1",
    "content.translationComplete": "\u7FFB\u8BD1\u5B8C\u6210\uFF1A{count} \u6BB5",
    "content.translationCompleteProgress": "\u7FFB\u8BD1\u5B8C\u6210 {translated}/{total}",
    "content.continueTranslation": "\u7EE7\u7EED\u7FFB\u8BD1",
    "content.partialTranslationProgress": "\u5DF2\u5B8C\u6210 {translated}/{total}\uFF0C\u5269\u4F59 {missing} \u9879\uFF0C\u70B9\u51FB\u7EE7\u7EED\u3002",
    "content.retry": "\u91CD\u8BD5",
    "content.serviceUnavailable": "\u65E0\u6CD5\u8FDE\u63A5\u5230\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u8BBE\u7F6E\u540E\u91CD\u8BD5\u3002",
    "content.captionPosition": "\u4E0A\u4E0B\u62D6\u52A8\u53EF\u8C03\u6574\u5B57\u5E55\u4F4D\u7F6E",
    "content.translatingTitle": "\u6B63\u5728\u7FFB\u8BD1\u6807\u9898\u2026",
    "content.titleTranslationFailed": "\u6807\u9898\u7FFB\u8BD1\u5931\u8D25\u3002",
    "content.retryTitleTranslation": "\u91CD\u8BD5",
    "content.translateDescription": "\u7FFB\u8BD1\u7B80\u4ECB",
    "content.descriptionActionAria": "xTranslator\uFF1A{action}",
    "content.translatingDescription": "\u6B63\u5728\u7FFB\u8BD1\u7B80\u4ECB\u2026",
    "content.descriptionTranslation": "\u8BD1\u6587",
    "content.descriptionTranslationFailed": "\u7B80\u4ECB\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5\u3002",
    "content.hideDescriptionTranslation": "\u6536\u8D77\u8BD1\u6587",
    "content.showDescriptionTranslation": "\u663E\u793A\u8BD1\u6587",
    "comment.translateVisible": "\u7FFB\u8BD1\u53EF\u89C1\u7684 {count} \u6761",
    "comment.translateVisiblePrefix": "\u7FFB\u8BD1\u53EF\u89C1\u7684",
    "comment.translateVisibleAria": "\u7FFB\u8BD1\u5F53\u524D\u53EF\u89C1\u7684 {count} \u6761\u8BC4\u8BBA",
    "comment.translateThread": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translateThreadAria": "\u7FFB\u8BD1\u6B64\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.translatedVisible": "\u5DF2\u7FFB\u8BD1 {count} \u6761\u8BC4\u8BBA",
    "comment.translatedThread": "\u5DF2\u7FFB\u8BD1\u7EBF\u7A0B\uFF08{count}\uFF09",
    "comment.noExpandedReplies": "\u672A\u53D1\u73B0\u5DF2\u5C55\u5F00\u56DE\u590D",
    "comment.noTranslatableComments": "\u672A\u53D1\u73B0\u53EF\u8BD1\u8BC4\u8BBA",
    "comment.translating": "\u7FFB\u8BD1\u4E2D\u2026",
    "comment.translatingProgress": "\u6B63\u5728\u7FFB\u8BD1 {completed}/{total}\u2026",
    "comment.retryIncomplete": "\u91CD\u8BD5\u672A\u5B8C\u6210\u7FFB\u8BD1",
    "comment.retryIncompleteCount": "\u91CD\u8BD5\u672A\u5B8C\u6210\uFF08{count}\uFF09",
    "comment.translationFailedRetry": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u70B9\u51FB\u91CD\u8BD5",
    "comment.retryComment": "\u91CD\u8BD5\u7FFB\u8BD1\u8BC4\u8BBA\uFF1A{id}",
    "comment.retried": "\u5DF2\u91CD\u8BD5",
    "selection.toolbar": "\u5212\u8BCD\u7FFB\u8BD1",
    "selection.translate": "\u7FFB\u8BD1",
    "selection.translateAria": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "selection.copyAria": "\u590D\u5236\u6240\u9009\u6587\u672C",
    "selection.closeAria": "\u5173\u95ED\u5212\u8BCD\u6D6E\u5C42",
    "selection.translating": "\u6B63\u5728\u7FFB\u8BD1\u2026",
    "selection.failed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "selection.copyTranslationAria": "\u590D\u5236\u8BD1\u6587",
    "selection.cancelAria": "\u53D6\u6D88\u7FFB\u8BD1",
    "selection.closeTranslationAria": "\u5173\u95ED\u8BD1\u6587\u9762\u677F",
    "background.notConnected": "\u5C1A\u672A\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u5148\u5B8C\u6210\u504F\u597D\u8BBE\u7F6E\u3002",
    "background.unknownService": "\u6682\u65F6\u65E0\u6CD5\u8BC6\u522B\u7FFB\u8BD1\u670D\u52A1\uFF1A{id}",
    "background.noModel": "\u5C1A\u672A\u9009\u62E9\u7FFB\u8BD1\u6A21\u578B\uFF0C\u8BF7\u5148\u6253\u5F00\u8BBE\u7F6E\u52A0\u8F7D\u5E76\u9009\u62E9\u6A21\u578B\u3002",
    "background.contextMenu": "\u7FFB\u8BD1\u6240\u9009\u6587\u672C",
    "background.videoFailed": "\u89C6\u9891\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "background.translationFailed": "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "translation.missingCaptions": "{count} \u6BB5\u5B57\u5E55\u6CA1\u6709\u83B7\u5F97\u6709\u6548\u8BD1\u6587\uFF0C\u5DF2\u4FDD\u5B58\u5DF2\u5B8C\u6210\u90E8\u5206\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.auth": "\u670D\u52A1\u5BC6\u94A5\u65E0\u6548\u6216\u6743\u9650\u4E0D\u8DB3\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u68C0\u67E5\u3002",
    "provider.rateLimit": "\u7FFB\u8BD1\u670D\u52A1\u5F53\u524D\u8F83\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002",
    "provider.timeout": "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    "provider.network": "\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u7FFB\u8BD1\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u518D\u8BD5\u3002",
    "provider.model": "\u5F53\u524D\u6A21\u578B\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5230\u504F\u597D\u8BBE\u7F6E\u66F4\u6362\u6A21\u578B\u3002",
    "provider.badResponse": "\u7FFB\u8BD1\u670D\u52A1\u6682\u65F6\u5F02\u5E38\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002"
  };
  var messages = { en, "zh-CN": zhCN };
  function getUiLocale(language = typeof navigator === "undefined" ? "" : navigator.language) {
    try {
      const locale = new Intl.Locale(language).maximize();
      return locale.language === "zh" && locale.script === "Hans" ? "zh-CN" : "en";
    } catch {
      return language.toLowerCase() === "zh-cn" ? "zh-CN" : "en";
    }
  }
  function translate(locale, key, values = {}) {
    return messages[locale][key].replace(/\{(\w+)\}/gu, (placeholder, name) => {
      const value = values[name];
      return value === void 0 ? placeholder : String(value);
    });
  }
  function t(key, values = {}) {
    return translate(getUiLocale(), key, values);
  }

  // src/content/caption-overlay.ts
  var CAPTION_SUPPRESSED_CLASS = "xtranslator-captions-suppressed";
  var CAPTION_PROGRESS_GAP_PX = 8;
  function getCaptionOverlayGeometry(playerRect, targetRect) {
    if (targetRect.width <= 0 || targetRect.height <= 0) {
      return null;
    }
    return {
      left: targetRect.left - playerRect.left,
      top: targetRect.top - playerRect.top,
      width: targetRect.width,
      height: targetRect.height
    };
  }
  function getCaptionBottomOffset(playerRect, progressBarRect, gapPx = CAPTION_PROGRESS_GAP_PX) {
    if (playerRect.bottom <= playerRect.top || progressBarRect.height <= 0 || progressBarRect.top < playerRect.top || progressBarRect.top > playerRect.bottom) {
      return null;
    }
    return Math.max(0, playerRect.bottom - progressBarRect.top + gapPx);
  }
  function toTimedBlocks(blocks) {
    const sorted = blocks.map((block) => ({
      id: block.id,
      startMs: Number.isFinite(block.startMs) ? Math.max(0, block.startMs) : 0,
      endMs: Number.isFinite(block.endMs) ? Math.max(0, block.endMs) : 0,
      sourceText: block.sourceText.replace(/\r?\n+/gu, " ").replace(/[ \t]+/gu, " ").trim(),
      translatedText: block.translatedText.replace(/\r?\n+/gu, " ").replace(/[ \t]+/gu, " ").trim()
    })).filter((block) => block.endMs > block.startMs && (block.sourceText.length > 0 || block.translatedText.length > 0)).sort((a, b) => a.startMs - b.startMs || a.endMs - b.endMs);
    const result = [];
    for (const block of sorted) {
      const previous = result[result.length - 1];
      if (previous && previous.endMs > block.startMs) {
        previous.endMs = block.startMs;
        if (previous.endMs <= previous.startMs) {
          result.pop();
        }
      }
      if (block.endMs <= block.startMs) {
        continue;
      }
      result.push({ ...block });
    }
    return result;
  }
  var CaptionOverlayController = class {
    constructor(documentNode, player, onVerticalPositionChange = () => void 0) {
      this.documentNode = documentNode;
      this.player = player;
      this.onVerticalPositionChange = onVerticalPositionChange;
    }
    overlay = null;
    frame = null;
    video = null;
    blocks = [];
    mode = "bilingual";
    subtitleSettings = { ...DEFAULT_SUBTITLE_SETTINGS };
    nativeCaptionObserver = null;
    renderedBlockId = null;
    /** Provide translated blocks and start showing them. */
    load(blocks) {
      this.blocks = toTimedBlocks(blocks).sort((a, b) => a.startMs - b.startMs);
      this.syncOverlay();
    }
    /** Merge blocks received from a streaming translation response. */
    append(blocks) {
      const merged = new Map(this.blocks.map((block) => [block.id, block]));
      for (const block of toTimedBlocks(blocks)) {
        merged.set(block.id, block);
      }
      this.blocks = [...merged.values()].sort((a, b) => a.startMs - b.startMs || a.endMs - b.endMs);
      this.syncOverlay();
    }
    setMode(mode) {
      this.mode = mode;
      this.subtitleSettings = { ...this.subtitleSettings, displayMode: mode };
      this.renderedBlockId = null;
      this.syncOverlay();
    }
    setSettings(settings) {
      this.subtitleSettings = { ...settings };
      this.mode = settings.displayMode;
      this.applySubtitleSettings();
      this.renderedBlockId = null;
      this.renderActive();
    }
    isActive() {
      return this.overlay !== null;
    }
    syncOverlay() {
      this.activate();
    }
    activate() {
      if (this.overlay !== null) {
        this.renderActive();
        return;
      }
      this.overlay = this.documentNode.createElement("div");
      this.overlay.className = "xtranslator-caption";
      if (this.player.id === "shorts-player") {
        this.overlay.dataset.layout = "shorts";
      }
      this.overlay.setAttribute(XTRANSLATOR_DOM.mountAttribute, XTRANSLATOR_DOM.mountCaption);
      this.overlay.hidden = true;
      this.player.append(this.overlay);
      this.applySubtitleSettings();
      this.resolveVideo();
      this.documentNode.body.classList.add(CAPTION_SUPPRESSED_CLASS);
      this.suppressNativeCaptions();
      if (typeof MutationObserver !== "undefined") {
        this.nativeCaptionObserver = new MutationObserver(() => this.suppressNativeCaptions());
        this.nativeCaptionObserver.observe(this.player, { childList: true, subtree: true });
      }
      this.startLoop();
    }
    suppressNativeCaptions() {
      this.player.querySelectorAll(".ytp-caption-window-container").forEach((captionWindow) => captionWindow.classList.add(XTRANSLATOR_DOM.nativeCaptionSuppressedClass));
    }
    restoreNativeCaptions() {
      this.player.querySelectorAll(`.${XTRANSLATOR_DOM.nativeCaptionSuppressedClass}`).forEach((captionWindow) => captionWindow.classList.remove(XTRANSLATOR_DOM.nativeCaptionSuppressedClass));
    }
    resolveVideo() {
      this.video = this.player.querySelector("video") ?? this.documentNode.querySelector("video");
    }
    deactivate() {
      if (this.frame !== null) {
        this.documentNode.defaultView?.cancelAnimationFrame(this.frame);
        this.frame = null;
      }
      this.nativeCaptionObserver?.disconnect();
      this.nativeCaptionObserver = null;
      this.restoreNativeCaptions();
      this.documentNode.body.classList.remove(CAPTION_SUPPRESSED_CLASS);
      this.overlay?.remove();
      this.overlay = null;
      this.video = null;
      this.renderedBlockId = null;
    }
    startLoop() {
      if (this.frame !== null) {
        return;
      }
      this.renderActive();
      this.frame = this.documentNode.defaultView?.requestAnimationFrame(this.tick) ?? null;
    }
    tick = () => {
      this.renderActive();
      this.frame = this.documentNode.defaultView?.requestAnimationFrame(this.tick) ?? null;
    };
    renderActive() {
      if (this.overlay === null) {
        return;
      }
      if (this.video === null) {
        this.resolveVideo();
      }
      this.syncOverlayGeometry();
      this.render(this.findActive(this.currentTimeMs()));
    }
    syncOverlayGeometry() {
      if (this.overlay === null) {
        return;
      }
      const target = this.video ?? this.player;
      const rect = target.getBoundingClientRect();
      const playerRect = this.player.getBoundingClientRect();
      const geometry = getCaptionOverlayGeometry(playerRect, rect);
      if (!geometry) {
        return;
      }
      this.overlay.style.left = `${geometry.left}px`;
      this.overlay.style.top = `${geometry.top}px`;
      this.overlay.style.width = `${geometry.width}px`;
      this.overlay.style.height = `${geometry.height}px`;
      const progressBar = this.player.querySelector(YOUTUBE_PAGE_SELECTOR.progressBarContainer);
      const bottomOffset = progressBar ? getCaptionBottomOffset(rect, progressBar.getBoundingClientRect()) : null;
      this.overlay.style.setProperty("--xtranslator-caption-bottom", bottomOffset === null ? "" : `${bottomOffset}px`);
      this.positionCard();
    }
    applySubtitleSettings() {
      if (this.overlay === null) {
        return;
      }
      this.overlay.style.setProperty("--xtranslator-caption-translation-color", this.subtitleSettings.translationColor);
      this.overlay.style.setProperty("--xtranslator-caption-original-color", this.subtitleSettings.originalColor);
      this.overlay.style.setProperty("--xtranslator-caption-translation-scale", String(this.subtitleSettings.translationFontScale / 100));
      this.overlay.style.setProperty("--xtranslator-caption-original-scale", String(this.subtitleSettings.originalFontScale / 100));
      this.positionCard();
    }
    currentTimeMs() {
      const currentTime = this.video?.currentTime;
      return typeof currentTime === "number" && Number.isFinite(currentTime) ? currentTime * 1e3 : Number.NaN;
    }
    findActive(timeMs) {
      if (!Number.isFinite(timeMs) || this.blocks.length === 0) {
        return null;
      }
      let low = 0;
      let high = this.blocks.length - 1;
      let index = -1;
      while (low <= high) {
        const mid = low + high >> 1;
        if (this.blocks[mid].startMs <= timeMs) {
          index = mid;
          low = mid + 1;
        } else {
          high = mid - 1;
        }
      }
      if (index === -1) {
        return null;
      }
      const block = this.blocks[index];
      return timeMs < block.endMs ? block : null;
    }
    render(block) {
      if (this.overlay === null) {
        return;
      }
      if (!block) {
        this.overlay.hidden = true;
        this.overlay.replaceChildren();
        this.renderedBlockId = null;
        return;
      }
      const lines = [];
      if (this.mode === "original") {
        if (block.sourceText) {
          lines.push({ text: block.sourceText, className: "xtranslator-caption-original" });
        }
      } else if (this.mode === "translation") {
        if (block.translatedText) {
          lines.push({ text: block.translatedText, className: "xtranslator-caption-translation" });
        }
      } else if (block.translatedText) {
        lines.push({ text: block.translatedText, className: "xtranslator-caption-translation" });
        if (block.sourceText) {
          lines.push({ text: block.sourceText, className: "xtranslator-caption-original" });
        }
      } else if (block.sourceText) {
        lines.push({ text: block.sourceText, className: "xtranslator-caption-original" });
      }
      if (lines.length === 0) {
        this.overlay.hidden = true;
        this.overlay.replaceChildren();
        this.renderedBlockId = null;
        return;
      }
      if (this.renderedBlockId === block.id && this.overlay.firstElementChild) {
        return;
      }
      this.overlay.hidden = false;
      this.overlay.replaceChildren();
      this.appendCard(lines, block.id);
      this.renderedBlockId = block.id;
    }
    appendCard(lines, blockId) {
      const card = this.documentNode.createElement("div");
      card.className = "xtranslator-caption-card";
      card.dataset.xtranslatorBlockId = blockId;
      card.setAttribute("aria-label", t("content.captionPosition"));
      lines.forEach((line) => this.appendLine(card, line.text, line.className, blockId));
      this.overlay?.append(card);
      this.positionCard(card);
      this.bindCardDrag(card);
    }
    positionCard(card = this.overlay?.querySelector(".xtranslator-caption-card") ?? null) {
      if (this.overlay === null || card === null) {
        return;
      }
      const position = this.subtitleSettings.verticalPosition;
      if (position === null) {
        delete card.dataset.position;
        card.style.top = "";
        return;
      }
      const availableHeight = Math.max(0, this.overlay.clientHeight - card.offsetHeight);
      card.dataset.position = "manual";
      card.style.top = `${Math.round(position * availableHeight)}px`;
    }
    bindCardDrag(card) {
      card.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || this.overlay === null) {
          return;
        }
        event.preventDefault();
        const overlayRect = this.overlay.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        const availableHeight = Math.max(0, overlayRect.height - cardRect.height);
        const startTop = Math.max(0, Math.min(availableHeight, cardRect.top - overlayRect.top));
        const startY = event.clientY;
        card.setPointerCapture(event.pointerId);
        card.dataset.dragging = "true";
        const move = (moveEvent) => {
          if (moveEvent.pointerId !== event.pointerId) {
            return;
          }
          const nextTop = Math.max(0, Math.min(availableHeight, startTop + moveEvent.clientY - startY));
          this.subtitleSettings = {
            ...this.subtitleSettings,
            verticalPosition: availableHeight === 0 ? 0 : nextTop / availableHeight
          };
          this.positionCard(card);
        };
        const end = (endEvent) => {
          if (endEvent.pointerId !== event.pointerId) {
            return;
          }
          card.removeEventListener("pointermove", move);
          card.removeEventListener("pointerup", end);
          card.removeEventListener("pointercancel", end);
          delete card.dataset.dragging;
          void this.onVerticalPositionChange(this.subtitleSettings.verticalPosition);
        };
        card.addEventListener("pointermove", move);
        card.addEventListener("pointerup", end);
        card.addEventListener("pointercancel", end);
      });
    }
    appendLine(parent, text, className, blockId) {
      const element = this.documentNode.createElement("span");
      element.className = `xtranslator-caption-line ${className}`;
      element.dataset.xtranslatorBlockId = blockId;
      element.textContent = text;
      parent.append(element);
    }
  };

  // src/shared/translation/token-estimator.ts
  function isDenseScript(codePoint) {
    return codePoint >= 11904 && codePoint <= 12031 || // CJK radicals and symbols
    codePoint >= 12288 && codePoint <= 12543 || // Japanese punctuation, hiragana, katakana
    codePoint >= 13312 && codePoint <= 40959 || // CJK unified ideographs
    codePoint >= 44032 && codePoint <= 55215 || // Hangul syllables
    codePoint >= 63744 && codePoint <= 64255 || // CJK compatibility ideographs
    codePoint >= 65280 && codePoint <= 65519;
  }
  function estimateTokens(text) {
    let tokens = 0;
    for (const character of text) {
      const codePoint = character.codePointAt(0) ?? 0;
      tokens += isDenseScript(codePoint) ? 1 : 0.25;
    }
    return Math.max(1, Math.ceil(tokens));
  }

  // src/shared/translation/chunker.ts
  var PROMPT_OVERHEAD_TOKENS = 600;
  var PER_BLOCK_OVERHEAD_TOKENS = 16;
  function computeInputTokenBudget(contextWindowTokens) {
    const usable = Math.max(0, contextWindowTokens - PROMPT_OVERHEAD_TOKENS);
    return Math.max(1, Math.floor(usable / 2));
  }

  // src/shared/translation/subtitle-segmentation.ts
  var CAPTION_MARKER_WORDS = /^(?:music|song|applause|laugh(?:s|ter)?|laughter|sigh(?:s|ing)?|cry(?:ing)?|breath(?:ing)?|noise|sound effects?|inaudible|indistinct|unintelligible|speaking (?:foreign )?language|cheering|crowd|clapping|door|phone ringing|snorts?|cough(?:s|ing)?|sneez(?:e|ing)|musik|música|musica|musique|tepuk tangan|lonceng|musik bermain|音楽|拍手|笑い|咳払い|咳|鈴|鐘|音效|音乐|掌声|笑声|叹气|哭声|呼吸声|噪音|听不清|无法辨认|음악|박수|웃음|기침|숨소리)(?:\s+(?:playing|plays|sounds?|only|continues|再生中|중))?$/iu;
  var CAPTION_MARKER_SYMBOLS = /^(?:[♪♫]+|[-–—_*]+)$/u;
  var SPEAKER_PREFIX = /^\s*>>\s*/gmu;
  var SENTENCE_BOUNDARY = /[.!?。！？…]+["'”’」』）)\]}]*/gu;
  var CJK_CHARACTER = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u;
  function isCaptionMarker(value) {
    const normalized = value.replace(/\s+/gu, " ").trim();
    return normalized.length === 0 || CAPTION_MARKER_SYMBOLS.test(normalized) || CAPTION_MARKER_WORDS.test(normalized);
  }
  function cleanCaptionText(text) {
    const normalized = text.replace(/\r\n?|[\u2028\u2029]/gu, " ").replace(/\u200B|\uFEFF/gu, "").replace(SPEAKER_PREFIX, " ").replace(/♪|♫/gu, " ").replace(/\[([^\]]*)\]/gu, (_match, inner) => isCaptionMarker(inner) ? " " : ` ${inner} `).replace(/\(([^()]*)\)/gu, (_match, inner) => isCaptionMarker(inner) ? " " : ` (${inner}) `).replace(/\{([^{}]*)\}/gu, (_match, inner) => {
      const value = inner.trim();
      return value.startsWith("\\") || isCaptionMarker(value) ? " " : ` ${value} `;
    }).replace(/\s+/gu, " ").trim();
    if (isCaptionMarker(normalized)) {
      return "";
    }
    return /[\p{L}\p{N}]/u.test(normalized) ? normalized : "";
  }
  function containsSpokenContent(text) {
    return /[\p{L}\p{N}]/u.test(cleanCaptionText(text));
  }
  function hasSentenceBoundary(text, matchEnd, matchText) {
    if (matchEnd >= text.length) {
      return true;
    }
    if (matchText.includes(".") && !/[!?。！？…]/u.test(matchText)) {
      const before = text[matchEnd - 1] ?? "";
      const after = text[matchEnd] ?? "";
      if (/\d/u.test(before) && /\d/u.test(after)) {
        return false;
      }
    }
    if (/\s/u.test(text[matchEnd] ?? "")) {
      return true;
    }
    const next = text.slice(matchEnd).trimStart().slice(0, 1);
    return /[!?。！？…]/u.test(matchText) || CJK_CHARACTER.test(next);
  }
  function splitAtSentenceBoundaries(text) {
    const parts = [];
    let cursor = 0;
    SENTENCE_BOUNDARY.lastIndex = 0;
    for (const match of text.matchAll(SENTENCE_BOUNDARY)) {
      const matchStart = match.index ?? 0;
      const matchEnd = matchStart + match[0].length;
      if (!hasSentenceBoundary(text, matchEnd, match[0])) {
        continue;
      }
      const part = text.slice(cursor, matchEnd).trim();
      if (part) {
        parts.push({ text: part, startOffset: cursor, endOffset: matchEnd });
      }
      cursor = matchEnd;
    }
    const tail = text.slice(cursor).trim();
    if (tail) {
      parts.push({ text: tail, startOffset: cursor, endOffset: text.length });
    }
    return parts.length > 1 ? parts : [{ text: text.trim(), startOffset: 0, endOffset: text.length }];
  }
  function createFragmentRanges(segment, rawText) {
    if (!segment.fragments || segment.fragments.length === 0) {
      return [];
    }
    const ranges = [];
    let charOffset = 0;
    let previousOffsetMs = 0;
    const durationMs = Math.max(1, segment.durationMs);
    for (let index = 0; index < segment.fragments.length; index += 1) {
      const fragment = segment.fragments[index];
      if (!fragment.text) {
        continue;
      }
      const startOffsetMs = Math.min(durationMs, Math.max(previousOffsetMs, fragment.offsetMs ?? previousOffsetMs));
      const nextFragment = segment.fragments.slice(index + 1).find((candidate) => candidate.text && candidate.offsetMs !== void 0);
      const endOffsetMs = Math.min(
        durationMs,
        Math.max(startOffsetMs, nextFragment?.offsetMs ?? durationMs)
      );
      const endChar = charOffset + fragment.text.length;
      ranges.push({ startChar: charOffset, endChar, startOffsetMs, endOffsetMs });
      charOffset = endChar;
      previousOffsetMs = startOffsetMs;
    }
    return charOffset === rawText.length ? ranges : [];
  }
  function timeAtOffset(segment, rawText, fragmentRanges, offset) {
    const durationMs = Math.max(1, segment.durationMs);
    if (fragmentRanges.length === 0) {
      return segment.startMs + Math.round(durationMs * offset / Math.max(1, rawText.length));
    }
    const range = fragmentRanges.find((candidate) => offset <= candidate.endChar) ?? fragmentRanges[fragmentRanges.length - 1];
    const width = Math.max(1, range.endChar - range.startChar);
    const ratio = Math.min(1, Math.max(0, (offset - range.startChar) / width));
    return segment.startMs + Math.round(range.startOffsetMs + (range.endOffsetMs - range.startOffsetMs) * ratio);
  }
  function splitCaptionSegment(segment) {
    const rawText = segment.fragments?.length ? segment.fragments.map((fragment) => fragment.text).join("") : segment.sourceText;
    const parts = splitAtSentenceBoundaries(rawText);
    if (parts.length <= 1 || segment.durationMs < parts.length) {
      return [segment];
    }
    const fragmentRanges = createFragmentRanges(segment, rawText);
    const segmentEndMs = segment.startMs + segment.durationMs;
    const result = [];
    let previousEndMs = segment.startMs;
    for (const [index, part] of parts.entries()) {
      const startMs = index === 0 ? segment.startMs : Math.max(previousEndMs, timeAtOffset(segment, rawText, fragmentRanges, part.startOffset));
      const endMs = index === parts.length - 1 ? segmentEndMs : Math.max(startMs + 1, timeAtOffset(segment, rawText, fragmentRanges, part.endOffset));
      if (endMs > segmentEndMs) {
        return [segment];
      }
      result.push({
        id: `${segment.id}:s${index + 1}`,
        sourceText: part.text,
        startMs,
        durationMs: endMs - startMs
      });
      previousEndMs = endMs;
    }
    return result;
  }

  // src/shared/translation/block-builder.ts
  var DEFAULT_GAP_MS = 500;
  var MAX_BLOCK_DURATION_MS = 16e3;
  var PREFERRED_BLOCK_SOURCE_TOKENS = 36;
  var MAX_BLOCK_SOURCE_TOKENS = 48;
  var MAX_DENSE_BLOCK_SOURCE_CHARACTERS = 72;
  var MAX_LATIN_BLOCK_SOURCE_CHARACTERS = 144;
  var SHORT_CONTINUATION_MAX_DURATION_MS = 2e3;
  var SHORT_CONTINUATION_MAX_TOKENS = 16;
  var SENTENCE_TERMINATOR = /[.!?。！？…]/u;
  var CLAUSE_TERMINATOR = /[,;:，；：、]$/u;
  var SPEAKER_MARKER = /^\s*>>\s*/u;
  var NO_SPACE_CJK_CHARACTER = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u;
  var HANGUL_CHARACTER = new RegExp("\\p{Script=Hangul}", "u");
  var NO_SPACE_BEFORE = /^[,.:;!?，。！？；：、】【〕〉》”’]/u;
  var NO_SPACE_AFTER = /[（【〔〈《“‘]$/u;
  var PUNCTUATION_ONLY = /^[\s.,!?;:，。！？；：、…'"“”‘’「」『』]+$/u;
  function isStandaloneNonVerbalMarker(text) {
    const trimmed = text.trim();
    return trimmed.length === 0 || !PUNCTUATION_ONLY.test(trimmed) && cleanCaptionText(trimmed).length === 0;
  }
  function stableBlockId(segmentIds, sourceText) {
    let hash = 2166136261;
    const parts = [...segmentIds, sourceText];
    for (const part of parts) {
      for (const character of part) {
        hash ^= character.codePointAt(0) ?? 0;
        hash = Math.imul(hash, 16777619);
      }
      hash = Math.imul(hash, 16777619);
    }
    return `blk-${(hash >>> 0).toString(36)}`;
  }
  function endsAtSentenceBoundary(text) {
    const last = text.trim().slice(-1);
    return last.length > 0 && SENTENCE_TERMINATOR.test(last);
  }
  function appendCaptionText(current, next, sourceLanguage) {
    if (!current) {
      return next;
    }
    const previousCharacter = current.trim().slice(-1);
    const nextCharacter = next.trim().slice(0, 1);
    const isKorean = sourceLanguage.toLowerCase().startsWith("ko");
    const keepAdjacentCharactersTogether = NO_SPACE_CJK_CHARACTER.test(previousCharacter) && NO_SPACE_CJK_CHARACTER.test(nextCharacter) || !isKorean && HANGUL_CHARACTER.test(previousCharacter) && HANGUL_CHARACTER.test(nextCharacter);
    const needsSpace = previousCharacter.length > 0 && nextCharacter.length > 0 && !NO_SPACE_BEFORE.test(nextCharacter) && !NO_SPACE_AFTER.test(previousCharacter) && !keepAdjacentCharactersTogether;
    return `${current}${needsSpace ? " " : ""}${next}`;
  }
  function effectiveSegmentEndMs(segment, nextSegment) {
    const rawEndMs = segment.startMs + Math.max(1, segment.durationMs);
    if (nextSegment && nextSegment.startMs > segment.startMs && nextSegment.startMs < rawEndMs) {
      return nextSegment.startMs;
    }
    return rawEndMs;
  }
  function buildTranslationBlocks(segments, contextWindowTokens, gapMs = DEFAULT_GAP_MS, preferredBlockSourceTokens = PREFERRED_BLOCK_SOURCE_TOKENS, maxBlockSourceTokens = MAX_BLOCK_SOURCE_TOKENS, sourceLanguage = "") {
    const budget = computeInputTokenBudget(contextWindowTokens);
    const blocks = [];
    let currentRawText = "";
    let currentSegmentIds = [];
    let currentStartMs = 0;
    let currentEndMs = 0;
    let currentTokens = 0;
    let currentHasSpeech = false;
    const flush = (boundaryStartMs) => {
      if (currentSegmentIds.length === 0) {
        return;
      }
      const rawSourceText = currentRawText.trim();
      const sourceText = cleanCaptionText(rawSourceText);
      const boundedEndMs = boundaryStartMs !== void 0 && boundaryStartMs >= currentStartMs ? Math.min(currentEndMs, boundaryStartMs) : currentEndMs;
      blocks.push({
        id: stableBlockId(currentSegmentIds, rawSourceText),
        segmentIds: [...currentSegmentIds],
        startMs: currentStartMs,
        endMs: Math.max(currentStartMs + 1, boundedEndMs),
        sourceText,
        isSilent: !currentHasSpeech
      });
      currentRawText = "";
      currentSegmentIds = [];
      currentTokens = 0;
      currentHasSpeech = false;
    };
    const orderedSegments = segments.flatMap((segment) => splitCaptionSegment(segment)).map((segment, sourceOrder) => ({ segment, sourceOrder })).sort((left, right) => left.segment.startMs - right.segment.startMs || left.sourceOrder - right.sourceOrder).map(({ segment }) => segment);
    for (const [index, segment] of orderedSegments.entries()) {
      const segmentEndMs = effectiveSegmentEndMs(segment, orderedSegments[index + 1]);
      const cleanedSegmentText = cleanCaptionText(segment.sourceText);
      const sourceTokens = estimateTokens(cleanedSegmentText);
      const tokens = sourceTokens + PER_BLOCK_OVERHEAD_TOKENS;
      const candidateRawText = appendCaptionText(currentRawText, segment.sourceText, sourceLanguage);
      const candidateSourceText = cleanCaptionText(candidateRawText);
      const candidateSourceTokens = estimateTokens(candidateSourceText);
      const gap = currentSegmentIds.length > 0 ? segment.startMs - currentEndMs : 0;
      const exceedsBudget = currentSegmentIds.length > 0 && currentTokens + tokens > budget;
      const exceedsGap = currentSegmentIds.length > 0 && gap > gapMs;
      const candidateEndMs = Math.max(currentEndMs, segmentEndMs);
      const exceedsDuration = currentSegmentIds.length > 0 && candidateEndMs - currentStartMs > MAX_BLOCK_DURATION_MS;
      const currentEndsAtClause = CLAUSE_TERMINATOR.test(cleanCaptionText(currentRawText));
      const readableLimit = Math.max(maxBlockSourceTokens, preferredBlockSourceTokens);
      const exceedsReadable = currentSegmentIds.length > 0 && candidateSourceTokens > readableLimit && (currentEndsAtClause || candidateSourceTokens > readableLimit + 20);
      const readableCharacterLimit = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u.test(candidateSourceText) ? MAX_DENSE_BLOCK_SOURCE_CHARACTERS : MAX_LATIN_BLOCK_SOURCE_CHARACTERS;
      const exceedsReadableCharacters = currentSegmentIds.length > 0 && candidateSourceText.length > readableCharacterLimit && (currentEndsAtClause || candidateSourceText.length > readableCharacterLimit + 24);
      const markerOnly = isStandaloneNonVerbalMarker(segment.sourceText);
      const currentHasOnlyMarkers = currentSegmentIds.length > 0 && !currentHasSpeech;
      const speakerBreak = currentSegmentIds.length > 0 && SPEAKER_MARKER.test(segment.sourceText);
      const previousRawEndMs = index > 0 ? orderedSegments[index - 1].startMs + Math.max(1, orderedSegments[index - 1].durationMs) : Number.NEGATIVE_INFINITY;
      const markerOverlapsPreviousCue = markerOnly && segment.startMs < previousRawEndMs;
      const markerBreak = currentSegmentIds.length > 0 && markerOnly && !markerOverlapsPreviousCue && segment.startMs >= currentEndMs;
      const sentenceBreak = currentSegmentIds.length > 0 && currentHasSpeech && endsAtSentenceBoundary(currentRawText) && !markerOnly && !PUNCTUATION_ONLY.test(segment.sourceText.trim());
      if (exceedsBudget || exceedsGap || exceedsDuration || exceedsReadable || exceedsReadableCharacters || speakerBreak || markerBreak || currentHasOnlyMarkers || sentenceBreak) {
        flush(segment.startMs);
      }
      if (currentSegmentIds.length === 0) {
        currentStartMs = segment.startMs;
      }
      currentRawText = appendCaptionText(currentRawText, segment.sourceText, sourceLanguage);
      currentSegmentIds.push(segment.id);
      currentEndMs = Math.max(currentEndMs, segmentEndMs);
      currentTokens += tokens;
      currentHasSpeech = currentHasSpeech || containsSpokenContent(segment.sourceText);
    }
    flush();
    return mergeShortContinuationBlocks(blocks, sourceLanguage);
  }
  function mergeShortContinuationBlocks(blocks, sourceLanguage) {
    const merged = [];
    for (const block of blocks) {
      const previous = merged[merged.length - 1];
      const gapMs = previous ? block.startMs - previous.endMs : Number.POSITIVE_INFINITY;
      const blockDurationMs = block.endMs - block.startMs;
      const isShortContinuation = previous !== void 0 && !previous.isSilent && !block.isSilent && !endsAtSentenceBoundary(previous.sourceText) && gapMs <= DEFAULT_GAP_MS && blockDurationMs <= SHORT_CONTINUATION_MAX_DURATION_MS && estimateTokens(block.sourceText) <= SHORT_CONTINUATION_MAX_TOKENS && block.endMs - previous.startMs <= MAX_BLOCK_DURATION_MS;
      if (!isShortContinuation || !previous) {
        merged.push({ ...block, segmentIds: [...block.segmentIds] });
        continue;
      }
      const sourceText = appendCaptionText(previous.sourceText, block.sourceText, sourceLanguage);
      merged[merged.length - 1] = {
        ...previous,
        id: stableBlockId([...previous.segmentIds, ...block.segmentIds], sourceText),
        segmentIds: [...previous.segmentIds, ...block.segmentIds],
        endMs: Math.max(previous.endMs, block.endMs),
        sourceText,
        isSilent: false
      };
    }
    return merged;
  }

  // src/shared/youtube/comment-grouping.ts
  function dedupeComments(comments) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const comment of comments) {
      if (seen.has(comment.commentId)) {
        continue;
      }
      seen.add(comment.commentId);
      result.push(comment);
    }
    return result;
  }
  function buildThread(comments, rootCommentId) {
    const root = rootCommentId ? comments.find((comment) => comment.commentId === rootCommentId) : comments.find((comment) => !comment.isReply);
    if (!root) {
      return null;
    }
    const replies = comments.filter((comment) => comment.isReply && comment.parentCommentId === root.commentId);
    return { root, replies };
  }
  function collectCommentBranch(comments, rootCommentId) {
    const root = comments.find((comment) => comment.commentId === rootCommentId);
    if (!root) {
      return [];
    }
    const childrenByParent = /* @__PURE__ */ new Map();
    for (const comment of comments) {
      if (!comment.parentCommentId) {
        continue;
      }
      const children = childrenByParent.get(comment.parentCommentId) ?? [];
      children.push(comment);
      childrenByParent.set(comment.parentCommentId, children);
    }
    const result = [];
    const visited = /* @__PURE__ */ new Set();
    const append = (comment) => {
      if (visited.has(comment.commentId)) {
        return;
      }
      visited.add(comment.commentId);
      result.push(comment);
      for (const child of childrenByParent.get(comment.commentId) ?? []) {
        append(child);
      }
    };
    append(root);
    return result;
  }
  function commentToTextItem(comment) {
    return { id: comment.commentId, sourceText: comment.sourceText };
  }
  function commentsToTextItems(comments) {
    return comments.map((comment) => commentToTextItem(comment));
  }

  // src/content/comments/comment-dom.ts
  function normalizeText(value) {
    return value.replace(/\s+/g, " ").trim();
  }
  function parseReplyCount(value) {
    if (!value || !/^\d+$/u.test(value.trim())) {
      return void 0;
    }
    return parseInt(value.trim(), 10);
  }
  function commentIdFromHref(href) {
    try {
      const url = new URL(href, "https://www.youtube.com");
      const lc = url.searchParams.get("lc");
      return lc && lc.length > 0 ? lc : null;
    } catch {
      return null;
    }
  }
  function isOwnedByComment(node, commentElement) {
    return node.closest(YOUTUBE_PAGE_SELECTOR.comment) === commentElement;
  }
  function closestAncestor(element, selector) {
    let current = element.parentElement;
    while (current) {
      if (current.matches(selector)) {
        return current;
      }
      current = current.parentElement;
    }
    return null;
  }
  function findOwnedElement(commentElement, selector) {
    return Array.from(commentElement.querySelectorAll(selector)).find(
      (node) => isOwnedByComment(node, commentElement)
    ) ?? null;
  }
  function findCommentsRoot(documentNode) {
    const roots = Array.from(documentNode.querySelectorAll(YOUTUBE_PAGE_SELECTOR.commentsRoot));
    return roots.find((root) => root.querySelector(YOUTUBE_PAGE_SELECTOR.comment) !== null) ?? roots.find((root) => root.matches(YOUTUBE_PAGE_SELECTOR.shortsCommentsRoot)) ?? roots[0] ?? null;
  }
  function extractCommentText(element) {
    const candidates = [
      YOUTUBE_PAGE_SELECTOR.commentContent,
      "#content yt-attributed-string",
      "#content .yt-core-attributed-string",
      "#content"
    ];
    for (const selector of candidates) {
      const node = findOwnedElement(element, selector);
      if (!node) {
        continue;
      }
      const text = normalizeText(node.textContent ?? "");
      if (text) {
        return text;
      }
    }
    return "";
  }
  function extractAuthor(element) {
    const author = findOwnedElement(element, YOUTUBE_PAGE_SELECTOR.commentAuthor);
    return author ? normalizeText(author.textContent ?? "") : "";
  }
  function extractCommentId(element) {
    const ownDataId = element.getAttribute("data-comment-id") ?? element.getAttribute("data-xtranslator-comment-id");
    if (ownDataId) {
      return ownDataId;
    }
    const permalink = findOwnedElement(element, YOUTUBE_PAGE_SELECTOR.commentPermalink);
    const fromPermalink = permalink?.href ? commentIdFromHref(permalink.href) : null;
    if (fromPermalink) {
      return fromPermalink;
    }
    const dataId = findOwnedElement(element, "[data-comment-id]")?.getAttribute("data-comment-id");
    if (dataId) {
      return dataId;
    }
    return null;
  }
  function readComment(commentElement) {
    const sourceText = extractCommentText(commentElement);
    if (!sourceText) {
      return null;
    }
    const authorName = extractAuthor(commentElement);
    const commentId = extractCommentId(commentElement);
    if (!commentId) {
      return null;
    }
    const isReply = Boolean(commentElement.closest(YOUTUBE_PAGE_SELECTOR.commentRepliesContainer));
    const parsedReplyCount = parseReplyCount(
      findOwnedElement(commentElement, YOUTUBE_PAGE_SELECTOR.commentReplyCount)?.textContent
    );
    return {
      commentId,
      authorName,
      sourceText,
      ...parsedReplyCount !== void 0 ? { replyCount: parsedReplyCount } : {},
      isReply
    };
  }
  function findOutermostThread(threadElement) {
    let outermost = threadElement;
    let parent = closestAncestor(outermost, YOUTUBE_PAGE_SELECTOR.commentThread);
    while (parent) {
      outermost = parent;
      parent = closestAncestor(outermost, YOUTUBE_PAGE_SELECTOR.commentThread);
    }
    return outermost;
  }
  function findThreadComment(threadElement) {
    return Array.from(threadElement.querySelectorAll(YOUTUBE_PAGE_SELECTOR.comment)).find(
      (element) => closestAncestor(element, YOUTUBE_PAGE_SELECTOR.commentThread) === threadElement
    ) ?? null;
  }
  function findDirectCommentInSubThread(subThread) {
    return Array.from(subThread.querySelectorAll(YOUTUBE_PAGE_SELECTOR.comment)).find(
      (element) => element.closest("yt-sub-thread") === subThread
    ) ?? null;
  }
  function collectThreadComments(threadElement) {
    const outermostThread = findOutermostThread(threadElement);
    const rootElement = findThreadComment(outermostThread);
    const rootComment = rootElement ? readComment(rootElement) : null;
    if (!rootElement || !rootComment) {
      return [];
    }
    const parsedComments = /* @__PURE__ */ new Map();
    for (const element of outermostThread.querySelectorAll(YOUTUBE_PAGE_SELECTOR.comment)) {
      const comment = readComment(element);
      if (comment) {
        parsedComments.set(element, comment);
      }
    }
    const comments = [rootComment];
    for (const [element, comment] of parsedComments) {
      if (element === rootElement) {
        continue;
      }
      if (!comment.isReply) {
        continue;
      }
      const subThread = element.closest("yt-sub-thread");
      const parentSubThread = subThread ? closestAncestor(subThread, "yt-sub-thread") : null;
      const parentElement = parentSubThread ? findDirectCommentInSubThread(parentSubThread) : rootElement;
      const parentComment = parentElement ? parsedComments.get(parentElement) : void 0;
      if (!parentComment) {
        continue;
      }
      comments.push({ ...comment, parentCommentId: parentComment.commentId });
    }
    if (comments[0]?.commentId !== rootComment.commentId) {
      return [];
    }
    return comments;
  }

  // src/content/comments/comment-controller.ts
  var COMMENT_ID_ATTRIBUTE = "data-xtranslator-comment-id";
  var MOUNT_COMMENT_TRANSLATION = XTRANSLATOR_DOM.mountCommentTranslation;
  var MOUNT_COMMENT_CONTROL = XTRANSLATOR_DOM.mountCommentControl;
  var MOUNT_BATCH_CONTROL = "comment-batch-control";
  var SCROLL_IDLE_DELAY_MS = 150;
  var CommentTranslationController = class {
    constructor(documentNode) {
      this.documentNode = documentNode;
    }
    commentState = /* @__PURE__ */ new Map();
    translatedTextById = /* @__PURE__ */ new Map();
    commentItemById = /* @__PURE__ */ new Map();
    observer = null;
    rootObserver = null;
    root = null;
    scanScheduled = false;
    scanHandle = null;
    scrollIdleHandle = null;
    activeTranslationRunId = null;
    activeTranslationButton = null;
    onScroll = () => this.requestScrollScan();
    onTextTranslationProgress = (message) => {
      if (!isTranslateTextProgressMessage(message) || message.scope !== "comment" || message.runId !== this.activeTranslationRunId || !this.activeTranslationButton) {
        return;
      }
      this.setButtonState(
        this.activeTranslationButton,
        t("comment.translatingProgress", { completed: message.completed, total: message.total }),
        "loading"
      );
    };
    start() {
      this.documentNode.defaultView?.addEventListener("scroll", this.onScroll, true);
      if (typeof chrome !== "undefined") {
        chrome.runtime?.onMessage?.addListener(this.onTextTranslationProgress);
      }
      this.watchForRoot();
    }
    /** Re-attach on SPA video navigation, dropping the previous root and state. */
    reset() {
      this.stop();
      this.start();
    }
    stop() {
      this.documentNode.defaultView?.removeEventListener("scroll", this.onScroll, true);
      if (typeof chrome !== "undefined") {
        chrome.runtime?.onMessage?.removeListener(this.onTextTranslationProgress);
      }
      if (this.scanHandle !== null) {
        this.documentNode.defaultView?.cancelAnimationFrame(this.scanHandle);
        this.scanHandle = null;
      }
      if (this.scrollIdleHandle !== null) {
        this.documentNode.defaultView?.clearTimeout(this.scrollIdleHandle);
        this.scrollIdleHandle = null;
      }
      this.scanScheduled = false;
      this.observer?.disconnect();
      this.observer = null;
      this.rootObserver?.disconnect();
      this.rootObserver = null;
      this.root = null;
      this.commentState.clear();
      this.translatedTextById.clear();
      this.commentItemById.clear();
      this.activeTranslationRunId = null;
      this.activeTranslationButton = null;
      this.documentNode.querySelectorAll(
        `[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_TRANSLATION}"],[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_CONTROL}"],[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_BATCH_CONTROL}"]`
      ).forEach((element) => element.remove());
    }
    watchForRoot() {
      const root = findCommentsRoot(this.documentNode);
      if (root) {
        this.attachRoot(root);
      }
      this.rootObserver = new MutationObserver(() => {
        const found = findCommentsRoot(this.documentNode);
        if (found && found !== this.root) {
          this.attachRoot(found);
        }
      });
      this.rootObserver.observe(this.documentNode.documentElement, { childList: true, subtree: true });
    }
    attachRoot(root) {
      this.observer?.disconnect();
      this.root = root;
      this.observer = new MutationObserver((mutations) => {
        if (mutations.some((mutation) => this.isRelevantMutation(mutation))) {
          this.requestScan();
        }
      });
      this.observer.observe(root, { childList: true, subtree: true });
      this.runScan();
    }
    /**
     * Coalesce a burst of mutations into a single scan per animation frame, so the
     * controller never re-enters while YouTube is hydrating comments.
     */
    requestScan() {
      if (this.scanScheduled || !this.root) {
        return;
      }
      this.scanScheduled = true;
      this.scanHandle = this.documentNode.defaultView?.requestAnimationFrame(() => {
        this.scanHandle = null;
        this.scanScheduled = false;
        this.runScan();
      }) ?? null;
    }
    /** Keep the control stable while the page is moving, then re-anchor at rest. */
    requestScrollScan() {
      const view = this.documentNode.defaultView;
      if (!view || !this.root) {
        return;
      }
      if (this.scrollIdleHandle !== null) {
        view.clearTimeout(this.scrollIdleHandle);
      }
      this.scrollIdleHandle = view.setTimeout(() => {
        this.scrollIdleHandle = null;
        this.requestScan();
      }, SCROLL_IDLE_DELAY_MS);
    }
    runScan() {
      if (!this.root) {
        return;
      }
      this.mutate(() => this.scan(this.root));
    }
    mutate(apply) {
      this.observer?.disconnect();
      try {
        apply();
      } finally {
        if (this.root) {
          this.observer?.observe(this.root, { childList: true, subtree: true });
        }
      }
    }
    mountBatchControl(root) {
      root.querySelectorAll("button.xtranslator-comment-action").forEach((element) => {
        if (element.getAttribute(XTRANSLATOR_DOM.mountAttribute) !== MOUNT_BATCH_CONTROL) {
          const label = element.querySelector(".xtranslator-comment-action-label");
          if (label?.textContent?.startsWith(t("comment.translateVisiblePrefix"))) {
            element.remove();
          }
        }
      });
      let button = root.querySelector(
        `[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_BATCH_CONTROL}"]`
      );
      if (button && this.scrollIdleHandle !== null) {
        return;
      }
      const topLevelComments = this.collectCommentElements(root).filter(
        (comment) => !comment.closest(YOUTUBE_PAGE_SELECTOR.commentRepliesContainer)
      );
      const firstComment = topLevelComments.find((comment) => {
        const rect = comment.getBoundingClientRect();
        return rect.top >= 0 && rect.top < (this.documentNode.defaultView?.innerHeight ?? 0);
      }) ?? topLevelComments.find((comment) => this.isVisibleInViewport(comment)) ?? topLevelComments[0];
      if (!firstComment) {
        return;
      }
      const visibleCount = this.collectVisibleComments().length;
      if (!button) {
        button = this.createActionButton(
          t("comment.translateVisible", { count: visibleCount }),
          t("comment.translateVisibleAria", { count: visibleCount })
        );
        button.setAttribute(XTRANSLATOR_DOM.mountAttribute, MOUNT_BATCH_CONTROL);
        button.addEventListener("click", () => void this.translateVisibleBatch(button));
      } else if (button.dataset.state !== "loading" && button.dataset.state !== "error") {
        this.setActionButtonLabel(
          button,
          t("comment.translateVisible", { count: visibleCount }),
          t("comment.translateVisibleAria", { count: visibleCount })
        );
      }
      if (button.parentElement !== firstComment.parentElement || button.nextElementSibling !== firstComment) {
        firstComment.insertAdjacentElement("beforebegin", button);
      }
    }
    scan(root) {
      this.mountBatchControl(root);
      const seen = /* @__PURE__ */ new Set();
      for (const element of this.collectCommentElements(root)) {
        const comment = readComment(element);
        if (!comment || seen.has(comment.commentId)) {
          continue;
        }
        seen.add(comment.commentId);
        if (element.getAttribute(COMMENT_ID_ATTRIBUTE) !== comment.commentId) {
          element.setAttribute(COMMENT_ID_ATTRIBUTE, comment.commentId);
        }
        this.ensureCommentMounted(element, comment, this.collectThreadAround(element));
      }
    }
    collectCommentElements(root) {
      return Array.from(root.querySelectorAll(YOUTUBE_PAGE_SELECTOR.comment));
    }
    /**
     * Best-effort thread grouping: when the comment sits inside a known thread
     * container, return every comment in it (parent + expanded replies); otherwise
     * return the single comment so single/batch translation still works.
     */
    collectThreadAround(commentElement) {
      const thread = commentElement.closest(YOUTUBE_PAGE_SELECTOR.commentThread);
      if (!thread) {
        return [readComment(commentElement)].filter((comment) => comment !== null);
      }
      return collectThreadComments(thread);
    }
    ensureCommentMounted(commentElement, comment, threadComments) {
      this.commentItemById.set(comment.commentId, { id: comment.commentId, sourceText: comment.sourceText });
      const state = this.commentState.get(comment.commentId) ?? "idle";
      if (state !== "idle") {
        this.renderStoredTranslation(commentElement, comment.commentId);
      } else {
        this.commentState.set(comment.commentId, "idle");
      }
      this.mountCommentControls(commentElement, comment, threadComments);
    }
    mountCommentControls(commentElement, comment, threadComments) {
      const group = buildThread(threadComments, comment.commentId);
      const isThreadRootWithReplies = group?.root.commentId === comment.commentId && group.replies.length > 0;
      if (!isThreadRootWithReplies) {
        commentElement.querySelector(`[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_CONTROL}"]`)?.remove();
        return;
      }
      let row = commentElement.querySelector(
        `[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_CONTROL}"]`
      );
      if (!row) {
        row = this.documentNode.createElement("div");
        row.className = "xtranslator-comment-controls";
        row.setAttribute(XTRANSLATOR_DOM.mountAttribute, MOUNT_COMMENT_CONTROL);
        row.setAttribute(COMMENT_ID_ATTRIBUTE, comment.commentId);
        const toolbar = commentElement.querySelector("#toolbar");
        if (toolbar) {
          toolbar.insertAdjacentElement("afterend", row);
        } else {
          commentElement.append(row);
        }
      }
      row.querySelectorAll('[data-action="thread-toggle"], .xtranslator-comment-thread-label').forEach(
        (element) => element.remove()
      );
      const threadButtonCount = comment.isReply ? group.replies.length : threadComments.length;
      if (!row.querySelector('[data-action="thread"]')) {
        const threadButton = this.createActionButton(
          t("comment.translateThread", { count: threadButtonCount }),
          t("comment.translateThreadAria", { count: threadButtonCount })
        );
        threadButton.dataset.action = "thread";
        threadButton.addEventListener("pointerdown", (event) => event.stopPropagation(), true);
        threadButton.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
          void this.translateCurrentThread(commentElement, threadButton);
        }, true);
        row.append(threadButton);
      } else {
        const threadButton = row.querySelector('[data-action="thread"]');
        if (threadButton && threadButton.dataset.state !== "loading" && threadButton.dataset.state !== "error") {
          this.setActionButtonLabel(
            threadButton,
            t("comment.translateThread", { count: threadButtonCount }),
            t("comment.translateThreadAria", { count: threadButtonCount })
          );
        }
      }
    }
    async translateCurrentThread(commentElement, button) {
      const allThreadComments = dedupeComments(this.collectThreadAround(commentElement));
      const commentId = commentElement.getAttribute(COMMENT_ID_ATTRIBUTE);
      const threadComments = commentId ? collectCommentBranch(allThreadComments, commentId) : [];
      const group = commentId ? buildThread(threadComments, commentId) : null;
      if (!group || group.replies.length === 0) {
        this.setButtonState(button, t("comment.noExpandedReplies"), "error");
        const threadButtonCount = group?.root.isReply ? group.replies.length : threadComments.length;
        this.documentNode.defaultView?.setTimeout(
          () => this.setActionButtonLabel(
            button,
            t("comment.translateThread", { count: threadButtonCount }),
            t("comment.translateThreadAria", { count: threadButtonCount })
          ),
          1800
        );
        return;
      }
      await this.requestTranslation(
        commentsToTextItems(threadComments),
        button,
        t("comment.translatedThread", {
          count: group.root.isReply ? group.replies.length : threadComments.length
        })
      );
    }
    async translateVisibleBatch(button) {
      const all = this.collectVisibleComments();
      const candidates = dedupeComments(
        all.filter((comment) => {
          const state = this.commentState.get(comment.commentId);
          return state === void 0 || state === "idle" || state === "failed";
        })
      );
      if (candidates.length === 0) {
        this.setButtonState(
          button,
          all.length > 0 ? t("comment.translatedVisible", { count: all.length }) : t("comment.noTranslatableComments"),
          "done"
        );
        return;
      }
      await this.requestTranslation(
        commentsToTextItems(candidates),
        button,
        t("comment.translatedVisible", { count: candidates.length })
      );
    }
    collectVisibleComments() {
      if (!this.root) {
        return [];
      }
      const all = [];
      const seen = /* @__PURE__ */ new Set();
      for (const element of this.collectCommentElements(this.root)) {
        if (!this.isVisibleInViewport(element)) {
          continue;
        }
        const comment = readComment(element);
        if (!comment || seen.has(comment.commentId)) {
          continue;
        }
        seen.add(comment.commentId);
        all.push(comment);
      }
      return all;
    }
    isVisibleInViewport(element) {
      const view = this.documentNode.defaultView;
      if (!view) {
        return true;
      }
      const rect = element.getBoundingClientRect();
      return rect.bottom > 0 && rect.top < view.innerHeight;
    }
    isRelevantMutation(mutation) {
      const target = mutation.target instanceof Element ? mutation.target : null;
      if (target?.closest(`[${XTRANSLATOR_DOM.mountAttribute}]`)) {
        return false;
      }
      const isCommentStructure = (node) => {
        const element = node instanceof Element ? node : node.parentElement;
        if (!element) {
          return false;
        }
        return element.matches(YOUTUBE_PAGE_SELECTOR.comment) || element.matches(YOUTUBE_PAGE_SELECTOR.commentHeader) || element.querySelector(YOUTUBE_PAGE_SELECTOR.comment) !== null || element.querySelector(YOUTUBE_PAGE_SELECTOR.commentHeader) !== null || element.closest(YOUTUBE_PAGE_SELECTOR.comment) !== null;
      };
      return Array.from(mutation.addedNodes).some(isCommentStructure) || Array.from(mutation.removedNodes).some(isCommentStructure);
    }
    async requestTranslation(items, button, doneLabel = t("comment.translatedVisible", { count: 0 })) {
      const fresh = [];
      for (const item of items) {
        const state = this.commentState.get(item.id);
        if (state === "pending" || state === "done") {
          continue;
        }
        this.commentState.set(item.id, "pending");
        fresh.push(item);
      }
      if (fresh.length === 0) {
        return;
      }
      if (button) {
        this.setButtonState(button, t("comment.translatingProgress", { completed: 0, total: fresh.length }), "loading");
      }
      const runId = `comment-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      this.activeTranslationRunId = runId;
      this.activeTranslationButton = button;
      try {
        const videoTitle = this.getVideoTitle();
        const response = await chrome.runtime.sendMessage({
          type: MESSAGE_TYPE.translateText,
          runId,
          scope: "comment",
          items: fresh,
          ...videoTitle ? { videoTitle } : {}
        });
        if (!isTranslateTextResponse(response)) {
          throw new Error("Invalid translate-text response.");
        }
        if (!response.ok) {
          throw new Error(response.errorMessage);
        }
        const failedIds = new Set(response.missingIds);
        const skippedIds = new Set(response.skippedIds ?? []);
        let hasFailure = false;
        for (const item of fresh) {
          if (skippedIds.has(item.id)) {
            this.commentState.set(item.id, "done");
            this.removeTranslation(item.id);
            continue;
          }
          const translated = response.translations[item.id];
          if (!failedIds.has(item.id) && typeof translated === "string" && translated.trim().length > 0) {
            this.translatedTextById.set(item.id, translated);
            this.commentState.set(item.id, "done");
            this.renderTranslation(item.id, translated, "done");
          } else {
            hasFailure = true;
            this.commentState.set(item.id, "failed");
            this.renderTranslation(item.id, "", "failed");
          }
        }
        if (button) {
          this.setButtonState(
            button,
            hasFailure ? t("comment.retryIncompleteCount", { count: fresh.filter((item) => failedIds.has(item.id)).length }) : doneLabel,
            hasFailure ? "error" : "done"
          );
        }
      } catch {
        for (const item of fresh) {
          this.commentState.set(item.id, "failed");
          this.renderTranslation(item.id, "", "failed");
        }
        if (button) {
          this.setButtonState(button, t("comment.retryIncompleteCount", { count: fresh.length }), "error");
        }
      } finally {
        if (this.activeTranslationRunId === runId) {
          this.activeTranslationRunId = null;
          this.activeTranslationButton = null;
        }
      }
    }
    getVideoTitle() {
      const title = this.documentNode.querySelector(YOUTUBE_PAGE_SELECTOR.title)?.textContent?.trim();
      return title || void 0;
    }
    renderStoredTranslation(commentElement, commentId) {
      const translated = this.translatedTextById.get(commentId);
      const state = this.commentState.get(commentId);
      if (translated === void 0 && state !== "failed") {
        return;
      }
      this.renderTranslation(commentId, translated ?? "", state === "failed" ? "failed" : "done");
    }
    removeTranslation(commentId) {
      const commentElement = this.collectCommentElements(this.root ?? this.documentNode.documentElement).find(
        (element) => element.getAttribute(COMMENT_ID_ATTRIBUTE) === commentId
      );
      commentElement?.querySelector(`[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_TRANSLATION}"]`)?.remove();
    }
    renderTranslation(commentId, translated, state) {
      const commentElement = this.collectCommentElements(this.root ?? this.documentNode.documentElement).find(
        (element) => element.getAttribute(COMMENT_ID_ATTRIBUTE) === commentId
      );
      if (!commentElement) {
        return;
      }
      const textElement = commentElement.querySelector(YOUTUBE_PAGE_SELECTOR.commentContent);
      if (!textElement) {
        return;
      }
      const translationAnchor = commentElement.querySelector(YOUTUBE_PAGE_SELECTOR.commentExpander) ?? textElement.closest(YOUTUBE_PAGE_SELECTOR.commentContentContainer) ?? textElement;
      let node = commentElement.querySelector(
        `[${XTRANSLATOR_DOM.mountAttribute}="${MOUNT_COMMENT_TRANSLATION}"]`
      );
      if (!node) {
        node = this.documentNode.createElement("div");
        node.className = "xtranslator-comment-translation";
        node.setAttribute(XTRANSLATOR_DOM.mountAttribute, MOUNT_COMMENT_TRANSLATION);
      }
      if (translationAnchor.nextElementSibling !== node) {
        translationAnchor.insertAdjacentElement("afterend", node);
      }
      node.dataset.state = state;
      if (state === "failed") {
        const existingRetryButton = node.querySelector('[data-action="comment-retry"]');
        if (existingRetryButton) {
          existingRetryButton.textContent = t("comment.translationFailedRetry");
          existingRetryButton.dataset.state = "error";
          existingRetryButton.disabled = false;
          existingRetryButton.setAttribute("aria-busy", "false");
          return;
        }
        const retryButton = this.documentNode.createElement("button");
        retryButton.className = "xtranslator-comment-retry";
        retryButton.type = "button";
        retryButton.dataset.action = "comment-retry";
        retryButton.setAttribute("aria-label", t("comment.retryComment", { id: commentId }));
        retryButton.textContent = t("comment.translationFailedRetry");
        retryButton.addEventListener("pointerdown", (event) => event.stopPropagation(), true);
        retryButton.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
          const item = this.commentItemById.get(commentId);
          if (!item) {
            return;
          }
          this.setButtonState(retryButton, t("comment.translatingProgress", { completed: 0, total: 1 }), "loading");
          void this.requestTranslation([item], retryButton, t("comment.retried"));
        }, true);
        node.replaceChildren(retryButton);
        return;
      }
      const text = translated;
      if (node.textContent !== text || node.querySelector('[data-action="comment-retry"]')) {
        node.replaceChildren(this.documentNode.createTextNode(text));
      }
    }
    createActionButton(label, ariaLabel) {
      const button = this.documentNode.createElement("button");
      button.className = "xtranslator-comment-action";
      button.type = "button";
      button.setAttribute("aria-label", ariaLabel);
      button.append(createBrandMark(this.documentNode, "light", 16));
      const labelElement = this.documentNode.createElement("span");
      labelElement.className = "xtranslator-comment-action-label";
      labelElement.textContent = label;
      button.append(labelElement);
      return button;
    }
    setActionButtonLabel(button, label, ariaLabel) {
      const labelElement = button.querySelector(".xtranslator-comment-action-label");
      if (labelElement) {
        labelElement.textContent = label;
      } else {
        button.textContent = label;
      }
      button.setAttribute("aria-label", ariaLabel);
    }
    setButtonState(button, label, state) {
      this.setActionButtonLabel(button, label, label);
      button.dataset.state = state;
      button.disabled = state === "loading";
      button.setAttribute("aria-busy", state === "loading" ? "true" : "false");
    }
  };

  // src/shared/selection/selection-context.ts
  var SENTENCE_TERMINATORS = /[.!?。！？]/u;
  function sentenceSpans(text) {
    const spans = [];
    let start = 0;
    for (let index = 0; index < text.length; index += 1) {
      if (SENTENCE_TERMINATORS.test(text[index])) {
        let end = index + 1;
        while (end < text.length && /\s/u.test(text[end])) {
          end += 1;
        }
        spans.push({ start, end });
        start = end;
        index = end - 1;
      }
    }
    if (start < text.length) {
      spans.push({ start, end: text.length });
    }
    return spans;
  }
  function extractSentenceContext(fullText, start, end) {
    const safeStart = Math.max(0, Math.min(start, fullText.length));
    const safeEnd = Math.max(safeStart, Math.min(end, fullText.length));
    const spans = sentenceSpans(fullText);
    const selectedSpanIndex = spans.findIndex(
      (span) => span.start <= safeStart && span.start <= safeEnd && span.end >= safeEnd
    );
    if (selectedSpanIndex === -1) {
      return {};
    }
    const before = selectedSpanIndex > 0 ? spans[selectedSpanIndex - 1] : void 0;
    const after = selectedSpanIndex < spans.length - 1 ? spans[selectedSpanIndex + 1] : void 0;
    return {
      ...before ? { contextBefore: fullText.slice(before.start, before.end).trim() || void 0 } : {},
      ...after ? { contextAfter: fullText.slice(after.start, after.end).trim() || void 0 } : {}
    };
  }

  // src/content/selection/selection-controller.ts
  var PILL_CLASS = "xtranslator-selection-pill";
  var RESULT_CLASS = "xtranslator-selection-result";
  var MOUNT_SELECTION = XTRANSLATOR_DOM.mountSelection;
  var SELECTION_DEBOUNCE_MS = 100;
  var SelectionController = class {
    constructor(documentNode) {
      this.documentNode = documentNode;
    }
    pill = null;
    result = null;
    nextItemId = 0;
    selectionEnabled = true;
    showPillTimer = null;
    translationRunId = 0;
    start() {
      this.documentNode.addEventListener("mousedown", this.onMouseDown);
      this.documentNode.addEventListener("mouseup", this.onMouseUp);
      this.documentNode.addEventListener("keyup", this.onKeyUp);
      this.documentNode.addEventListener("scroll", this.hidePill, true);
      this.documentNode.defaultView?.addEventListener("blur", this.hidePill);
      void this.loadSelectionSettings();
      if (typeof chrome !== "undefined" && chrome.storage?.onChanged) {
        chrome.storage.onChanged.addListener((changes, areaName) => {
          if (areaName === "local" && changes.settings) {
            void this.loadSelectionSettings();
          }
        });
      }
      typeof chrome !== "undefined" && chrome.runtime.onMessage.addListener((message) => {
        if (this.selectionEnabled && message && message.type === MESSAGE_TYPE.translateSelectionFromContext) {
          void this.translateCurrentSelection();
        }
        return false;
      });
    }
    onMouseDown = (event) => {
      if (!this.selectionEnabled || this.isOwnOverlay(event.target)) {
        return;
      }
      if (event.detail >= 2) {
        this.hidePill();
      }
    };
    onMouseUp = (event) => {
      if (!this.selectionEnabled) {
        return;
      }
      if (this.isOwnOverlay(event.target)) {
        return;
      }
      this.scheduleShowPill();
    };
    onKeyUp = (event) => {
      if (!this.selectionEnabled) {
        return;
      }
      if (event.key === "Escape") {
        this.hideOverlays();
        return;
      }
      if (this.isOwnOverlay(event.target)) {
        return;
      }
      this.scheduleShowPill();
    };
    isOwnOverlay(node) {
      if (!node || node.nodeType !== Node.ELEMENT_NODE) {
        return false;
      }
      return Boolean(node.closest(`.${PILL_CLASS}, .${RESULT_CLASS}`));
    }
    scheduleShowPill() {
      if (!this.selectionEnabled) {
        return;
      }
      if (this.showPillTimer !== null) {
        this.documentNode.defaultView?.clearTimeout(this.showPillTimer);
      }
      const timer = this.documentNode.defaultView?.setTimeout(() => {
        this.showPillTimer = null;
        if (this.selectionEnabled) {
          this.showPill();
        }
      }, SELECTION_DEBOUNCE_MS);
      this.showPillTimer = timer ?? null;
    }
    readSelection() {
      const selection = this.documentNode.defaultView?.getSelection();
      if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
        return null;
      }
      const text = selection.toString().trim();
      if (!text) {
        return null;
      }
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) {
        return null;
      }
      return { text, range, rect };
    }
    showPill() {
      const selection = this.readSelection();
      if (!selection) {
        this.hidePill();
        return;
      }
      if (!this.pill || !this.pill.isConnected) {
        this.pill = this.buildPill();
      }
      this.pill.hidden = false;
      this.position(this.pill, selection.rect);
    }
    buildPill() {
      const pill = this.documentNode.createElement("div");
      pill.className = PILL_CLASS;
      pill.setAttribute(XTRANSLATOR_DOM.mountAttribute, MOUNT_SELECTION);
      pill.setAttribute("role", "toolbar");
      pill.setAttribute("aria-label", t("selection.toolbar"));
      const translate2 = this.documentNode.createElement("button");
      translate2.className = "xtranslator-selection-action xtranslator-selection-primary";
      translate2.type = "button";
      translate2.dataset.action = "translate";
      translate2.setAttribute("aria-label", t("selection.translateAria"));
      translate2.append(createElement(MousePointer2), this.documentNode.createTextNode(t("selection.translate")));
      translate2.addEventListener("click", () => void this.translateCurrentSelection());
      const copy = this.documentNode.createElement("button");
      copy.className = "xtranslator-selection-action";
      copy.type = "button";
      copy.dataset.action = "copy";
      copy.setAttribute("aria-label", t("selection.copyAria"));
      copy.append(createElement(Copy));
      copy.addEventListener("click", () => this.copySelection());
      const close = this.documentNode.createElement("button");
      close.className = "xtranslator-selection-action";
      close.type = "button";
      close.dataset.action = "close";
      close.setAttribute("aria-label", t("selection.closeAria"));
      close.append(createElement(X));
      close.addEventListener("click", () => this.hidePill());
      pill.append(translate2, copy, close);
      this.documentNode.body.append(pill);
      return pill;
    }
    async copySelection() {
      const text = this.documentNode.defaultView?.getSelection()?.toString() ?? "";
      if (text) {
        await this.copyText(text);
      }
    }
    async copyText(text) {
      try {
        await navigator.clipboard?.writeText(text);
      } catch {
        const textarea = this.documentNode.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        this.documentNode.body.append(textarea);
        textarea.select();
        this.documentNode.execCommand("copy");
        textarea.remove();
      }
    }
    buildSelectionItem() {
      const selection = this.readSelection();
      if (!selection) {
        return null;
      }
      const includeContext = this.includeContext();
      const id = `sel-${this.nextItemId += 1}`;
      if (includeContext) {
        const context = this.singleNodeContext(selection.range);
        if (context) {
          return { id, sourceText: selection.text, ...context.contextBefore ? { contextBefore: context.contextBefore } : {}, ...context.contextAfter ? { contextAfter: context.contextAfter } : {} };
        }
      }
      return { id, sourceText: selection.text };
    }
    singleNodeContext(range) {
      const startNode = range.startContainer;
      const endNode = range.endContainer;
      if (startNode !== endNode || startNode.nodeType !== Node.TEXT_NODE) {
        return null;
      }
      const fullText = startNode.textContent ?? "";
      return extractSentenceContext(fullText, range.startOffset, range.endOffset);
    }
    includeContext() {
      return this.includeContextSetting;
    }
    includeContextSetting = false;
    async loadIncludeContext() {
      await this.loadSelectionSettings();
    }
    async loadSelectionSettings() {
      try {
        const response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.getSettings });
        if (isSettingsMessageResponse(response)) {
          const enabled = response.settings.selection.enabled;
          if (!enabled) {
            this.hideOverlays();
          }
          this.selectionEnabled = enabled;
          this.includeContextSetting = response.settings.selection.includeContext;
        }
      } catch {
      }
    }
    async translateCurrentSelection() {
      if (!this.selectionEnabled) {
        return;
      }
      await this.loadIncludeContext();
      if (!this.selectionEnabled) {
        return;
      }
      const item = this.buildSelectionItem();
      if (!item) {
        return;
      }
      const anchor = this.currentSelectionRect();
      const result = this.showResultPanel(anchor);
      const runId = ++this.translationRunId;
      this.pill?.remove();
      this.pill = null;
      this.setResultState(result, "loading", t("selection.translating"));
      try {
        const response = await chrome.runtime.sendMessage({
          type: MESSAGE_TYPE.translateText,
          scope: "selection",
          items: [item]
        });
        if (!isTranslateTextResponse(response)) {
          throw new Error("Invalid translate-text response.");
        }
        if (!response.ok) {
          throw new Error(response.errorMessage);
        }
        const translated = response.translations[item.id];
        if (typeof translated !== "string") {
          throw new Error("Missing translation.");
        }
        if (runId !== this.translationRunId || this.result !== result || !result.isConnected) {
          return;
        }
        this.setResultText(result, translated);
      } catch {
        if (runId !== this.translationRunId || this.result !== result || !result.isConnected) {
          return;
        }
        this.setResultState(result, "error", t("selection.failed"));
      }
    }
    currentSelectionRect() {
      const selection = this.readSelection();
      return selection?.rect ?? null;
    }
    showResultPanel(anchor) {
      if (this.result && this.result.isConnected) {
        this.position(this.result, anchor);
        return this.result;
      }
      const panel = this.documentNode.createElement("div");
      panel.className = RESULT_CLASS;
      panel.setAttribute(XTRANSLATOR_DOM.mountAttribute, MOUNT_SELECTION);
      const content = this.documentNode.createElement("div");
      content.className = "xtranslator-selection-result-text";
      const actions = this.documentNode.createElement("div");
      actions.className = "xtranslator-selection-result-actions";
      const copy = this.documentNode.createElement("button");
      copy.className = "xtranslator-selection-action";
      copy.type = "button";
      copy.dataset.action = "copy-result";
      copy.setAttribute("aria-label", t("selection.copyTranslationAria"));
      copy.append(createElement(Copy));
      copy.addEventListener("click", () => void this.copyResultText(panel));
      const close = this.documentNode.createElement("button");
      close.className = "xtranslator-selection-action";
      close.type = "button";
      close.dataset.action = "close-result";
      close.setAttribute("aria-label", t("selection.cancelAria"));
      close.append(createElement(X));
      close.addEventListener("click", () => this.closeResultPanel());
      actions.append(copy, close);
      panel.append(content, actions);
      this.documentNode.body.append(panel);
      this.result = panel;
      this.position(panel, anchor);
      return panel;
    }
    async copyResultText(panel) {
      const text = panel.querySelector(".xtranslator-selection-result-text")?.textContent ?? "";
      if (text) {
        await this.copyText(text);
        const copyButton = panel.querySelector('[data-action="copy-result"]');
        if (copyButton) {
          copyButton.replaceChildren(createElement(Check));
          this.documentNode.defaultView?.setTimeout(() => copyButton.replaceChildren(createElement(Copy)), 1200);
        }
      }
    }
    setResultState(panel, state, message) {
      panel.dataset.state = state;
      const close = panel.querySelector('[data-action="close-result"]');
      close?.setAttribute("aria-label", state === "loading" ? t("selection.cancelAria") : t("selection.closeTranslationAria"));
      const content = panel.querySelector(".xtranslator-selection-result-text");
      if (content) {
        content.replaceChildren();
        if (state === "loading") {
          const loader = createElement(LoaderCircle);
          loader.classList.add("xtranslator-spin");
          content.append(loader, this.documentNode.createTextNode(message));
        } else if (state === "error") {
          content.append(createElement(CircleAlert), this.documentNode.createTextNode(message));
        } else {
          content.textContent = message;
        }
      }
    }
    setResultText(panel, translated) {
      panel.dataset.state = "done";
      panel.querySelector('[data-action="close-result"]')?.setAttribute("aria-label", t("selection.closeTranslationAria"));
      const content = panel.querySelector(".xtranslator-selection-result-text");
      if (content) {
        content.replaceChildren();
        content.textContent = translated;
      }
    }
    position(element, anchor) {
      const viewport = this.documentNode.defaultView;
      if (!viewport) {
        return;
      }
      element.style.left = "0px";
      element.style.top = "0px";
      element.style.transform = "translateY(0)";
      const rect = element.getBoundingClientRect();
      const margin = 8;
      const anchorRect = anchor ?? rect;
      let left = anchorRect.left + margin;
      let top = anchorRect.bottom + margin;
      left = Math.max(margin, Math.min(left, viewport.innerWidth - rect.width - margin));
      if (top + rect.height > viewport.innerHeight - margin) {
        top = Math.max(margin, anchorRect.top - rect.height - margin);
      }
      element.style.left = `${Math.round(left)}px`;
      element.style.top = `${Math.round(top)}px`;
    }
    hidePill = () => {
      if (this.showPillTimer !== null) {
        this.documentNode.defaultView?.clearTimeout(this.showPillTimer);
        this.showPillTimer = null;
      }
      this.pill?.remove();
      this.pill = null;
    };
    closeResultPanel = () => {
      this.translationRunId += 1;
      this.result?.remove();
      this.result = null;
    };
    hideOverlays = () => {
      this.hidePill();
      this.closeResultPanel();
    };
  };

  // src/shared/design-tokens.ts
  var DESIGN_TOKEN = {
    color: {
      accentCyan: "#33d6ff",
      accentViolet: "#7865ff",
      accentMix: "#5c9bff",
      textOnDark: "#f5f7ff",
      textPrimary: "#1d1d1f",
      textSecondary: "#5f636b",
      surfaceGlassDark: "rgba(19, 22, 33, 0.72)",
      surfaceGlassDarkStrong: "rgba(19, 22, 33, 0.88)",
      surfaceGlassLight: "rgba(255, 255, 255, 0.56)",
      surfaceGlassLightStrong: "rgba(255, 255, 255, 0.78)",
      borderGlassDark: "rgba(255, 255, 255, 0.18)",
      borderGlassLight: "rgba(255, 255, 255, 0.76)",
      danger: "#c0362c"
    },
    radius: { control: "10px", panel: "16px" },
    shadow: { float: "0 12px 32px rgba(0, 0, 0, 0.28)" },
    blur: { glass: "24px" },
    duration: { fast: "160ms", normal: "220ms" }
  };

  // src/content/content-style.ts
  var CONTENT_STYLE = `
  .xtranslator-player-mount { position: relative; display: flex; flex: 0 0 36px; align-items: center; min-width: 36px; height: 100%; margin-right: 4px; }
  .xtranslator-shorts-player-mount { position: absolute; top: 24px; right: 152px; z-index: 5; height: 32px; margin: 0; }
  .xtranslator-shorts-player-mount .xtranslator-status { top: calc(100% + 8px); bottom: auto; }
  /* Shorts keeps CC/fullscreen controls outside the light-DOM child list, but
     the visible toolbar is the positioned parent below. Pin our child within
     that toolbar instead of letting its flex layout push it over fullscreen. */
  #shorts-player .ytp-chrome-top-buttons > [data-xtranslator-mount="player"] { position: absolute; top: 0; right: 160px; z-index: 1; display: flex; flex: 0 0 44px; align-items: center; justify-content: center; width: 44px; min-width: 44px; height: 44px; margin: 0; background: transparent; }
  .xtranslator-control { display: grid; flex: 0 0 32px; width: 32px; height: 32px; padding: 0; color: ${DESIGN_TOKEN.color.textOnDark}; border: 1px solid transparent; border-radius: ${DESIGN_TOKEN.radius.control}; background: transparent; box-shadow: none; place-items: center; cursor: pointer; transition: background ${DESIGN_TOKEN.duration.fast}, border-color ${DESIGN_TOKEN.duration.fast}, transform ${DESIGN_TOKEN.duration.fast}; }
  .xtranslator-control svg { display: block; width: 18px; height: 18px; }
  .xtranslator-brand-mark { display: block; object-fit: contain; }
  .xtranslator-control .xtranslator-brand-mark { display: block !important; visibility: visible !important; width: 20px; height: 20px; border-radius: 6px; opacity: 1 !important; }
  .xtranslator-control:hover { border-color: rgba(255, 255, 255, 0.22); background: rgba(255, 255, 255, 0.14); transform: translateY(-1px); }
  .xtranslator-control:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 2px; }
  .xtranslator-control:disabled { cursor: progress; opacity: .72; }
  .xtranslator-status { position: absolute; right: 0; bottom: calc(100% + 8px); box-sizing: border-box; display: flex; align-items: center; gap: 6px; max-width: 320px; padding: 8px 12px; color: ${DESIGN_TOKEN.color.textOnDark}; border: 1px solid ${DESIGN_TOKEN.color.borderGlassDark}; border-radius: ${DESIGN_TOKEN.radius.control}; background: ${DESIGN_TOKEN.color.surfaceGlassDark}; box-shadow: ${DESIGN_TOKEN.shadow.float}; backdrop-filter: blur(${DESIGN_TOKEN.blur.glass}); font: 13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .xtranslator-status svg { display: block; width: 14px; height: 14px; flex: none; }
  .xtranslator-status[data-tone="success"] { border-color: rgba(51, 214, 255, .3); }
  .xtranslator-status[data-tone="error"] { color: #ffb4ad; border-color: rgba(255, 180, 173, .34); background: ${DESIGN_TOKEN.color.surfaceGlassDarkStrong}; }
  .xtranslator-spin { animation: xtranslator-rotate 0.8s linear infinite; }
  .xtranslator-translation { margin-top: 8px; color: ${DESIGN_TOKEN.color.textSecondary}; font: 14px/20px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  .xtranslator-title-translation { min-height: 40px; }
  .xtranslator-title-translation[data-state="loading"] { opacity: .78; }
  .xtranslator-title-translation[data-state="error"] { color: ${DESIGN_TOKEN.color.danger}; }
  .xtranslator-title-translation[data-state="failed"] { display: flex; align-items: center; gap: 8px; color: ${DESIGN_TOKEN.color.danger}; }
  .xtranslator-title-retry { min-height: 32px; padding: 0 10px; color: inherit; border: 1px solid currentColor; border-radius: ${DESIGN_TOKEN.radius.control}; background: transparent; cursor: pointer; font: 600 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  .xtranslator-title-retry:hover { background: rgba(214, 48, 49, .08); }
  .xtranslator-title-retry:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 1px; }
  .xtranslator-description-translation { margin: 12px 0 4px; }
  .xtranslator-description-action { display: inline-flex; align-items: center; gap: 6px; min-height: 32px; padding: 0 12px 0 8px; color: ${DESIGN_TOKEN.color.textOnDark}; border: 1px solid ${DESIGN_TOKEN.color.borderGlassDark}; border-radius: 999px; background: ${DESIGN_TOKEN.color.surfaceGlassDark}; box-shadow: 0 3px 10px rgba(25, 35, 69, .22); cursor: pointer; font: 600 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; transition: background ${DESIGN_TOKEN.duration.fast}, box-shadow ${DESIGN_TOKEN.duration.fast}, transform ${DESIGN_TOKEN.duration.fast}; }
  .xtranslator-description-action .xtranslator-brand-mark { width: 16px; height: 16px; flex: none; border-radius: 5px; }
  .xtranslator-description-action:hover { box-shadow: 0 5px 14px rgba(25, 35, 69, .28); transform: translateY(-1px); }
  .xtranslator-description-action:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 1px; }
  .xtranslator-description-action:disabled { cursor: progress; opacity: .72; }
  .xtranslator-description-result { display: grid; gap: 4px; margin-top: 8px; padding: 9px 12px; color: ${DESIGN_TOKEN.color.textPrimary}; border: 1px solid rgba(91, 108, 153, .16); border-left: 3px solid ${DESIGN_TOKEN.color.accentViolet}; border-radius: 8px; background: ${DESIGN_TOKEN.color.surfaceGlassLightStrong}; font: 13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  .xtranslator-description-label { color: ${DESIGN_TOKEN.color.accentViolet}; font: 600 11px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; letter-spacing: .02em; }
  .xtranslator-description-result-text { white-space: pre-wrap; }
  .xtranslator-description-translation[data-state="failed"] .xtranslator-description-result { color: ${DESIGN_TOKEN.color.danger}; border-left-color: ${DESIGN_TOKEN.color.danger}; }
  .xtranslator-caption { position: absolute; inset: auto; box-sizing: border-box; z-index: 10000; padding: 0 2%; pointer-events: none; text-align: center; }
  .xtranslator-caption[hidden] { display: none; }
  .xtranslator-caption-card { position: absolute; bottom: var(--xtranslator-caption-bottom, 4.25rem); left: 50%; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; gap: 2px; width: fit-content; max-width: min(92%, 72rem); padding: 5px 14px 6px; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 8px; background: rgba(0, 0, 0, 0.62); box-shadow: 0 2px 12px rgba(0, 0, 0, 0.22); pointer-events: auto; touch-action: none; user-select: none; cursor: grab; transform: translateX(-50%); }
  .xtranslator-caption-card[data-position="manual"] { bottom: auto; }
  .xtranslator-caption-card[data-dragging="true"] { cursor: grabbing; }
  .xtranslator-caption-line { box-sizing: border-box; display: block; width: 100%; max-width: 100%; padding: 0; color: #ffffff; font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; font-size: clamp(15px, 1.35vw, 18px); line-height: 1.25; text-shadow: 0 1px 2px rgba(0, 0, 0, 0.85); white-space: normal; overflow-wrap: break-word; word-break: normal; text-wrap: pretty; }
  .xtranslator-caption-original { color: var(--xtranslator-caption-original-color, #ececf0); font-size: clamp(calc(13px * var(--xtranslator-caption-original-scale, 1)), calc(1.05vw * var(--xtranslator-caption-original-scale, 1)), calc(15px * var(--xtranslator-caption-original-scale, 1))); }
  .xtranslator-caption-translation { color: var(--xtranslator-caption-translation-color, #ffd438); font-size: clamp(calc(16px * var(--xtranslator-caption-translation-scale, 1)), calc(1.4vw * var(--xtranslator-caption-translation-scale, 1)), calc(19px * var(--xtranslator-caption-translation-scale, 1))); font-weight: 700; }
  /* Shorts uses a narrow portrait player, so its subtitle size is intentionally
     fixed and independent from the regular-video preference sliders. */
  .xtranslator-caption[data-layout="shorts"] .xtranslator-caption-original { font-size: 15px; }
  .xtranslator-caption[data-layout="shorts"] .xtranslator-caption-translation { font-size: 19px; }
  body.xtranslator-captions-suppressed ${YOUTUBE_PAGE_SELECTOR.captionWindow} { visibility: hidden !important; }
  .${XTRANSLATOR_DOM.nativeCaptionSuppressedClass} { visibility: hidden !important; }
  .xtranslator-comments-control { display: flex; align-items: center; margin: 12px 0 4px; }
  .xtranslator-comment-controls { display: flex; align-items: center; gap: 6px; margin-top: 2px; }
  .xtranslator-comment-action { position: relative; z-index: 1; display: inline-flex; align-items: center; gap: 5px; min-height: 32px; padding: 0 11px; color: ${DESIGN_TOKEN.color.textPrimary}; border: 1px solid rgba(86, 102, 148, .18); border-radius: ${DESIGN_TOKEN.radius.control}; background: ${DESIGN_TOKEN.color.surfaceGlassLightStrong}; box-shadow: inset 0 1px 0 rgba(255, 255, 255, .78); cursor: pointer; font: 600 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; pointer-events: auto; transition: background ${DESIGN_TOKEN.duration.fast}, box-shadow ${DESIGN_TOKEN.duration.fast}, transform ${DESIGN_TOKEN.duration.fast}; }
  /* The batch action is moved beside the first visible top-level comment by the
     controller. It must stay in normal flow: sticky positioning flickers when
     YouTube reflows or virtualizes the last comment container. */
  [data-xtranslator-mount="comment-batch-control"] { position: relative; z-index: 2; }
  [data-xtranslator-mount="comment-batch-control"].xtranslator-comment-action { color: ${DESIGN_TOKEN.color.textOnDark}; border-color: rgba(255, 255, 255, .32); background: ${DESIGN_TOKEN.color.accentViolet}; box-shadow: 0 4px 12px rgba(60, 55, 142, .2); }
  .xtranslator-comment-action > * { pointer-events: none; }
  .xtranslator-comment-action svg { width: 12px; height: 12px; flex: none; }
  .xtranslator-comment-action .xtranslator-brand-mark { width: 16px; height: 16px; flex: none; border-radius: 5px; }
  .xtranslator-comment-action:hover { background: rgba(255, 255, 255, .96); box-shadow: inset 0 1px 0 rgba(255, 255, 255, .88), 0 3px 10px rgba(41, 52, 84, .12); transform: translateY(-1px); }
  [data-xtranslator-mount="comment-batch-control"].xtranslator-comment-action:hover { background: #6955ed; }
  .xtranslator-comment-action:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 1px; }
  .xtranslator-comment-action[data-state="loading"] { cursor: progress; opacity: .72; }
  .xtranslator-comment-action[data-state="error"] { color: ${DESIGN_TOKEN.color.danger}; }
  .xtranslator-comment-translation { box-sizing: border-box; max-width: 100%; margin-top: 6px; padding: 8px 12px; color: ${DESIGN_TOKEN.color.textPrimary}; border: 1px solid rgba(86, 102, 148, .14); border-left: 3px solid ${DESIGN_TOKEN.color.accentViolet}; border-radius: 8px; background: ${DESIGN_TOKEN.color.surfaceGlassLightStrong}; font: 13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  .xtranslator-comment-retry { padding: 0; color: inherit; border: 0; background: transparent; cursor: pointer; font: inherit; text-align: left; }
  .xtranslator-comment-retry:hover { text-decoration: underline; }
  .xtranslator-comment-retry:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 2px; border-radius: 3px; }
  .xtranslator-comment-retry[data-state="loading"] { cursor: progress; opacity: .72; }
  .xtranslator-comment-translation[data-state="failed"] { color: ${DESIGN_TOKEN.color.danger}; border-left-color: ${DESIGN_TOKEN.color.danger}; }
  .xtranslator-selection-pill { position: fixed; z-index: 100010; display: flex; align-items: center; gap: 4px; box-sizing: border-box; padding: 4px; color: ${DESIGN_TOKEN.color.textOnDark}; border: 1px solid ${DESIGN_TOKEN.color.borderGlassDark}; border-radius: 999px; background: ${DESIGN_TOKEN.color.surfaceGlassDark}; box-shadow: ${DESIGN_TOKEN.shadow.float}; backdrop-filter: blur(${DESIGN_TOKEN.blur.glass}); }
  .xtranslator-selection-pill[hidden] { display: none; }
  .xtranslator-selection-result { position: fixed; z-index: 100011; display: grid; gap: 8px; box-sizing: border-box; width: min(360px, calc(100vw - 16px)); padding: 10px 12px; color: ${DESIGN_TOKEN.color.textOnDark}; border: 1px solid ${DESIGN_TOKEN.color.borderGlassDark}; border-radius: ${DESIGN_TOKEN.radius.panel}; background: ${DESIGN_TOKEN.color.surfaceGlassDarkStrong}; box-shadow: ${DESIGN_TOKEN.shadow.float}; backdrop-filter: blur(${DESIGN_TOKEN.blur.glass}); font: 14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
  .xtranslator-selection-result[hidden] { display: none; }
  .xtranslator-selection-result[data-state="loading"] .xtranslator-selection-result-text { color: ${DESIGN_TOKEN.color.textOnDark}; opacity: .8; }
  .xtranslator-selection-result[data-state="error"] .xtranslator-selection-result-text { color: ${DESIGN_TOKEN.color.textOnDark}; }
  .xtranslator-selection-result-actions { display: flex; align-items: center; justify-content: flex-end; gap: 4px; }
  .xtranslator-selection-action { display: grid; width: 32px; height: 32px; padding: 0; color: ${DESIGN_TOKEN.color.textOnDark}; border: 0; border-radius: ${DESIGN_TOKEN.radius.control}; background: transparent; place-items: center; cursor: pointer; }
  .xtranslator-selection-action svg { display: block; width: 15px; height: 15px; }
  .xtranslator-selection-action:hover { background: rgba(255, 255, 255, 0.12); }
  .xtranslator-selection-action:focus-visible { outline: 2px solid ${DESIGN_TOKEN.color.accentMix}; outline-offset: 1px; }
  .xtranslator-selection-primary { display: inline-flex; align-items: center; gap: 4px; width: auto; padding: 0 10px; color: ${DESIGN_TOKEN.color.textOnDark}; background: ${DESIGN_TOKEN.color.accentViolet}; font-size: 12px; font-weight: 600; }
  .xtranslator-selection-primary:hover { background: ${DESIGN_TOKEN.color.accentViolet}; filter: brightness(1.08); }
  .xtranslator-selection-primary svg { width: 13px; height: 13px; }
  .xtranslator-selection-result-text { display: flex; align-items: flex-start; gap: 6px; color: ${DESIGN_TOKEN.color.textOnDark}; overflow-wrap: anywhere; white-space: pre-wrap; }
  .xtranslator-selection-result-text svg { width: 14px; height: 14px; flex: none; margin-top: 2px; }
  @keyframes xtranslator-rotate { to { transform: rotate(360deg); } }
  @media (prefers-reduced-motion: reduce) { .xtranslator-control, .xtranslator-description-action, .xtranslator-comment-action { transition: none; } .xtranslator-control:hover, .xtranslator-description-action:hover, .xtranslator-comment-action:hover { transform: none; } .xtranslator-spin { animation: none; } }
`;
  function ensureContentStyle(documentNode) {
    if (documentNode.getElementById(XTRANSLATOR_DOM.styleId)) {
      return;
    }
    const style = documentNode.createElement("style");
    style.id = XTRANSLATOR_DOM.styleId;
    style.textContent = CONTENT_STYLE;
    documentNode.head.append(style);
  }

  // src/shared/storage/settings-repository.ts
  var SETTINGS_STORAGE_KEY = "settings";
  var SettingsRepository = class {
    constructor(storageArea) {
      this.storageArea = storageArea;
    }
    async loadSettings() {
      const stored = await this.storageArea.get(SETTINGS_STORAGE_KEY);
      return parseExtensionSettings(stored[SETTINGS_STORAGE_KEY]) ?? { ...DEFAULT_SETTINGS };
    }
    async saveSettings(settings) {
      await this.storageArea.set({ [SETTINGS_STORAGE_KEY]: settings });
    }
  };
  function createChromeSettingsRepository() {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      throw new Error("xTranslator settings are only available inside Chrome.");
    }
    return new SettingsRepository(chrome.storage.local);
  }

  // src/content/index.ts
  var PAGE_UNSUPPORTED_MESSAGE = t("content.pageUnsupported");
  var PLAYER_CONTROL_CONFIRMATION_DELAY_MS = 200;
  var TITLE_TRANSLATION_DELAY_MS = 400;
  var captionOverlay = null;
  var subtitleSettings = { ...DEFAULT_SUBTITLE_SETTINGS };
  var shortsTranslationEnabled = DEFAULT_SUBTITLE_SETTINGS.shortsTranslationEnabled;
  var autoTranslateTitleEnabled = true;
  var titleTranslationSettingsReady = false;
  var pageRuntime = null;
  var nextVideoTranslationRunId = 0;
  var activeVideoTranslationRun = null;
  function getExtensionSettings(value) {
    return parseExtensionSettings(value);
  }
  async function saveCaptionVerticalPosition(verticalPosition) {
    const repository = createChromeSettingsRepository();
    const settings = await repository.loadSettings();
    await repository.saveSettings({
      ...settings,
      subtitles: { ...settings.subtitles, verticalPosition }
    });
  }
  function getCaptionOverlay(documentNode, player) {
    captionOverlay ??= new CaptionOverlayController(documentNode, player, saveCaptionVerticalPosition);
    captionOverlay.setSettings(subtitleSettings);
    return captionOverlay;
  }
  function bindSettingsChange() {
    if (typeof chrome === "undefined" || !chrome.storage?.onChanged) {
      return;
    }
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") {
        return;
      }
      const settings = getExtensionSettings(changes.settings?.newValue);
      if (settings) {
        subtitleSettings = settings.subtitles;
        shortsTranslationEnabled = settings.subtitles.shortsTranslationEnabled;
        autoTranslateTitleEnabled = settings.page.autoTranslateTitle;
        titleTranslationSettingsReady = true;
        captionOverlay?.setSettings(settings.subtitles);
        pageRuntime?.invalidateDescriptionTranslationAvailability();
        pageRuntime?.refresh();
      }
    });
  }
  function createMount(documentNode, mount, className) {
    const element = documentNode.createElement("div");
    element.setAttribute(XTRANSLATOR_DOM.mountAttribute, mount);
    element.className = className;
    return element;
  }
  function createTranslationContainer(documentNode, mount) {
    const container = createMount(documentNode, mount, "xtranslator-translation");
    if (mount === XTRANSLATOR_DOM.mountTitle) {
      container.classList.add("xtranslator-title-translation");
    }
    container.hidden = true;
    container.setAttribute("aria-live", "polite");
    return container;
  }
  function renderTitleTranslation(container, run, onRetry) {
    container.dataset.state = run.state;
    if (run.state === "waiting" || run.state === "checking" || run.state === "skipped") {
      container.hidden = true;
      return;
    }
    container.hidden = false;
    switch (run.state) {
      case "loading":
        if (container.textContent !== t("content.translatingTitle") || container.childElementCount > 0) {
          container.textContent = t("content.translatingTitle");
        }
        break;
      case "done":
        if (container.textContent !== (run.translatedText ?? "") || container.childElementCount > 0) {
          container.textContent = run.translatedText ?? "";
        }
        break;
      case "failed":
        if (!onRetry) {
          if (container.textContent !== t("content.titleTranslationFailed") || container.childElementCount > 0) {
            container.textContent = t("content.titleTranslationFailed");
          }
          break;
        }
        if (container.querySelector("[data-xtranslator-title-retry]")) {
          break;
        }
        const failureMessage = container.ownerDocument.createElement("span");
        failureMessage.textContent = t("content.titleTranslationFailed");
        const retryButton = container.ownerDocument.createElement("button");
        retryButton.type = "button";
        retryButton.className = "xtranslator-title-retry";
        retryButton.setAttribute("data-xtranslator-title-retry", "");
        retryButton.textContent = t("content.retryTitleTranslation");
        retryButton.addEventListener("click", onRetry);
        container.replaceChildren(failureMessage, retryButton);
        break;
    }
  }
  function getDescriptionTranslationItems(run) {
    return run.sourceLines.flatMap((sourceText, index) => {
      const text = sourceText.trim();
      return text ? [{ id: `${run.itemId}-${index}`, sourceText: text }] : [];
    });
  }
  function reassembleDescriptionTranslation(run, translations, skippedIds = []) {
    const skipped = new Set(skippedIds);
    let missingTranslation = false;
    const translatedLines = run.sourceLines.map((sourceText, index) => {
      if (!sourceText.trim()) {
        return sourceText;
      }
      const itemId = `${run.itemId}-${index}`;
      if (skipped.has(itemId)) {
        return sourceText;
      }
      const translatedText = translations[itemId]?.trim();
      if (!translatedText) {
        missingTranslation = true;
        return sourceText;
      }
      return translatedText;
    });
    return missingTranslation ? null : translatedLines.join("\n");
  }
  function createDescriptionTranslationContainer(documentNode) {
    const container = createMount(documentNode, XTRANSLATOR_DOM.mountDescription, "xtranslator-description-translation");
    const button = documentNode.createElement("button");
    button.type = "button";
    button.className = "xtranslator-description-action";
    button.setAttribute("data-xtranslator-description-action", "");
    button.append(createBrandMark(documentNode, "light", 16));
    const label = documentNode.createElement("span");
    label.setAttribute("data-xtranslator-description-action-label", "");
    button.append(label);
    const result = documentNode.createElement("div");
    result.className = "xtranslator-description-result";
    result.setAttribute("data-xtranslator-description-result", "");
    result.hidden = true;
    const resultLabel = documentNode.createElement("span");
    resultLabel.className = "xtranslator-description-label";
    resultLabel.setAttribute("data-xtranslator-description-label", "");
    const resultText = documentNode.createElement("div");
    resultText.className = "xtranslator-description-result-text";
    resultText.setAttribute("data-xtranslator-description-result-text", "");
    result.append(resultLabel, resultText);
    container.append(button, result);
    container.hidden = true;
    container.setAttribute("aria-live", "polite");
    return container;
  }
  function setDescriptionActionLabel(button, label) {
    button.setAttribute("aria-label", t("content.descriptionActionAria", { action: label }));
    const labelElement = button.querySelector("[data-xtranslator-description-action-label]");
    if (labelElement) {
      labelElement.textContent = label;
    }
  }
  function renderDescriptionTranslation(container, run) {
    const button = container.querySelector("[data-xtranslator-description-action]");
    const result = container.querySelector("[data-xtranslator-description-result]");
    const resultLabel = container.querySelector("[data-xtranslator-description-label]");
    const resultText = container.querySelector("[data-xtranslator-description-result-text]");
    if (!button || !result || !resultLabel || !resultText) {
      return;
    }
    container.hidden = false;
    container.dataset.state = run.state;
    button.disabled = run.state === "loading";
    result.hidden = run.state !== "done" || !run.translationVisible;
    switch (run.state) {
      case "idle":
        setDescriptionActionLabel(button, t("content.translateDescription"));
        resultLabel.textContent = "";
        resultText.textContent = "";
        break;
      case "loading":
        setDescriptionActionLabel(button, t("content.translatingDescription"));
        resultLabel.textContent = "";
        resultText.textContent = "";
        break;
      case "done":
        setDescriptionActionLabel(button, t(run.translationVisible ? "content.hideDescriptionTranslation" : "content.showDescriptionTranslation"));
        resultLabel.textContent = t("content.descriptionTranslation");
        resultText.textContent = run.translatedText ?? "";
        break;
      case "failed":
        setDescriptionActionLabel(button, t("content.translateDescription"));
        result.hidden = false;
        resultLabel.textContent = "";
        resultText.textContent = t("content.descriptionTranslationFailed");
        break;
    }
  }
  function showTranslationStatus(container, message) {
    container.hidden = false;
    container.textContent = message;
  }
  function mountTranslationContainers(documentNode, anchors) {
    if (anchors.title && !hasExtensionMount(documentNode, XTRANSLATOR_DOM.mountTitle)) {
      anchors.title.insertAdjacentElement("afterend", createTranslationContainer(documentNode, XTRANSLATOR_DOM.mountTitle));
    }
  }
  function setTranslationError(documentNode, message) {
    const titleContainer = findExtensionMount(documentNode, XTRANSLATOR_DOM.mountTitle);
    if (titleContainer) {
      showTranslationStatus(titleContainer, `xTranslator\uFF1A${message}`);
    }
  }
  function deactivateCaptionOverlay() {
    captionOverlay?.deactivate();
    captionOverlay = null;
  }
  function selectDefaultCaptionTrack(snapshot) {
    return snapshot.captionTracks.find((track) => track.kind !== "asr") ?? snapshot.captionTracks[0];
  }
  function captionErrorMessage(result) {
    switch (result.reason) {
      case "http":
        return t("content.captionHttp");
      case "network":
        return t("content.captionNetwork");
      case "unsupported-format":
        return t("content.captionUnsupported");
    }
  }
  async function loadCaptionTranscript(snapshot, track) {
    let body;
    try {
      body = await requestTranscriptBody(snapshot.videoId, track);
    } catch {
      return { status: "error", reason: "network", canRetry: true };
    }
    const segments = new YouTubeTranscriptParser().parse(createCaptionTrackFingerprint(track), body);
    return segments ? { status: "ready", segments } : { status: "error", reason: "unsupported-format", canRetry: true };
  }
  async function requestVideoTranslation(snapshot, track, segments, runId) {
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE.translateVideo,
      runId,
      videoId: snapshot.videoId,
      videoTitle: snapshot.title,
      sourceTrackFingerprint: createCaptionTrackFingerprint(track),
      sourceLanguage: track.languageCode,
      segments: [...segments]
    });
    if (!isTranslateVideoResponse(response)) {
      throw new Error("Invalid xTranslator translate response.");
    }
    return response;
  }
  function bindVideoTranslationProgress() {
    if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (!isTranslateVideoProgressMessage(message)) {
        return false;
      }
      const active = activeVideoTranslationRun;
      if (!active || active.runId !== message.runId || active.videoId !== message.videoId || active.sourceTrackFingerprint !== message.sourceTrackFingerprint) {
        return false;
      }
      const anchors = findYouTubePageAnchors(document);
      if (!anchors) {
        return false;
      }
      const overlay = getCaptionOverlay(document, anchors.player);
      overlay.append([message.block]);
      overlay.setMode(message.displayMode);
      active.translatedBlockIds.add(message.block.id);
      renderStatus(
        document,
        active.status,
        "info",
        LoaderCircle,
        true,
        t("content.translatingProgress", {
          translated: active.translatedBlockIds.size,
          total: active.segmentCount
        })
      );
      void publishVideoTranslationStatus({
        phase: "translating",
        videoId: active.videoId,
        videoTitle: active.videoTitle,
        segmentCount: active.segmentCount,
        translatedCount: active.translatedBlockIds.size
      });
      return false;
    });
  }
  async function resolveTranslationBlockCount(segments, sourceLanguage) {
    try {
      const response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.getSettings });
      if (isSettingsMessageResponse(response)) {
        const preset = getProviderPreset(response.settings.provider.providerId);
        if (preset) {
          const model = response.settings.provider.model.trim();
          if (!model) {
            return segments.length;
          }
          return buildTranslationBlocks(
            segments,
            getProviderContextWindow(preset, model),
            void 0,
            void 0,
            void 0,
            sourceLanguage
          ).length;
        }
      }
    } catch {
    }
    return segments.length;
  }
  async function requestCachedVideoTranslation(videoId) {
    const response = await chrome.runtime.sendMessage({
      type: MESSAGE_TYPE.getVideoTranslationCache,
      videoId
    });
    if (!isVideoTranslationCacheResponse(response)) {
      throw new Error("Invalid xTranslator cache response.");
    }
    return response;
  }
  async function publishVideoTranslationStatus(status) {
    if (typeof chrome === "undefined") {
      return;
    }
    try {
      await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.updateVideoTranslationStatus, status });
    } catch {
    }
  }
  function createStatusIcon(icon, spinning) {
    const element = createElement(icon);
    if (spinning) {
      element.classList.add("xtranslator-spin");
    }
    return element;
  }
  function setPlayerBrandIcon(documentNode, button) {
    button.replaceChildren(createBrandMark(documentNode, "dark", 20));
  }
  function setPlayerButtonLabel(button, label) {
    button.title = label;
    button.setAttribute("aria-label", label);
  }
  function setButtonIcon(documentNode, button, icon, spinning = false) {
    button.replaceChildren(createStatusIcon(icon, spinning));
  }
  function renderStatus(documentNode, status, tone, icon, spinning, message) {
    status.replaceChildren(createStatusIcon(icon, spinning), documentNode.createTextNode(message));
    status.dataset.tone = tone;
    status.hidden = false;
  }
  function mountPlayerControl(documentNode, anchors, snapshot, isCurrent) {
    const isShortsPlayer = anchors.player.id === "shorts-player";
    const controlParent = isShortsPlayer ? anchors.playerTopControls ?? anchors.player : anchors.playerRightControls ?? anchors.playerTopControls ?? anchors.player;
    const existingMount = findExtensionMount(documentNode, XTRANSLATOR_DOM.mountPlayer);
    if (existingMount?.parentElement === controlParent) {
      return;
    }
    existingMount?.remove();
    const isShortsFallback = isShortsPlayer && anchors.playerTopControls === null;
    const control = createMount(
      documentNode,
      XTRANSLATOR_DOM.mountPlayer,
      isShortsFallback ? "xtranslator-player-mount xtranslator-shorts-player-mount" : "xtranslator-player-mount"
    );
    const button = documentNode.createElement("button");
    button.className = "xtranslator-control";
    button.type = "button";
    setPlayerButtonLabel(button, t("content.startTranslation"));
    setPlayerBrandIcon(documentNode, button);
    const status = documentNode.createElement("div");
    status.className = "xtranslator-status";
    status.hidden = true;
    status.setAttribute("role", "status");
    let cachedResponsePromise = null;
    const readCache = () => {
      cachedResponsePromise ??= requestCachedVideoTranslation(snapshot.videoId).catch(() => ({ found: false }));
      return cachedResponsePromise;
    };
    const track = selectDefaultCaptionTrack(snapshot);
    const applyCachedResponse = async (response) => {
      if (!response.found || !isCurrent()) {
        return false;
      }
      if (track && (response.sourceLanguage !== track.languageCode || response.sourceTrackFingerprint !== createCaptionTrackFingerprint(track))) {
        return false;
      }
      const overlay = getCaptionOverlay(documentNode, anchors.player);
      overlay.load(response.blocks);
      overlay.setMode(response.displayMode);
      const translatedCount = response.blocks.filter((block) => block.translatedText.trim()).length;
      renderStatus(
        documentNode,
        status,
        "success",
        Check,
        false,
        t("content.translationCompleteProgress", {
          translated: translatedCount,
          total: response.blocks.length
        })
      );
      setPlayerButtonLabel(button, t("content.translateAgain"));
      await publishVideoTranslationStatus({
        phase: "translated",
        videoId: snapshot.videoId,
        videoTitle: snapshot.title,
        segmentCount: response.blocks.length,
        translatedCount
      });
      return true;
    };
    button.addEventListener("click", () => {
      const runId = `video-${nextVideoTranslationRunId += 1}`;
      setPlayerButtonLabel(button, t("content.translating"));
      setButtonIcon(documentNode, button, LoaderCircle, true);
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
      void (async () => {
        const finish = () => {
          if (activeVideoTranslationRun?.runId === runId) {
            activeVideoTranslationRun = null;
          }
          if (isCurrent()) {
            setPlayerBrandIcon(documentNode, button);
            button.disabled = false;
            button.removeAttribute("aria-busy");
          }
        };
        if (!isCurrent()) {
          return;
        }
        renderStatus(documentNode, status, "info", LoaderCircle, true, t("content.readingCache"));
        const cachedResponse = await readCache();
        if (!isCurrent()) {
          return;
        }
        if (await applyCachedResponse(cachedResponse)) {
          finish();
          return;
        }
        if (!track) {
          const message = t("content.noCaptionsOrCache");
          setPlayerButtonLabel(button, t("content.retryCaptions"));
          renderStatus(documentNode, status, "error", CircleAlert, false, message);
          await publishVideoTranslationStatus({
            phase: "error",
            videoId: snapshot.videoId,
            videoTitle: snapshot.title,
            errorMessage: message
          });
          finish();
          return;
        }
        activeVideoTranslationRun = {
          runId,
          videoId: snapshot.videoId,
          videoTitle: snapshot.title,
          sourceTrackFingerprint: createCaptionTrackFingerprint(track),
          segmentCount: 0,
          translatedBlockIds: /* @__PURE__ */ new Set(),
          status
        };
        renderStatus(documentNode, status, "info", LoaderCircle, true, t("content.readingCaptions"));
        await publishVideoTranslationStatus({ phase: "reading-captions", videoId: snapshot.videoId, videoTitle: snapshot.title });
        const result = await loadCaptionTranscript(snapshot, track);
        if (!isCurrent()) {
          return;
        }
        if (result.status === "ready") {
          const translationBlockCount = await resolveTranslationBlockCount(result.segments, track.languageCode);
          renderStatus(documentNode, status, "info", LoaderCircle, true, t("content.translatingSegments", { count: translationBlockCount }));
          if (activeVideoTranslationRun?.runId === runId) {
            activeVideoTranslationRun.segmentCount = translationBlockCount;
            activeVideoTranslationRun.translatedBlockIds.clear();
            renderStatus(
              documentNode,
              status,
              "info",
              LoaderCircle,
              true,
              t("content.translatingProgress", { translated: 0, total: translationBlockCount })
            );
          }
          await publishVideoTranslationStatus({
            phase: "translating",
            videoId: snapshot.videoId,
            videoTitle: snapshot.title,
            segmentCount: translationBlockCount
          });
          try {
            const response = await requestVideoTranslation(snapshot, track, result.segments, runId);
            if (!isCurrent()) {
              return;
            }
            if (response.ok) {
              if (response.skipped) {
                deactivateCaptionOverlay();
                renderStatus(documentNode, status, "success", Check, false, t("content.noTranslationNeeded"));
                setPlayerButtonLabel(button, t("content.noTranslation"));
                await publishVideoTranslationStatus({
                  phase: "translated",
                  videoId: snapshot.videoId,
                  videoTitle: snapshot.title,
                  segmentCount: 0,
                  translatedCount: 0
                });
              } else {
                const overlay = getCaptionOverlay(documentNode, anchors.player);
                overlay.load(response.blocks);
                overlay.setMode(response.displayMode);
                const translatedCount = response.blocks.length - response.missingIds.length;
                renderStatus(
                  documentNode,
                  status,
                  "success",
                  Check,
                  false,
                  t("content.translationCompleteProgress", {
                    translated: translatedCount,
                    total: response.blocks.length
                  })
                );
                setPlayerButtonLabel(button, t("content.translateAgain"));
                await publishVideoTranslationStatus({
                  phase: "translated",
                  videoId: snapshot.videoId,
                  videoTitle: snapshot.title,
                  segmentCount: response.blocks.length,
                  translatedCount
                });
              }
            } else {
              if (response.partial) {
                const overlay = getCaptionOverlay(documentNode, anchors.player);
                overlay.load(response.partial.blocks);
                overlay.setMode(response.partial.displayMode);
                setPlayerButtonLabel(button, t("content.continueTranslation"));
                const translatedCount = response.partial.blocks.length - response.partial.missingIds.length;
                renderStatus(
                  documentNode,
                  status,
                  "error",
                  CircleAlert,
                  false,
                  t("content.partialTranslationProgress", {
                    translated: translatedCount,
                    total: response.partial.blocks.length,
                    missing: response.partial.missingIds.length
                  })
                );
              } else {
                setPlayerButtonLabel(button, t("content.retry"));
                renderStatus(documentNode, status, "error", CircleAlert, false, response.errorMessage);
              }
              await publishVideoTranslationStatus({
                phase: "error",
                videoId: snapshot.videoId,
                videoTitle: snapshot.title,
                errorMessage: response.errorMessage
              });
            }
          } catch {
            if (!isCurrent()) {
              return;
            }
            const message = t("content.serviceUnavailable");
            setPlayerButtonLabel(button, t("content.retry"));
            renderStatus(documentNode, status, "error", CircleAlert, false, message);
            await publishVideoTranslationStatus({
              phase: "error",
              videoId: snapshot.videoId,
              videoTitle: snapshot.title,
              errorMessage: message
            });
          }
        } else {
          if (!isCurrent()) {
            return;
          }
          const message = captionErrorMessage(result);
          setPlayerButtonLabel(button, t("content.retryCaptions"));
          renderStatus(documentNode, status, "error", CircleAlert, false, message);
          await publishVideoTranslationStatus({
            phase: "error",
            videoId: snapshot.videoId,
            videoTitle: snapshot.title,
            errorMessage: message
          });
        }
        finish();
      })();
    });
    control.append(button, status);
    controlParent.prepend(control);
    void readCache().then((response) => {
      if (!button.disabled && response.found) {
        void applyCachedResponse(response);
      }
    });
  }
  var YouTubePageRuntime = class {
    activeVideoId = null;
    routeVideoId = null;
    mountTimer;
    navigationVersion = 0;
    mountRetryCount = 0;
    pendingPlayerControlVideoId = null;
    playerControlShownVideoId = null;
    bridgeSnapshot = null;
    bridgeSnapshotPending = false;
    bridgeSnapshotRequestId = 0;
    titleTranslation = null;
    titleTranslationTimer;
    descriptionTranslation = null;
    descriptionTranslationAvailable = null;
    descriptionSettingsCheck = null;
    start() {
      document.addEventListener("yt-navigate-finish", () => this.resetForVideoNavigation());
      window.addEventListener("popstate", () => this.resetForVideoNavigation());
      new MutationObserver(() => this.scheduleMount()).observe(document.documentElement, { childList: true, subtree: true });
      this.scheduleMount();
    }
    scheduleMount(delayMs = 50) {
      if (this.mountTimer !== void 0) {
        return;
      }
      this.mountTimer = window.setTimeout(() => {
        this.mountTimer = void 0;
        this.mount();
      }, delayMs);
    }
    scheduleMountRetry() {
      if (this.mountRetryCount >= 24) {
        return false;
      }
      this.mountRetryCount += 1;
      this.scheduleMount(250);
      return true;
    }
    refresh() {
      this.scheduleMount();
    }
    invalidateDescriptionTranslationAvailability() {
      this.descriptionTranslationAvailable = null;
    }
    resetForVideoNavigation() {
      this.navigationVersion += 1;
      this.activeVideoId = null;
      activeVideoTranslationRun = null;
      this.mountRetryCount = 0;
      this.pendingPlayerControlVideoId = null;
      this.playerControlShownVideoId = null;
      this.bridgeSnapshot = null;
      this.bridgeSnapshotPending = false;
      this.bridgeSnapshotRequestId += 1;
      this.titleTranslation = null;
      this.descriptionTranslation = null;
      if (this.titleTranslationTimer !== void 0) {
        window.clearTimeout(this.titleTranslationTimer);
        this.titleTranslationTimer = void 0;
      }
      deactivateCaptionOverlay();
      removeVideoExtensionMounts(document);
      void publishVideoTranslationStatus({ phase: "idle" });
      this.scheduleMount();
    }
    isSnapshotForCurrentRoute(snapshot) {
      return snapshot !== null && (this.routeVideoId === null || snapshot.videoId === this.routeVideoId);
    }
    mount() {
      const routeVideoId = readYouTubeRouteVideoId(window.location.href);
      if (routeVideoId !== this.routeVideoId) {
        this.routeVideoId = routeVideoId;
        this.resetForVideoNavigation();
      }
      const anchors = findYouTubePageAnchors(document);
      if (!anchors) {
        this.scheduleMountRetry();
        return;
      }
      ensureContentStyle(document);
      const documentSnapshot = readYouTubeVideoSnapshot(document);
      const currentBridgeSnapshot = this.isSnapshotForCurrentRoute(this.bridgeSnapshot) ? this.bridgeSnapshot : null;
      const currentDocumentSnapshot = this.isSnapshotForCurrentRoute(documentSnapshot) ? documentSnapshot : null;
      const snapshot = currentBridgeSnapshot ?? currentDocumentSnapshot;
      if (!currentBridgeSnapshot && (!currentDocumentSnapshot || currentDocumentSnapshot.captionTracks.length === 0)) {
        this.requestBridgeSnapshot();
      }
      if (!snapshot) {
        if (this.scheduleMountRetry()) {
          return;
        }
        this.pendingPlayerControlVideoId = null;
        this.playerControlShownVideoId = null;
        deactivateCaptionOverlay();
        removeVideoExtensionMounts(document);
        mountTranslationContainers(document, anchors);
        setTranslationError(document, PAGE_UNSUPPORTED_MESSAGE);
        return;
      }
      this.mountRetryCount = 0;
      if (this.activeVideoId !== snapshot.videoId) {
        activeVideoTranslationRun = null;
        deactivateCaptionOverlay();
        removeVideoExtensionMounts(document);
        this.activeVideoId = snapshot.videoId;
        this.titleTranslation = null;
        this.descriptionTranslation = null;
        if (this.titleTranslationTimer !== void 0) {
          window.clearTimeout(this.titleTranslationTimer);
          this.titleTranslationTimer = void 0;
        }
        this.pendingPlayerControlVideoId = null;
        this.playerControlShownVideoId = null;
      }
      mountTranslationContainers(document, anchors);
      this.mountTitleTranslation(snapshot);
      this.mountDescriptionTranslation(snapshot);
      if (anchors.player.id === "shorts-player" && !shortsTranslationEnabled) {
        this.pendingPlayerControlVideoId = null;
        findExtensionMount(document, XTRANSLATOR_DOM.mountPlayer)?.remove();
        return;
      }
      const nativeCaptionsEnabled = isYouTubeNativeCaptionsEnabled(document, anchors.player);
      const canShowPlayerControl = shouldShowYouTubeTranslationControl(snapshot, nativeCaptionsEnabled);
      const alreadyShownForVideo = this.playerControlShownVideoId === snapshot.videoId;
      if (!shouldKeepYouTubeTranslationControl(snapshot, nativeCaptionsEnabled, alreadyShownForVideo)) {
        this.pendingPlayerControlVideoId = null;
        findExtensionMount(document, XTRANSLATOR_DOM.mountPlayer)?.remove();
        return;
      }
      if (!canShowPlayerControl) {
        this.pendingPlayerControlVideoId = null;
        return;
      }
      if (this.playerControlShownVideoId !== snapshot.videoId) {
        if (this.pendingPlayerControlVideoId !== snapshot.videoId) {
          this.pendingPlayerControlVideoId = snapshot.videoId;
          this.scheduleMount(PLAYER_CONTROL_CONFIRMATION_DELAY_MS);
          return;
        }
        this.pendingPlayerControlVideoId = null;
        this.playerControlShownVideoId = snapshot.videoId;
      }
      const navigationVersion = this.navigationVersion;
      mountPlayerControl(
        document,
        anchors,
        snapshot,
        () => navigationVersion === this.navigationVersion && this.activeVideoId === snapshot.videoId
      );
    }
    mountTitleTranslation(snapshot) {
      const container = findExtensionMount(document, XTRANSLATOR_DOM.mountTitle);
      if (!container) {
        return;
      }
      if (!isYouTubeWatchRoute(window.location.href) || !titleTranslationSettingsReady || !autoTranslateTitleEnabled) {
        container.hidden = true;
        return;
      }
      const sourceText = snapshot.title.trim();
      if (!sourceText) {
        container.hidden = true;
        return;
      }
      const current = this.titleTranslation;
      if (current?.videoId === snapshot.videoId && current.sourceText === sourceText) {
        this.renderTitleTranslation(container, current);
        return;
      }
      const run = {
        videoId: snapshot.videoId,
        itemId: `title-${snapshot.videoId}`,
        sourceText,
        state: "waiting"
      };
      this.titleTranslation = run;
      this.titleTranslationTimer = window.setTimeout(() => {
        this.titleTranslationTimer = void 0;
        void this.startTitleTranslation(run);
      }, TITLE_TRANSLATION_DELAY_MS);
    }
    renderTitleTranslation(container, run) {
      renderTitleTranslation(container, run, () => {
        this.retryTitleTranslation(run);
      });
    }
    retryTitleTranslation(run) {
      if (this.titleTranslation !== run || this.activeVideoId !== run.videoId || !autoTranslateTitleEnabled || !isYouTubeWatchRoute(window.location.href)) {
        return;
      }
      run.state = "checking";
      const container = findExtensionMount(document, XTRANSLATOR_DOM.mountTitle);
      if (container) {
        this.renderTitleTranslation(container, run);
      }
      void this.startTitleTranslation(run);
    }
    mountDescriptionTranslation(snapshot) {
      if (!isYouTubeWatchRoute(window.location.href)) {
        findExtensionMount(document, XTRANSLATOR_DOM.mountDescription)?.remove();
        return;
      }
      const source = findYouTubeExpandedDescriptionText(document);
      const sourceText = source?.textContent?.trim() ?? "";
      if (!source || !sourceText) {
        findExtensionMount(document, XTRANSLATOR_DOM.mountDescription)?.remove();
        return;
      }
      let run = this.descriptionTranslation;
      if (run?.videoId !== snapshot.videoId || run.sourceText !== sourceText) {
        run = {
          videoId: snapshot.videoId,
          itemId: `description-${snapshot.videoId}`,
          sourceText,
          sourceLines: sourceText.split(/\r?\n/u),
          state: "idle",
          translationVisible: false
        };
        this.descriptionTranslation = run;
        findExtensionMount(document, XTRANSLATOR_DOM.mountDescription)?.remove();
      }
      let container = findExtensionMount(document, XTRANSLATOR_DOM.mountDescription);
      if (container?.nextElementSibling !== source) {
        container?.remove();
        container = createDescriptionTranslationContainer(document);
        source.insertAdjacentElement("beforebegin", container);
        container.querySelector("[data-xtranslator-description-action]")?.addEventListener("click", () => {
          this.handleDescriptionTranslationAction(run);
        });
      }
      if (this.descriptionTranslationAvailable !== null) {
        container.hidden = !this.descriptionTranslationAvailable;
        if (this.descriptionTranslationAvailable) {
          renderDescriptionTranslation(container, run);
        }
        return;
      }
      container.hidden = true;
      void this.ensureDescriptionTranslationAvailable().then((available) => {
        if (this.descriptionTranslation !== run || this.activeVideoId !== run.videoId || !isYouTubeWatchRoute(window.location.href)) {
          return;
        }
        const currentContainer = findExtensionMount(document, XTRANSLATOR_DOM.mountDescription);
        if (!currentContainer) {
          return;
        }
        currentContainer.hidden = !available;
        if (available) {
          renderDescriptionTranslation(currentContainer, run);
        }
      });
    }
    async ensureDescriptionTranslationAvailable() {
      if (this.descriptionTranslationAvailable !== null) {
        return this.descriptionTranslationAvailable;
      }
      if (this.descriptionSettingsCheck) {
        return this.descriptionSettingsCheck;
      }
      const check = (async () => {
        try {
          const response = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.getSettings });
          if (!isSettingsMessageResponse(response)) {
            this.descriptionTranslationAvailable = false;
            return false;
          }
          const settings = response.settings;
          const apiKey = settings.apiKeys[settings.provider.providerId]?.trim() ?? "";
          this.descriptionTranslationAvailable = Boolean(apiKey && settings.provider.model.trim());
          return this.descriptionTranslationAvailable;
        } catch {
          this.descriptionTranslationAvailable = false;
          return false;
        }
      })();
      this.descriptionSettingsCheck = check;
      try {
        return await check;
      } finally {
        if (this.descriptionSettingsCheck === check) {
          this.descriptionSettingsCheck = null;
        }
      }
    }
    handleDescriptionTranslationAction(run) {
      if (this.descriptionTranslation !== run || this.activeVideoId !== run.videoId) {
        return;
      }
      if (run.state === "done") {
        run.translationVisible = !run.translationVisible;
        const container = findExtensionMount(document, XTRANSLATOR_DOM.mountDescription);
        if (container) {
          renderDescriptionTranslation(container, run);
        }
        return;
      }
      void this.startDescriptionTranslation(run);
    }
    async startDescriptionTranslation(run) {
      if (this.descriptionTranslation !== run || this.activeVideoId !== run.videoId || !this.descriptionTranslationAvailable || !isYouTubeWatchRoute(window.location.href)) {
        return;
      }
      run.state = "loading";
      const container = findExtensionMount(document, XTRANSLATOR_DOM.mountDescription);
      if (container) {
        renderDescriptionTranslation(container, run);
      }
      try {
        const items = getDescriptionTranslationItems(run);
        const response = await chrome.runtime.sendMessage({
          type: MESSAGE_TYPE.translateText,
          scope: "description",
          items
        });
        if (!isTranslateTextResponse(response) || !response.ok) {
          run.state = "failed";
        } else {
          const translatedText = reassembleDescriptionTranslation(run, response.translations, response.skippedIds);
          if (translatedText) {
            run.state = "done";
            run.translatedText = translatedText;
            run.translationVisible = true;
          } else {
            run.state = "failed";
          }
        }
      } catch {
        run.state = "failed";
      }
      if (this.descriptionTranslation !== run || this.activeVideoId !== run.videoId || !isYouTubeWatchRoute(window.location.href)) {
        return;
      }
      const currentContainer = findExtensionMount(document, XTRANSLATOR_DOM.mountDescription);
      if (currentContainer) {
        renderDescriptionTranslation(currentContainer, run);
      }
    }
    async startTitleTranslation(run) {
      if (this.titleTranslation !== run || this.activeVideoId !== run.videoId || !autoTranslateTitleEnabled || !isYouTubeWatchRoute(window.location.href)) {
        return;
      }
      run.state = "checking";
      let settingsResponse;
      try {
        settingsResponse = await chrome.runtime.sendMessage({ type: MESSAGE_TYPE.getSettings });
      } catch {
        run.state = "skipped";
        return;
      }
      if (this.titleTranslation !== run || this.activeVideoId !== run.videoId || !autoTranslateTitleEnabled || !isYouTubeWatchRoute(window.location.href)) {
        return;
      }
      if (!isSettingsMessageResponse(settingsResponse)) {
        run.state = "skipped";
        return;
      }
      const settings = settingsResponse.settings;
      const apiKey = settings.apiKeys[settings.provider.providerId]?.trim() ?? "";
      if (!apiKey || !settings.provider.model.trim()) {
        run.state = "skipped";
        return;
      }
      run.state = "loading";
      const container = findExtensionMount(document, XTRANSLATOR_DOM.mountTitle);
      if (container) {
        this.renderTitleTranslation(container, run);
      }
      try {
        const response = await chrome.runtime.sendMessage({
          type: MESSAGE_TYPE.translateText,
          scope: "title",
          items: [{ id: run.itemId, sourceText: run.sourceText }]
        });
        if (!isTranslateTextResponse(response) || !response.ok) {
          run.state = "failed";
        } else {
          const translatedText = response.translations[run.itemId]?.trim();
          if (translatedText) {
            run.state = "done";
            run.translatedText = translatedText;
          } else if (response.skippedIds?.includes(run.itemId)) {
            run.state = "skipped";
          } else {
            run.state = "failed";
          }
        }
        if (this.titleTranslation !== run || this.activeVideoId !== run.videoId || !autoTranslateTitleEnabled) {
          return;
        }
        const currentContainer = findExtensionMount(document, XTRANSLATOR_DOM.mountTitle);
        if (currentContainer) {
          this.renderTitleTranslation(currentContainer, run);
        }
      } catch {
        if (this.titleTranslation !== run) {
          return;
        }
        run.state = "failed";
        if (this.activeVideoId !== run.videoId || !autoTranslateTitleEnabled) {
          return;
        }
        const currentContainer = findExtensionMount(document, XTRANSLATOR_DOM.mountTitle);
        if (currentContainer) {
          this.renderTitleTranslation(currentContainer, run);
        }
      }
    }
    requestBridgeSnapshot() {
      if (this.bridgeSnapshotPending || this.routeVideoId === null) {
        return;
      }
      this.bridgeSnapshotPending = true;
      const navigationVersion = this.navigationVersion;
      const routeVideoId = this.routeVideoId;
      const requestId = this.bridgeSnapshotRequestId += 1;
      void requestPlayerResponse(routeVideoId).then((response) => {
        const snapshot = parseYouTubePlayerResponse(response);
        if (navigationVersion === this.navigationVersion && routeVideoId === this.routeVideoId && this.isSnapshotForCurrentRoute(snapshot)) {
          this.bridgeSnapshot = snapshot;
        }
        if (requestId === this.bridgeSnapshotRequestId) {
          this.bridgeSnapshotPending = false;
          this.scheduleMount();
        }
      });
    }
  };
  ensureContentStyle(document);
  bindSettingsChange();
  bindVideoTranslationProgress();
  void createChromeSettingsRepository().loadSettings().then((settings) => {
    subtitleSettings = settings.subtitles;
    shortsTranslationEnabled = settings.subtitles.shortsTranslationEnabled;
    autoTranslateTitleEnabled = settings.page.autoTranslateTitle;
    titleTranslationSettingsReady = true;
    captionOverlay?.setSettings(subtitleSettings);
    pageRuntime?.refresh();
  }).catch(() => {
    titleTranslationSettingsReady = true;
    pageRuntime?.refresh();
  });
  pageRuntime = new YouTubePageRuntime();
  pageRuntime.start();
  var commentController = new CommentTranslationController(document);
  commentController.start();
  document.addEventListener("yt-navigate-finish", () => commentController.reset());
  new SelectionController(document).start();
})();
//# sourceMappingURL=index.js.map
